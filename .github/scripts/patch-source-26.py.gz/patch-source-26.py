#!/usr/bin/env python3
from pathlib import Path
import re
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else "buildsrc")
main_path = root / "app/src/main/java/com/aiguanjia/app/MainActivity.kt"
engine_path = root / "app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt"
cpp_path = root / "app/src/main/cpp/dongbake_llama_jni.cpp"
gradle_path = root / "app/build.gradle.kts"

def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected exactly one match, got {count}")
    return source.replace(old, new, 1)

# 1) Remove the incorrect file-size-vs-free-RAM admission gate. Keep memory as diagnostic data only.
main = main_path.read_text(encoding="utf-8")
old_memory_gate = '''                val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
                val memoryInfo = ActivityManager.MemoryInfo()
                runCatching { manager?.getMemoryInfo(memoryInfo) }
                val safeModelLimit = if (memoryInfo.availMem > 0L && memoryInfo.totalMem > 0L) {
                    minOf(memoryInfo.availMem * 7L / 10L, memoryInfo.totalMem * 50L / 100L)
                } else Long.MAX_VALUE
                AppDiagnostics.log(this@MainActivity, "INFO", "model_load_memory_preflight", "file=${modelFile.name}; bytes=$loadFileSize; available=${memoryInfo.availMem}; total=${memoryInfo.totalMem}; safeEstimate=$safeModelLimit; lowMemory=${memoryInfo.lowMemory}")
                if (loadFileSize > safeModelLimit) {
                    val message = "为降低闪退风险，已暂停加载此模型。模型文件 ${formatBytes(loadFileSize)}，系统可用内存约 ${formatBytes(memoryInfo.availMem)}，保守估算的安全上限约 ${formatBytes(safeModelLimit)}。请关闭后台应用后重试，或选择更小的 GGUF 量化模型。此估算偏保守，不代表模型文件损坏。"
                    AppDiagnostics.finishOperation(this@MainActivity, "model_load", "blocked_memory", message)
                    finishTrackedTask("模型加载", false, message)
                    statusText.text = message
                    showThinking(message, 100)
                    return@launch
                }
                updateTrackedTask("模型加载", "检查文件", "已确认文件存在且非空，准备分析 GGUF 元数据。", null)
'''
new_memory_gate = '''                val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
                val memoryInfo = ActivityManager.MemoryInfo()
                runCatching { manager?.getMemoryInfo(memoryInfo) }
                // Keep memory metrics for diagnosis only. Model file length is not its resident RAM use
                // (GGUF weights are memory-mapped and the OS pages them in on demand), so never reject
                // a model merely because file bytes exceed an estimated free-RAM threshold.
                AppDiagnostics.log(this@MainActivity, "INFO", "model_load_memory_snapshot", "file=${modelFile.name}; fileBytes=$loadFileSize; available=${memoryInfo.availMem}; total=${memoryInfo.totalMem}; lowMemory=${memoryInfo.lowMemory}; admissionGate=disabled")
                updateTrackedTask("模型加载", "检查文件", "记录当前内存状态用于诊断；不会按模型文件大小预先拒绝加载。", null)
'''
main = replace_once(main, old_memory_gate, new_memory_gate, "remove model-size memory admission gate")

# 2) Always initialize the backend loader with nativeLibraryDir so dynamically loaded CPU kernels remain available.
old_backend_init = '''                        val requestedGpuLayers = preferences.getInt("inference_gpu_layers", 0).coerceAtLeast(0)
                        if (requestedGpuLayers > 0) {
                            NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
                        }
                        NativeLlamaEngine.loadModel(
'''
new_backend_init = '''                        // This registers the packaged dynamic CPU backend plugins. It does not enumerate
                        // physical Vulkan devices; native device probing remains conditional on GPU layers > 0.
                        NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
                        val requestedGpuLayers = preferences.getInt("inference_gpu_layers", 0).coerceAtLeast(0)
                        NativeLlamaEngine.loadModel(
'''
main = replace_once(main, old_backend_init, new_backend_init, "initialize dynamic CPU backends in CPU-only mode")

# 3) Keep failure data, clear stale model metadata, and persist a breadcrumb for native inference crashes.
main = replace_once(
    main,
    '''                AppDiagnostics.logThrowable(this@MainActivity, "ERROR", "model_load_exception", "file=${modelFile.name}; bytes=$loadFileSize; ${AppDiagnostics.memorySnapshot(this@MainActivity)}", e)
''',
    '''                AppDiagnostics.logThrowable(this@MainActivity, "ERROR", "model_load_exception", "file=${modelFile.name}; bytes=$loadFileSize; ${AppDiagnostics.memorySnapshot(this@MainActivity)}; nativeLog=${NativeLlamaEngine.lastNativeLogTail().takeLast(6000)}", e)
''',
    "include native diagnostics on model-load exception"
)
main = replace_once(
    main,
    '''                nativeModelHandle = 0L
                loadedModelFileName = null
                statusText.text = "模型加载失败：${e.message ?: "请确认这是受支持的 GGUF 模型"}"
''',
    '''                nativeModelHandle = 0L
                loadedModelFileName = null
                loadedModelProfile = null
                statusText.text = "模型加载失败：${e.message ?: "请确认这是受支持的 GGUF 模型"}"
''',
    "clear stale loaded model profile after failed load"
)

# Mark native inference as an operation too: if SIGSEGV/LMK kills the process, the marker survives to next launch.
main = replace_once(
    main,
    '''                    val streamBuffer = StringBuilder()
                    var lastUiUpdateAt = 0L
                    val raw = try {
''',
    '''                    val streamBuffer = StringBuilder()
                    var lastUiUpdateAt = 0L
                    AppDiagnostics.beginOperation(this@MainActivity, "model_inference", "model=${loadedModelFileName ?: "unknown"}; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; promptChars=${prompt.length}")
                    val raw = try {
''',
    "add native inference crash breadcrumb"
)
main = replace_once(
    main,
    '''                    } catch (e: Exception) {
                        finishTrackedTask("本地模型回答", false, "原生推理失败或已中断：${e.message ?: e.javaClass.simpleName}")
                        throw e
                    }
                    val inferenceSeconds = (android.os.SystemClock.elapsedRealtime() - inferenceStartedAt) / 1000.0
''',
    '''                    } catch (e: Exception) {
                        AppDiagnostics.logThrowable(this@MainActivity, "ERROR", "native_inference_exception", "model=${loadedModelFileName ?: "unknown"}; context=${configuredContextSize()}; ${AppDiagnostics.memorySnapshot(this@MainActivity)}; nativeLog=${NativeLlamaEngine.lastNativeLogTail().takeLast(6000)}", e)
                        AppDiagnostics.finishOperation(this@MainActivity, "model_inference", "failed", "${e.javaClass.simpleName}: ${e.message.orEmpty()}")
                        finishTrackedTask("本地模型回答", false, "原生推理失败或已中断：${e.message ?: e.javaClass.simpleName}")
                        throw e
                    }
                    val nativeFailureMarkers = listOf("无法创建本地推理上下文", "无法初始化 Token 采样器", "模型预填充失败", "GPU 预填充失败", "无法加载此 GGUF 模型")
                    if (nativeFailureMarkers.any { raw.startsWith(it) }) {
                        AppDiagnostics.log(this@MainActivity, "ERROR", "native_inference_reported_error", "message=${raw.take(300)}; nativeLog=${NativeLlamaEngine.lastNativeLogTail().takeLast(4000)}")
                        AppDiagnostics.finishOperation(this@MainActivity, "model_inference", "reported_error", raw.take(300))
                    } else {
                        AppDiagnostics.finishOperation(this@MainActivity, "model_inference", "success", "model=${loadedModelFileName ?: "unknown"}; outputChars=${raw.length}; elapsedMs=${android.os.SystemClock.elapsedRealtime() - inferenceStartedAt}")
                    }
                    val inferenceSeconds = (android.os.SystemClock.elapsedRealtime() - inferenceStartedAt) / 1000.0
''',
    "finish inference breadcrumbs and log native-reported errors"
)
main_path.write_text(main, encoding="utf-8")

# 4) Return captured llama.cpp diagnostics when the native model loader fails.
engine = engine_path.read_text(encoding="utf-8")
engine = replace_once(
    engine,
    '''    fun loadModel(path: String, contextSize: Int, threads: Int, gpuLayers: Int = 0): Long {
        check(isAvailable) { libraryLoadError ?: "原生引擎不可用" }
        return nativeLoadModel(path, contextSize.coerceIn(512, 32768), threads.coerceIn(1, 16), gpuLayers.coerceIn(0, 64))
            .also { check(it != 0L) { "llama.cpp 无法加载此 GGUF 模型；GPU 尝试与 CPU 后备路径均失败。" } }
    }
''',
    '''    fun lastNativeLogTail(): String = if (!isAvailable) {
        libraryLoadError.orEmpty()
    } else runCatching { nativeLastLogTail() }.getOrDefault("")

    fun loadModel(path: String, contextSize: Int, threads: Int, gpuLayers: Int = 0): Long {
        check(isAvailable) { libraryLoadError ?: "原生引擎不可用" }
        val handle = nativeLoadModel(path, contextSize.coerceIn(512, 32768), threads.coerceIn(1, 16), gpuLayers.coerceIn(0, 64))
        if (handle == 0L) {
            val nativeTail = lastNativeLogTail().takeLast(8000)
            val detail = if (nativeTail.isBlank()) "" else "\\n最近 llama.cpp 原生日志：\\n$nativeTail"
            throw IllegalStateException("llama.cpp 无法加载此 GGUF 模型；请检查模型兼容性、后端加载与可用内存。$detail")
        }
        return handle
    }
''',
    "surface llama.cpp logs on model-load failure"
)
engine = replace_once(
    engine,
    '''    private external fun nativeEngineInfo(): String
    private external fun nativeLoadModel(path: String, contextSize: Int, threads: Int, gpuLayers: Int): Long
''',
    '''    private external fun nativeEngineInfo(): String
    private external fun nativeLastLogTail(): String
    private external fun nativeLoadModel(path: String, contextSize: Int, threads: Int, gpuLayers: Int): Long
''',
    "declare native log tail function"
)
engine_path.write_text(engine, encoding="utf-8")

# 5) Harden native log callback and model-load failure reporting.
cpp = cpp_path.read_text(encoding="utf-8")
cpp = replace_once(cpp, "#include <atomic>\n#include <cstdint>", "#include <atomic>\n#include <exception>\n#include <cstdint>", "include explicit std::exception declaration")
old_log_callback = '''void capture_llama_log(enum ggml_log_level /* level */, const char * text, void * /* user_data */) {
    if (text == nullptr || text[0] == '\\0') return;
    std::lock_guard<std::mutex> lock(g_native_log_mutex);
    g_native_log_tail.append(text);
    constexpr size_t kMaxNativeLogChars = 12000;
    if (g_native_log_tail.size() > kMaxNativeLogChars) {
        g_native_log_tail.erase(0, g_native_log_tail.size() - kMaxNativeLogChars);
    }
}
'''
new_log_callback = '''void append_native_log_tail(const char * text) noexcept {
    if (text == nullptr || text[0] == '\\0') return;
    try {
        std::lock_guard<std::mutex> lock(g_native_log_mutex);
        g_native_log_tail.append(text);
        constexpr size_t kMaxNativeLogChars = 12000;
        if (g_native_log_tail.size() > kMaxNativeLogChars) {
            g_native_log_tail.erase(0, g_native_log_tail.size() - kMaxNativeLogChars);
        }
    } catch (...) {
        // Never allow diagnostics allocation failure to escape through a C logging callback.
    }
}

void record_native_event(int priority, const std::string & message) noexcept {
    append_native_log_tail(message.c_str());
    append_native_log_tail("\\n");
    __android_log_print(priority, kLogTag, "%s", message.c_str());
}

void capture_llama_log(enum ggml_log_level /* level */, const char * text, void * /* user_data */) {
    append_native_log_tail(text);
}
'''
cpp = replace_once(cpp, old_log_callback, new_log_callback, "make native log callback exception-safe")

native_load_anchor = '''        session->model = load_with_layers(chosen_layers);
        if (session->model == nullptr && chosen_layers > 0) {
            __android_log_print(ANDROID_LOG_WARN, kLogTag, "GPU model-load path failed; retrying CPU-only.");
            session->cpu_retry_used = true;
            chosen_layers = 0;
            session->model = load_with_layers(0);
        }
        if (session->model == nullptr) return 0;

        session->active_gpu_layers = chosen_layers;
'''
native_load_replacement = '''        record_native_event(ANDROID_LOG_INFO,
            "model_load_begin context=" + std::to_string(session->context_size) +
            " threads=" + std::to_string(session->threads) +
            " requested_gpu_layers=" + std::to_string(session->requested_gpu_layers));
        session->model = load_with_layers(chosen_layers);
        if (session->model == nullptr && chosen_layers > 0) {
            record_native_event(ANDROID_LOG_WARN, "GPU model-load path failed; retrying CPU-only.");
            session->cpu_retry_used = true;
            chosen_layers = 0;
            session->model = load_with_layers(0);
        }
        if (session->model == nullptr) {
            record_native_event(ANDROID_LOG_ERROR, "llama_model_load_from_file returned null; model loading failed. Check the captured llama.cpp log tail.");
            return 0;
        }

        session->active_gpu_layers = chosen_layers;
'''
cpp = replace_once(cpp, native_load_anchor, native_load_replacement, "record native model load outcomes")
cpp = replace_once(
    cpp,
    '''        return register_session(session);
    } catch (...) {
        return 0;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeGenerate''',
    '''        record_native_event(ANDROID_LOG_INFO, "model_load_success active_gpu_layers_config=" + std::to_string(session->active_gpu_layers));
        return register_session(session);
    } catch (const std::exception & error) {
        record_native_event(ANDROID_LOG_ERROR, std::string("nativeLoadModel exception: ") + error.what());
        return 0;
    } catch (...) {
        record_native_event(ANDROID_LOG_ERROR, "nativeLoadModel failed with an unknown native exception.");
        return 0;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeGenerate''',
    "capture native model loader exceptions"
)

# Expose only the bounded in-memory llama.cpp tail; it never contains chat prompt text by design.
cpp = replace_once(
    cpp,
    '''extern "C" JNIEXPORT jlong JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLoadModel''',
    '''extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLastLogTail(JNIEnv * env, jobject /* thiz */) {
    try { return to_java_string(env, native_log_snapshot()); }
    catch (...) { return to_java_string(env, "读取原生日志失败"); }
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLoadModel''',
    "add bounded native log tail JNI endpoint"
)

# 6) Reduce transient inference workspace from context-sized batches without reducing n_ctx or truncating more context.
cpp = replace_once(
    cpp,
    '''        ctx_params.n_ctx = static_cast<uint32_t>(session->context_size);
        ctx_params.n_batch = static_cast<uint32_t>(session->context_size);
        ctx_params.n_ubatch = std::min<uint32_t>(ctx_params.n_ubatch, ctx_params.n_batch);
''',
    '''        ctx_params.n_ctx = static_cast<uint32_t>(session->context_size);
        // Keep the full requested context/KV capacity, but bound each prompt prefill batch.
        // Chunked prefill below avoids allocating a context-sized compute batch for long prompts.
        ctx_params.n_batch = static_cast<uint32_t>(std::min(session->context_size, 512));
        ctx_params.n_ubatch = std::min<uint32_t>(ctx_params.n_ubatch, ctx_params.n_batch);
''',
    "bound transient prefill batch while preserving context size"
)

old_sampler_init = '''        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
        if (sampler == nullptr) {
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, "无法初始化 Token 采样器。");
        }
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

        llama_batch batch = llama_batch_get_one(prompt_tokens.data(), static_cast<int32_t>(prompt_tokens.size()));
        const int32_t prefill_result = llama_decode(ctx, batch);
        if (prefill_result != 0) {
            if (session->active_gpu_layers > 0) {
                llama_sampler_free(sampler); sampler = nullptr;
                llama_free(ctx); ctx = nullptr;
                return to_java_string(env, "__DONGBAKE_GPU_RETRY_CPU__");
            }
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, "模型预填充失败（llama_decode=" + std::to_string(prefill_result) + "）。");
        }
'''
new_sampler_init = '''        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
        if (sampler == nullptr) {
            record_native_event(ANDROID_LOG_ERROR, "llama_sampler_chain_init returned null.");
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, "无法初始化 Token 采样器。");
        }
        llama_sampler * temp_sampler = llama_sampler_init_temp(0.7f);
        llama_sampler * dist_sampler = llama_sampler_init_dist(LLAMA_DEFAULT_SEED);
        if (temp_sampler == nullptr || dist_sampler == nullptr) {
            if (temp_sampler) llama_sampler_free(temp_sampler);
            if (dist_sampler) llama_sampler_free(dist_sampler);
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            record_native_event(ANDROID_LOG_ERROR, "A llama sampler could not be allocated.");
            return to_java_string(env, "无法分配 Token 采样器，可能是内存不足。");
        }
        llama_sampler_chain_add(sampler, temp_sampler);
        llama_sampler_chain_add(sampler, dist_sampler);

        int32_t prefill_result = 0;
        size_t prefill_offset = 0;
        while (prefill_offset < prompt_tokens.size()) {
            if (session->cancelled.load(std::memory_order_acquire)) break;
            const size_t chunk_count = std::min<size_t>(ctx_params.n_batch, prompt_tokens.size() - prefill_offset);
            llama_batch prompt_batch = llama_batch_get_one(
                prompt_tokens.data() + prefill_offset, static_cast<int32_t>(chunk_count));
            prefill_result = llama_decode(ctx, prompt_batch);
            if (prefill_result != 0) break;
            prefill_offset += chunk_count;
        }
        if (session->cancelled.load(std::memory_order_acquire)) {
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, answer);
        }
        if (prefill_result != 0) {
            record_native_event(ANDROID_LOG_ERROR, "Prompt prefill failed with llama_decode=" + std::to_string(prefill_result));
            if (session->active_gpu_layers > 0) {
                llama_sampler_free(sampler); sampler = nullptr;
                llama_free(ctx); ctx = nullptr;
                return to_java_string(env, "__DONGBAKE_GPU_RETRY_CPU__");
            }
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, "模型预填充失败（llama_decode=" + std::to_string(prefill_result) + "）。");
        }
'''
cpp = replace_once(cpp, old_sampler_init, new_sampler_init, "chunk long prompt prefill and check sampler allocations")

# Reuse token-piece buffer rather than allocating a vector on every generated token.
cpp = replace_once(
    cpp,
    '''        jmethodID on_token = listener_class ? env->GetMethodID(listener_class, "onToken", "(Ljava/lang/String;)V") : nullptr;
        for (int32_t generated = 0; generated < output_limit; ++generated) {
''',
    '''        jmethodID on_token = listener_class ? env->GetMethodID(listener_class, "onToken", "(Ljava/lang/String;)V") : nullptr;
        std::vector<char> piece_buffer(256, '\\0');
        for (int32_t generated = 0; generated < output_limit; ++generated) {
''',
    "allocate token conversion buffer once per inference"
)
cpp = replace_once(
    cpp,
    '''            std::vector<char> piece_buffer(256, '\\0');
            int32_t piece_size = llama_token_to_piece(vocab, token, piece_buffer.data(), static_cast<int32_t>(piece_buffer.size()), 0, false);
''',
    '''            std::fill(piece_buffer.begin(), piece_buffer.end(), '\\0');
            if (piece_buffer.size() < 256) piece_buffer.resize(256);
            int32_t piece_size = llama_token_to_piece(vocab, token, piece_buffer.data(), static_cast<int32_t>(piece_buffer.size()), 0, false);
''',
    "reuse token conversion buffer inside generation loop"
)

# Record explicit context/decode failures and caught C++ exceptions in the exported native tail.
cpp = replace_once(
    cpp,
    '''        if (ctx == nullptr) {
            if (session->active_gpu_layers > 0) return to_java_string(env, "__DONGBAKE_GPU_RETRY_CPU__");
            return to_java_string(env, "无法创建本地推理上下文，可能是内存不足或模型与上下文设置不兼容。");
        }
''',
    '''        if (ctx == nullptr) {
            record_native_event(ANDROID_LOG_ERROR, "llama_init_from_model returned null; contextSize=" + std::to_string(session->context_size));
            if (session->active_gpu_layers > 0) return to_java_string(env, "__DONGBAKE_GPU_RETRY_CPU__");
            return to_java_string(env, "无法创建本地推理上下文，可能是内存不足或模型与上下文设置不兼容。");
        }
''',
    "log context initialization failures"
)
cpp = replace_once(
    cpp,
    '''                if (decode_result != 0) {
                    __android_log_print(ANDROID_LOG_WARN, kLogTag, "Decode stopped with result=%d after %d tokens.", decode_result, generated + 1);
                    break;
                }
''',
    '''                if (decode_result != 0) {
                    record_native_event(ANDROID_LOG_WARN, "Decode stopped with result=" + std::to_string(decode_result) + " after " + std::to_string(generated + 1) + " tokens.");
                    break;
                }
''',
    "store token decode failures in diagnostics tail"
)
cpp = replace_once(
    cpp,
    '''    } catch (...) {
        __android_log_print(ANDROID_LOG_ERROR, kLogTag, "Unhandled native inference exception.");
    }
''',
    '''    } catch (const std::exception & error) {
        record_native_event(ANDROID_LOG_ERROR, std::string("Native inference exception: ") + error.what());
    } catch (...) {
        record_native_event(ANDROID_LOG_ERROR, "Unhandled native inference exception.");
    }
''',
    "record native inference exceptions safely"
)
cpp_path.write_text(cpp, encoding="utf-8")

# 7) Increment app version and keep source-level regression tests in sync.
gradle = gradle_path.read_text(encoding="utf-8")
gradle = replace_once(gradle, "versionCode = 25", "versionCode = 26", "increment versionCode")
gradle = replace_once(gradle, 'versionName = "0.10.3"', 'versionName = "0.10.4"', "increment versionName")
gradle_path.write_text(gradle, encoding="utf-8")

for test_name in ("test_native_build_setup.py", "test_progress_audit.py"):
    p = root / "tests" / test_name
    source = p.read_text(encoding="utf-8")
    source = source.replace(r"versionCode\s*=\s*25\b", r"versionCode\s*=\s*26\b")
    source = source.replace('versionName = "0.10.3"', 'versionName = "0.10.4"')
    p.write_text(source, encoding="utf-8")

test_native = root / "tests" / "test_native_build_setup.py"
test_source = test_native.read_text(encoding="utf-8")
test_source = test_source.replace('self.assertIn("llama_decode(ctx, batch)", cpp)', 'self.assertIn("llama_decode(ctx, prompt_batch)", cpp)')
test_native.write_text(test_source, encoding="utf-8")

new_tests = r'''"""Regression checks for source-26 model loading stability. These complement Android/NDK builds."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt"
ENGINE = ROOT / "app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt"
CPP = ROOT / "app/src/main/cpp/dongbake_llama_jni.cpp"
GRADLE = ROOT / "app/build.gradle.kts"


class StabilityRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = MAIN.read_text(encoding="utf-8")
        cls.engine = ENGINE.read_text(encoding="utf-8")
        cls.cpp = CPP.read_text(encoding="utf-8")
        cls.gradle = GRADLE.read_text(encoding="utf-8")

    def test_model_file_size_never_blocks_loading(self):
        self.assertNotIn("safeModelLimit", self.main)
        self.assertNotIn("model_load_memory_preflight", self.main)
        self.assertIn('"model_load_memory_snapshot"', self.main)
        self.assertIn("admissionGate=disabled", self.main)

    def test_dynamic_cpu_backend_is_initialized_without_gpu_offload(self):
        load_pos = self.main.index('val requestedGpuLayers = preferences.getInt("inference_gpu_layers", 0)')
        before = self.main[max(0, load_pos - 450):load_pos]
        self.assertIn("NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)", before)

    def test_context_is_preserved_and_prompt_prefill_is_chunked(self):
        self.assertIn("ctx_params.n_ctx = static_cast<uint32_t>(session->context_size)", self.cpp)
        self.assertIn("ctx_params.n_batch = static_cast<uint32_t>(std::min(session->context_size, 512))", self.cpp)
        self.assertIn("while (prefill_offset < prompt_tokens.size())", self.cpp)
        self.assertIn("prompt_tokens.data() + prefill_offset", self.cpp)

    def test_native_load_log_tail_surfaces_into_app_diagnostics(self):
        self.assertIn("nativeLastLogTail", self.engine)
        self.assertIn("nativeLastLogTail", self.cpp)
        self.assertIn('"model_load_exception"', self.main)
        self.assertIn('"native_inference_exception"', self.main)
        self.assertIn('"model_inference"', self.main)

    def test_native_log_callback_cannot_throw_into_upstream_c_code(self):
        self.assertIn("void append_native_log_tail(const char * text) noexcept", self.cpp)
        self.assertIn("Never allow diagnostics allocation failure to escape", self.cpp)

    def test_new_version_preserves_application_id(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', self.gradle)
        self.assertRegex(self.gradle, r'versionCode\\s*=\\s*26\\b')
        self.assertIn('versionName = "0.10.4"', self.gradle)


if __name__ == "__main__":
    unittest.main()
'''
new_tests = new_tests.replace("\\\\s", "\\s").replace("\\\\b", "\\b")
(root / "tests" / "test_stability_regression.py").write_text(new_tests, encoding="utf-8")

for required in (
    'versionCode = 26', 'versionName = "0.10.4"',
    '"model_load_memory_snapshot"', 'while (prefill_offset < prompt_tokens.size())',
    'nativeLastLogTail', 'model_inference',
):
    combined = main_path.read_text(encoding="utf-8") + engine_path.read_text(encoding="utf-8") + cpp_path.read_text(encoding="utf-8") + gradle_path.read_text(encoding="utf-8")
    if required not in combined:
        raise SystemExit("Post-patch assertion failed: " + required)

print("Patched source revision 26 / v0.10.4:")
print("- removed false model-file-size memory gate")
print("- restored dynamic CPU backend initialization for CPU-first loading")
print("- added native model/inference log-tail diagnostics and abrupt-exit breadcrumbs")
print("- bounded prompt prefill batches at 512 tokens while preserving configured context size")
print("- hardened native log/sampler failure handling and updated regression tests")
