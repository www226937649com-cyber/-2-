#!/usr/bin/env python3
"""Patch DongBaKe source-26 into source-27 with explicit CPU mmap + crash diagnostics."""
from pathlib import Path
import re
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else "buildsrc")
app = root / "app/src/main/java/com/aiguanjia/app"
main_path = app / "MainActivity.kt"
engine_path = app / "NativeLlamaEngine.kt"
logger_path = app / "AppDiagnostics.kt"
cpp_path = root / "app/src/main/cpp/dongbake_llama_jni.cpp"
gradle_path = root / "app/build.gradle.kts"
profile_path = app / "ModelProfileAnalyzer.kt"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{label}: expected exactly one match, found {n}")
    return text.replace(old, new, 1)

# 1) Device- and exit-aware diagnostics: Android can report native crashes and LMK kills
# on the next startup; retain a small preview of the system trace when available.
logger = logger_path.read_text(encoding="utf-8")
logger = replace_once(
    logger,
    "import android.app.ActivityManager\n",
    "import android.app.ActivityManager\nimport android.app.ApplicationExitInfo\n",
    "import ApplicationExitInfo",
)
logger = replace_once(
    logger,
    '    private const val MAX_BYTES = 512L * 1024L\n',
    '    private const val MAX_BYTES = 512L * 1024L\n    private const val EXIT_PREFS = "dongbake-diagnostic-state"\n    private const val EXIT_TS_KEY = "last_recorded_exit_timestamp"\n',
    "add exit history preference keys",
)
logger = replace_once(
    logger,
    '''        synchronized(lock) {
            val marker = File(app.filesDir, MARKER)
''',
    '''        synchronized(lock) {
            recordRecentProcessExitsLocked(app)
            val marker = File(app.filesDir, MARKER)
''',
    "capture historical process exits before active-operation marker",
)
logger = replace_once(
    logger,
    '''            writeLocked(app, "INFO", "startup",
                "启动 Android=${Build.VERSION.RELEASE}/API${Build.VERSION.SDK_INT}; device=${Build.MANUFACTURER} ${Build.MODEL}; " +
                "ABI=${Build.SUPPORTED_ABIS.joinToString(",")}; version=${version(app)}; ${memorySnapshot(app)}")
''',
    '''            val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "API<31 (SoC API unavailable)"
            writeLocked(app, "INFO", "startup",
                "启动 Android=${Build.VERSION.RELEASE}/API${Build.VERSION.SDK_INT}; device=${Build.MANUFACTURER} ${Build.MODEL}; " +
                "deviceCode=${Build.DEVICE}; hardware=${Build.HARDWARE}; board=${Build.BOARD}; soc=$soc; " +
                "ABI=${Build.SUPPORTED_ABIS.joinToString(",")}; version=${version(app)}; ${memorySnapshot(app)}; ${processMemorySnapshot()}")
''',
    "record full device and per-process memory snapshot",
)
logger = replace_once(
    logger,
    '''    fun memorySnapshot(context: Context): String = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        "available=${info.availMem}; total=${info.totalMem}; lowMemory=${info.lowMemory}; vmMax=${Runtime.getRuntime().maxMemory()}; nativeHeap=${android.os.Debug.getNativeHeapAllocatedSize()}"
    }.getOrDefault("memorySnapshot=unavailable")
''',
    '''    fun memorySnapshot(context: Context): String = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        "available=${info.availMem}; total=${info.totalMem}; lowMemory=${info.lowMemory}; " +
            "vmMax=${Runtime.getRuntime().maxMemory()}; nativeHeap=${android.os.Debug.getNativeHeapAllocatedSize()}"
    }.getOrDefault("memorySnapshot=unavailable")

    private fun processMemorySnapshot(): String = runCatching {
        val status = File("/proc/self/status").takeIf { it.canRead() }?.readText().orEmpty()
        val keys = listOf("VmRSS", "VmHWM", "VmSize", "VmPeak", "VmSwap")
        val values = status.lineSequence().filter { line -> keys.any { line.startsWith("$it:") } }.joinToString(";")
        val cgCurrent = File("/sys/fs/cgroup/memory.current").takeIf { it.canRead() }?.readText()?.trim()
        val cgMax = File("/sys/fs/cgroup/memory.max").takeIf { it.canRead() }?.readText()?.trim()
        "procStatus=[$values]; cgroupMemoryCurrent=${cgCurrent ?: "n/a"}; cgroupMemoryMax=${cgMax ?: "n/a"}"
    }.getOrDefault("processMemorySnapshot=unavailable")

    private fun recordRecentProcessExitsLocked(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        runCatching {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val prefs = context.getSharedPreferences(EXIT_PREFS, Context.MODE_PRIVATE)
            val lastTimestamp = prefs.getLong(EXIT_TS_KEY, 0L)
            val exits = manager.getHistoricalProcessExitReasons(context.packageName, 0, 8)
                .filter { it.processName == context.packageName || it.processName.startsWith(context.packageName + ":") }
                .sortedBy { it.timestamp }
            for (exit in exits) {
                if (exit.timestamp <= lastTimestamp) continue
                val reason = when (exit.reason) {
                    ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
                    ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY"
                    ApplicationExitInfo.REASON_CRASH -> "JAVA_CRASH"
                    ApplicationExitInfo.REASON_SIGNALED -> "OS_SIGNAL"
                    ApplicationExitInfo.REASON_ANR -> "ANR"
                    ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE_USAGE"
                    ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
                    ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
                    ApplicationExitInfo.REASON_USER_STOPPED -> "USER_STOPPED"
                    else -> "OTHER_${exit.reason}"
                }
                writeLocked(context, "FATAL", "previous_process_exit",
                    "timestamp=${exit.timestamp}; reason=$reason; status=${exit.status}; importance=${exit.importance}; " +
                    "process=${exit.processName}; pssKB=${exit.pss}; rssKB=${exit.rss}; description=${exit.description.orEmpty().take(2000)}")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val traceText = runCatching {
                        val stream = exit.traceInputStream ?: return@runCatching ""
                        val out = java.io.ByteArrayOutputStream()
                        stream.use { input ->
                            val buffer = ByteArray(4096)
                            var remaining = 65536
                            while (remaining > 0) {
                                val read = input.read(buffer, 0, minOf(buffer.size, remaining))
                                if (read <= 0) break
                                out.write(buffer, 0, read)
                                remaining -= read
                            }
                        }
                        val raw = out.toByteArray().toString(Charsets.ISO_8859_1)
                        Regex("[ -~]{8,}").findAll(raw).map { it.value.trim() }
                            .filter { it.contains("/", true) || it.contains("signal", true) || it.contains("fault", true) || it.contains("crash", true) || it.contains("DongBaKe", true) || it.contains("llama", true) }
                            .distinct().take(45).joinToString(" | ").take(6000)
                    }.getOrDefault("")
                    if (traceText.isNotBlank()) writeLocked(context, "FATAL", "previous_exit_trace_preview", traceText)
                }
            }
            val newest = exits.maxOfOrNull { it.timestamp } ?: lastTimestamp
            if (newest > lastTimestamp) prefs.edit().putLong(EXIT_TS_KEY, newest).apply()
        }.onFailure { writeLocked(context, "WARN", "process_exit_history_unavailable", it.javaClass.simpleName + ": " + it.message.orEmpty()) }
    }
''',
    "add ApplicationExitInfo plus native trace preview",
)
logger_path.write_text(logger, encoding="utf-8")

# 2) Expose a clear-tail call so the native log collector begins at this attempt, not stale logs.
engine = engine_path.read_text(encoding="utf-8")
engine = replace_once(
    engine,
    '''    fun lastNativeLogTail(): String = if (!isAvailable) {
        libraryLoadError.orEmpty()
    } else runCatching { nativeLastLogTail() }.getOrDefault("")
''',
    '''    fun lastNativeLogTail(): String = if (!isAvailable) {
        libraryLoadError.orEmpty()
    } else runCatching { nativeLastLogTail() }.getOrDefault("")

    fun clearNativeLogTail() {
        if (isAvailable) runCatching { nativeClearLogTail() }
    }
''',
    "expose native log clear method",
)
engine = replace_once(
    engine,
    '''    private external fun nativeLastLogTail(): String
''',
    '''    private external fun nativeLastLogTail(): String
    private external fun nativeClearLogTail()
''',
    "declare native clear-tail JNI method",
)
engine_path.write_text(engine, encoding="utf-8")

# 3) Persist the native logger tail while JNI model loading is still in progress.
main = main_path.read_text(encoding="utf-8")
main = replace_once(
    main,
    'import kotlinx.coroutines.CancellationException\n',
    'import kotlinx.coroutines.CancellationException\nimport kotlinx.coroutines.cancelAndJoin\n',
    "import cancelAndJoin",
)
main = replace_once(
    main,
    '''        AppDiagnostics.log(this, "INFO", "model_load_configuration", "file=${modelFile.name}; bytes=$loadFileSize; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; gpuLayersDefault=0; ${AppDiagnostics.memorySnapshot(this)}")
''',
    '''        AppDiagnostics.log(this, "INFO", "model_load_configuration", "file=${modelFile.name}; path=${modelFile.absolutePath}; bytes=$loadFileSize; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; requestedGpuLayers=${preferences.getInt("inference_gpu_layers", 0)}; ${AppDiagnostics.memorySnapshot(this)}; ${AppDiagnostics.deviceSnapshot(this)}; ${AppDiagnostics.processSnapshot()}")
''',
    "enrich load configuration with device and process snapshot",
)
# Add public helpers in AppDiagnostics called from MainActivity.
logger = logger_path.read_text(encoding="utf-8")
logger = replace_once(
    logger,
    '''    private fun processMemorySnapshot(): String = runCatching {
''',
    '''    fun deviceSnapshot(context: Context): String = runCatching {
        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "unknown (API<31)"
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        "manufacturer=${Build.MANUFACTURER}; model=${Build.MODEL}; device=${Build.DEVICE}; hardware=${Build.HARDWARE}; board=${Build.BOARD}; soc=$soc; abi=${Build.SUPPORTED_ABIS.joinToString(",")}; totalMem=${info.totalMem}; availableMem=${info.availMem}"
    }.getOrDefault("deviceSnapshot=unavailable")

    fun processSnapshot(): String = processMemorySnapshot()

    private fun processMemorySnapshot(): String = runCatching {
''',
    "expose device/process snapshot helpers",
)
logger_path.write_text(logger, encoding="utf-8")

# Record parsed architecture/quantization and ensure native logs are flushed to disk during a crash.
main = replace_once(
    main,
    '''                loadedModelProfile = profile
                responseModeIndex = responseModeIndex.coerceAtMost(profile.modeLabels.lastIndex)
''',
    '''                loadedModelProfile = profile
                AppDiagnostics.log(this@MainActivity, "INFO", "model_load_profile", "name=${profile.displayName}; architecture=${profile.architecture}; quantization=${profile.quantizationHint}; ggufVersion=${profile.ggufVersion}; tensorCount=${profile.tensorCount}; metadataCount=${profile.metadataCount}; parameterCount=${profile.parameterCount}; chatTemplate=${profile.hasChatTemplate}; modelBytes=${profile.modelBytes}")
                responseModeIndex = responseModeIndex.coerceAtMost(profile.modeLabels.lastIndex)
''',
    "record exact model metadata before native loading",
)
old_native_block = '''                val loadedHandle = try {
                    withContext(Dispatchers.IO) {
                        // This registers the packaged dynamic CPU backend plugins. It does not enumerate
                        // physical Vulkan devices; native device probing remains conditional on GPU layers > 0.
                        NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
                        val requestedGpuLayers = preferences.getInt("inference_gpu_layers", 0).coerceAtLeast(0)
                        NativeLlamaEngine.loadModel(
                            path = path,
                            contextSize = contextSize,
                            threads = cpuThreads,
                            gpuLayers = requestedGpuLayers
                        )
                    }
                } finally {
                    modelLoadTicker?.cancel()
                    modelLoadTicker = null
                }
'''
new_native_block = '''                NativeLlamaEngine.clearNativeLogTail()
                val nativeLogCollector = lifecycleScope.launch(Dispatchers.IO) {
                    var previousTail = ""
                    while (kotlin.coroutines.coroutineContext[kotlinx.coroutines.Job]?.isActive == true) {
                        val currentTail = NativeLlamaEngine.lastNativeLogTail()
                        if (currentTail.isNotBlank() && currentTail != previousTail) {
                            val delta = when {
                                previousTail.isBlank() -> currentTail.takeLast(5000)
                                currentTail.startsWith(previousTail) -> currentTail.substring(previousTail.length).takeLast(5000)
                                else -> {
                                    val probe = previousTail.takeLast(1024)
                                    val overlapAt = if (probe.length >= 256) currentTail.indexOf(probe) else -1
                                    if (overlapAt >= 0) currentTail.substring(overlapAt + probe.length).takeLast(5000) else currentTail.takeLast(2500)
                                }
                            }
                            if (delta.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "llama_cpp", delta)
                            previousTail = currentTail
                        }
                        delay(250)
                    }
                }
                val loadedHandle = try {
                    withContext(Dispatchers.IO) {
                        AppDiagnostics.log(this@MainActivity, "INFO", "native_backend_init_begin", "nativeLibraryDir=${applicationInfo.nativeLibraryDir}; GPU device enumeration is disabled for CPU-only load mode.")
                        NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
                        AppDiagnostics.log(this@MainActivity, "INFO", "native_backend_init_complete", "${NativeLlamaEngine.lastNativeLogTail().takeLast(3000)}")
                        val requestedGpuLayers = preferences.getInt("inference_gpu_layers", 0).coerceAtLeast(0)
                        AppDiagnostics.log(this@MainActivity, "INFO", "native_model_load_call", "path=$path; bytes=$loadFileSize; context=$contextSize; threads=$cpuThreads; gpuLayers=$requestedGpuLayers; loadMode=${if (requestedGpuLayers == 0) "MMAP (file-backed CPU weights)" else "AUTO (GPU path)"}")
                        NativeLlamaEngine.loadModel(
                            path = path,
                            contextSize = contextSize,
                            threads = cpuThreads,
                            gpuLayers = requestedGpuLayers
                        )
                    }
                } finally {
                    nativeLogCollector.cancelAndJoin()
                    val finalNativeTail = withContext(Dispatchers.IO) { NativeLlamaEngine.lastNativeLogTail() }
                    if (finalNativeTail.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "native_load_final_tail", finalNativeTail.takeLast(8000))
                    modelLoadTicker?.cancel()
                    modelLoadTicker = null
                }
'''
main = replace_once(main, old_native_block, new_native_block, "add durable native log collector around blocking load")
# Device details on the app-version page; only read public Android API information.
main = replace_once(
    main,
    '''        append("APK 原生架构：").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\\n')
        append("当前设备：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
''',
    '''        append("当前 APK 原生架构：").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\\n')
        append("设备代号：").append(Build.DEVICE).append('\\n')
        append("硬件平台：").append(Build.HARDWARE).append('\\n')
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) append("SoC：").append(Build.SOC_MANUFACTURER).append(' ').append(Build.SOC_MODEL).append('\\n')
        append("物理内存总量：").append(formatBytes(AppDiagnostics.memoryTotalBytes(this@MainActivity))).append('\\n')
        append("当前设备：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
''',
    "show actual chipset and RAM in app version page",
)
main_path.write_text(main, encoding="utf-8")

# Provide a public total-RAM helper without using model file size as a loading gate.
logger = logger_path.read_text(encoding="utf-8")
logger = replace_once(
    logger,
    '''    fun deviceSnapshot(context: Context): String = runCatching {
''',
    '''    fun memoryTotalBytes(context: Context): Long = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        info.totalMem
    }.getOrDefault(0L)

    fun deviceSnapshot(context: Context): String = runCatching {
''',
    "add total RAM helper",
)
logger_path.write_text(logger, encoding="utf-8")

# Model profile fallback should recognize the newer qwen35 architecture when metadata is absent.
profile = profile_path.read_text(encoding="utf-8")
profile = replace_once(profile, '        "qwen3", "qwen2", "qwen",', '        "qwen35", "qwen3", "qwen2", "qwen",', "recognize qwen35 architecture")
profile_path.write_text(profile, encoding="utf-8")

# 4) Persist clearNativeLogTail JNI API; no change to token generation or chat API.
cpp = cpp_path.read_text(encoding="utf-8")
cpp = replace_once(
    cpp,
    '''extern "C" JNIEXPORT jlong JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLoadModel''',
    '''extern "C" JNIEXPORT void JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeClearLogTail(JNIEnv * /* env */, jobject /* thiz */) {
    try {
        std::lock_guard<std::mutex> lock(g_native_log_mutex);
        g_native_log_tail.clear();
    } catch (...) {
        __android_log_print(ANDROID_LOG_WARN, kLogTag, "Could not clear native log tail.");
    }
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLoadModel''',
    "implement native log-tail clear JNI method",
)
cpp = replace_once(
    cpp,
    '''        auto load_with_layers = [&](int layers) -> llama_model * {
            llama_model_params params = llama_model_default_params();
            params.n_gpu_layers = layers;
            return llama_model_load_from_file(path.c_str(), params);
        };
''',
    '''        auto load_with_layers = [&](int layers) -> llama_model * {
            llama_model_params params = llama_model_default_params();
            params.n_gpu_layers = layers;
            // IMPORTANT for Android CPU mode: AUTO inspects every registered device and may
            // disable mmap because an unused Vulkan device does not advertise mmap support.
            // That can turn a 2.8 GB file-backed model into a multi-GB resident allocation.
            // CPU-only loading explicitly forces mmap; GPU-offload requests retain AUTO behavior.
            params.load_mode = layers == 0 ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_AUTO;
            record_native_event(ANDROID_LOG_INFO,
                std::string("model_load_params layers=") + std::to_string(layers) +
                " load_mode=" + (layers == 0 ? "MMAP" : "AUTO") +
                " use_extra_bufts=" + (params.use_extra_bufts ? "true" : "false"));
            return llama_model_load_from_file(path.c_str(), params);
        };
''',
    "force file-backed mmap for CPU-only model loading",
)
cpp = replace_once(
    cpp,
    '''        record_native_event(ANDROID_LOG_INFO,
            "model_load_begin context=" + std::to_string(session->context_size) +
            " threads=" + std::to_string(session->threads) +
            " requested_gpu_layers=" + std::to_string(session->requested_gpu_layers));
''',
    '''        record_native_event(ANDROID_LOG_INFO,
            "model_load_begin context=" + std::to_string(session->context_size) +
            " threads=" + std::to_string(session->threads) +
            " requested_gpu_layers=" + std::to_string(session->requested_gpu_layers) +
            " file=" + path);
''',
    "include model path in native load breadcrumb",
)
cpp_path.write_text(cpp, encoding="utf-8")

# Version bump and existing test expectations.
gradle = gradle_path.read_text(encoding="utf-8")
gradle = replace_once(gradle, "versionCode = 26", "versionCode = 27", "bump version code")
gradle = replace_once(gradle, 'versionName = "0.10.4"', 'versionName = "0.10.5"', "bump version name")
gradle_path.write_text(gradle, encoding="utf-8")
for name in ("test_native_build_setup.py", "test_progress_audit.py", "test_stability_regression.py"):
    p = root / "tests" / name
    test = p.read_text(encoding="utf-8")
    test = test.replace(r"versionCode\s*=\s*26\b", r"versionCode\s*=\s*27\b")
    test = test.replace('versionName = "0.10.4"', 'versionName = "0.10.5"')
    if name == "test_stability_regression.py":
        test = test.replace("source-26 model loading stability", "source-27 Redmi Note 11T Pro model loading stability")
        test = test.replace('self.assertIn("admissionGate=disabled", self.main)', 'self.assertIn("admissionGate=disabled", self.main)')
        insert = '''
    def test_cpu_only_model_loading_forces_file_backed_mmap(self):
        self.assertIn("params.load_mode = layers == 0 ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_AUTO", self.cpp)
        self.assertIn("forces mmap", self.cpp.lower())

    def test_native_log_tail_is_collected_while_model_load_blocks(self):
        self.assertIn("nativeLogCollector = lifecycleScope.launch(Dispatchers.IO)", self.main)
        self.assertIn("cancelAndJoin()", self.main)
        self.assertIn("nativeClearLogTail", self.engine)

    def test_android_exit_history_is_persisted_after_native_crash_or_lmk(self):
        self.assertIn("getHistoricalProcessExitReasons", (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8"))
        self.assertIn("REASON_CRASH_NATIVE", (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8"))
        self.assertIn("REASON_LOW_MEMORY", (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8"))
'''
        marker = '\n\nif __name__ == "__main__":'
        test = replace_once(test, marker, insert + marker, "add source-27 regression tests")
    p.write_text(test, encoding="utf-8")

# Audit assertions before archiving.
main = main_path.read_text(encoding="utf-8")
engine = engine_path.read_text(encoding="utf-8")
logger = logger_path.read_text(encoding="utf-8")
cpp = cpp_path.read_text(encoding="utf-8")
gradle = gradle_path.read_text(encoding="utf-8")
assertions = [
    ('versionCode = 27', gradle),
    ('versionName = "0.10.5"', gradle),
    ('params.load_mode = layers == 0 ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_AUTO', cpp),
    ('nativeLogCollector = lifecycleScope.launch(Dispatchers.IO)', main),
    ('nativeClearLogTail', engine + cpp),
    ('getHistoricalProcessExitReasons', logger),
    ('REASON_CRASH_NATIVE', logger),
    ('REASON_LOW_MEMORY', logger),
    ('architecture=${profile.architecture}', main),
    ('"qwen35"', profile_path.read_text(encoding="utf-8")),
]
for expected, contents in assertions:
    if expected not in contents:
        raise SystemExit(f"Post-patch assertion failed: {expected}")
print("Patched source revision 27 / v0.10.5:")
print("- explicitly file-mapped CPU model weights, preventing unused Vulkan devices from disabling mmap under AUTO")
print("- streams native llama.cpp log tail to disk while loading is in progress")
print("- records Android ApplicationExitInfo (native crash/low memory), device SoC and process memory")
print("- preserves model loading feature; no file-size admission gate added")
