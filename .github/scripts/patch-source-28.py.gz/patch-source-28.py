#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else 'buildsrc')
main_path = root / 'app/src/main/java/com/aiguanjia/app/MainActivity.kt'
cpp_path = root / 'app/src/main/cpp/dongbake_llama_jni.cpp'
gradle_path = root / 'app/build.gradle.kts'

def replace_once(source, old, new, label):
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected exactly one match, got {count}')
    return source.replace(old, new, 1)

cpp = cpp_path.read_text(encoding='utf-8')
cpp = replace_once(cpp,
'''    try {
        const std::string formatted = apply_chat_template(session.get(), system_prompt, raw_prompt);
        const llama_vocab * vocab = llama_model_get_vocab(session->model);
        std::vector<llama_token> prompt_tokens;
        if (!tokenise_prompt(vocab, formatted, prompt_tokens)) {
''',
'''    try {
        record_native_event(ANDROID_LOG_INFO,
            "inference_begin context=" + std::to_string(session->context_size) +
            " threads=" + std::to_string(session->threads) +
            " gpu_layers=" + std::to_string(session->active_gpu_layers) +
            " user_prompt_chars=" + std::to_string(raw_prompt.size()) +
            " system_prompt_chars=" + std::to_string(system_prompt.size()));
        const std::string formatted = apply_chat_template(session.get(), system_prompt, raw_prompt);
        record_native_event(ANDROID_LOG_INFO, "chat_template_complete formatted_chars=" + std::to_string(formatted.size()));
        const llama_vocab * vocab = llama_model_get_vocab(session->model);
        std::vector<llama_token> prompt_tokens;
        record_native_event(ANDROID_LOG_INFO, "tokenization_begin formatted_chars=" + std::to_string(formatted.size()));
        if (!tokenise_prompt(vocab, formatted, prompt_tokens)) {
''', 'inference/template/tokenization phase breadcrumbs')
cpp = replace_once(cpp,
'''        const int output_limit = std::min(std::max(1, static_cast<int>(max_tokens)), std::max(1, session->context_size - 64));
''',
'''        record_native_event(ANDROID_LOG_INFO, "tokenization_complete prompt_tokens=" + std::to_string(prompt_tokens.size()));
        const int output_limit = std::min(std::max(1, static_cast<int>(max_tokens)), std::max(1, session->context_size - 64));
''', 'log tokenization completion')
cpp = replace_once(cpp,
'''        ctx_params.n_threads = session->threads;
        ctx_params.n_threads_batch = session->threads;
        ctx_params.no_perf = false;
        ctx = llama_init_from_model(session->model, ctx_params);
''',
'''        ctx_params.n_threads = session->threads;
        ctx_params.n_threads_batch = session->threads;
        // Android AArch64 CPU flash-attention kernels have caused SIGSEGV on some recent
        // ggml/llama.cpp revisions. Prefer the portable attention path for CPU inference;
        // leave the GPU-enabled path unchanged. This affects performance, not model support.
        ctx_params.flash_attn_type = session->active_gpu_layers == 0
            ? LLAMA_FLASH_ATTN_TYPE_DISABLED
            : LLAMA_FLASH_ATTN_TYPE_AUTO;
        ctx_params.offload_kqv = session->active_gpu_layers > 0;
        ctx_params.no_perf = false;
        record_native_event(ANDROID_LOG_INFO,
            std::string("context_init_begin flash_attention=") +
            (ctx_params.flash_attn_type == LLAMA_FLASH_ATTN_TYPE_DISABLED ? "disabled" : "auto") +
            " offload_kqv=" + (ctx_params.offload_kqv ? "true" : "false") +
            " n_ctx=" + std::to_string(ctx_params.n_ctx) +
            " n_batch=" + std::to_string(ctx_params.n_batch) +
            " n_ubatch=" + std::to_string(ctx_params.n_ubatch));
        ctx = llama_init_from_model(session->model, ctx_params);
''', 'disable CPU flash attention and KQV offload')
cpp = replace_once(cpp,
'''        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
''',
'''        record_native_event(ANDROID_LOG_INFO, "context_init_complete; beginning sampler initialization.");
        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
''', 'context-ready breadcrumb')
cpp = replace_once(cpp,
'''        llama_sampler_chain_add(sampler, temp_sampler);
        llama_sampler_chain_add(sampler, dist_sampler);

        int32_t prefill_result = 0;
''',
'''        llama_sampler_chain_add(sampler, temp_sampler);
        llama_sampler_chain_add(sampler, dist_sampler);
        record_native_event(ANDROID_LOG_INFO, "sampler_init_complete; prompt_prefill_begin tokens=" + std::to_string(prompt_tokens.size()));

        int32_t prefill_result = 0;
''', 'sampler ready and prefill start')
cpp = replace_once(cpp,
'''            const size_t chunk_count = std::min<size_t>(ctx_params.n_batch, prompt_tokens.size() - prefill_offset);
            llama_batch prompt_batch = llama_batch_get_one(
                prompt_tokens.data() + prefill_offset, static_cast<int32_t>(chunk_count));
            prefill_result = llama_decode(ctx, prompt_batch);
            if (prefill_result != 0) break;
            prefill_offset += chunk_count;
''',
'''            const size_t chunk_count = std::min<size_t>(ctx_params.n_batch, prompt_tokens.size() - prefill_offset);
            record_native_event(ANDROID_LOG_INFO, "prompt_prefill_batch_begin offset=" + std::to_string(prefill_offset) +
                " count=" + std::to_string(chunk_count));
            llama_batch prompt_batch = llama_batch_get_one(
                prompt_tokens.data() + prefill_offset, static_cast<int32_t>(chunk_count));
            prefill_result = llama_decode(ctx, prompt_batch);
            if (prefill_result != 0) {
                record_native_event(ANDROID_LOG_ERROR, "prompt_prefill_batch_failed result=" + std::to_string(prefill_result));
                break;
            }
            prefill_offset += chunk_count;
            record_native_event(ANDROID_LOG_INFO, "prompt_prefill_batch_complete offset=" + std::to_string(prefill_offset));
''', 'trace each prompt prefill batch')
cpp = replace_once(cpp,
'''        listener_class = listener ? env->GetObjectClass(listener) : nullptr;
''',
'''        record_native_event(ANDROID_LOG_INFO, "prompt_prefill_complete tokens=" + std::to_string(prefill_offset) + "; first_sampler_sample_begin.");
        listener_class = listener ? env->GetObjectClass(listener) : nullptr;
''', 'log prefill complete')
cpp = replace_once(cpp,
'''            llama_token token = llama_sampler_sample(sampler, ctx, -1);
            if (llama_vocab_is_eog(vocab, token)) break;
''',
'''            if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_sampler_sample_begin");
            llama_token token = llama_sampler_sample(sampler, ctx, -1);
            if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_sampler_sample_complete token_id=" + std::to_string(token));
            if (llama_vocab_is_eog(vocab, token)) {
                record_native_event(ANDROID_LOG_INFO, "sampler_emitted_end_of_generation");
                break;
            }
''', 'trace first sampled token')
cpp = replace_once(cpp,
'''                // llama_batch_get_one tracks position for a single sequence automatically.
                llama_batch next_batch = llama_batch_get_one(&token, 1);
                const int32_t decode_result = llama_decode(ctx, next_batch);
''',
'''                // llama_batch_get_one tracks position for a single sequence automatically.
                if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_generated_token_decode_begin");
                llama_batch next_batch = llama_batch_get_one(&token, 1);
                const int32_t decode_result = llama_decode(ctx, next_batch);
                if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_generated_token_decode_complete result=" + std::to_string(decode_result));
''', 'trace first generated-token decode')
cpp = replace_once(cpp,
'''        if (!pending_stream_text.empty() && !session->cancelled.load(std::memory_order_acquire)) {
            emit_token(env, listener, on_token, pending_stream_text);
        }
''',
'''        if (!pending_stream_text.empty() && !session->cancelled.load(std::memory_order_acquire)) {
            emit_token(env, listener, on_token, pending_stream_text);
        }
        record_native_event(ANDROID_LOG_INFO, "inference_complete generated_chars=" + std::to_string(answer.size()));
''', 'log inference completion')
cpp_path.write_text(cpp, encoding='utf-8')

main = main_path.read_text(encoding='utf-8')
old_call = '''                                withContext(Dispatchers.IO) {
                                    NativeLlamaEngine.generate(loadedHandle, prompt, systemPrompt, tokenLimit) { token ->
                                        val snapshot: String
                                        synchronized(streamBuffer) {
                                            streamBuffer.append(token)
                                            snapshot = streamBuffer.toString()
                                        }
                                        val now = android.os.SystemClock.elapsedRealtime()
                                        if (now - lastUiUpdateAt >= 90L || token.contains('\\n')) {
                                            lastUiUpdateAt = now
                                            runOnUiThread {
                                                if (!isFinishing && !isDestroyed && (modelInferenceActive || isBusy)) {
                                                    showThinking("✍️ 正在逐 Token 生成…\\n${snapshot.takeLast(1600)}", null)
                                                }
                                            }
                                        }
                                    }
                                }
'''
new_call = '''                                withContext(Dispatchers.IO) {
                                    // A SIGSEGV cannot be caught by Kotlin. Persist native log-tail checkpoints
                                    // concurrently so the last engine stage survives an abrupt process exit.
                                    NativeLlamaEngine.clearNativeLogTail()
                                    coroutineScope {
                                        val nativeLogCollector = launch {
                                            var previousTail = ""
                                            while (true) {
                                                currentCoroutineContext().ensureActive()
                                                val currentTail = NativeLlamaEngine.lastNativeLogTail()
                                                if (currentTail.isNotBlank() && currentTail != previousTail) {
                                                    val delta = when {
                                                        previousTail.isBlank() -> currentTail.takeLast(5000)
                                                        currentTail.startsWith(previousTail) -> currentTail.substring(previousTail.length).takeLast(5000)
                                                        else -> currentTail.takeLast(2500)
                                                    }
                                                    if (delta.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "llama_inference_checkpoint", delta)
                                                    previousTail = currentTail
                                                }
                                                delay(180)
                                            }
                                        }
                                        try {
                                            NativeLlamaEngine.generate(loadedHandle, prompt, systemPrompt, tokenLimit) { token ->
                                                val snapshot: String
                                                synchronized(streamBuffer) {
                                                    streamBuffer.append(token)
                                                    snapshot = streamBuffer.toString()
                                                }
                                                val now = android.os.SystemClock.elapsedRealtime()
                                                if (now - lastUiUpdateAt >= 90L || token.contains('\\n')) {
                                                    lastUiUpdateAt = now
                                                    runOnUiThread {
                                                        if (!isFinishing && !isDestroyed && (modelInferenceActive || isBusy)) {
                                                            showThinking("✍️ 正在逐 Token 生成…\\n${snapshot.takeLast(1600)}", null)
                                                        }
                                                    }
                                                }
                                            }
                                        } finally {
                                            nativeLogCollector.cancelAndJoin()
                                            val finalNativeTail = NativeLlamaEngine.lastNativeLogTail()
                                            if (finalNativeTail.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "native_inference_final_tail", finalNativeTail.takeLast(8000))
                                        }
                                    }
                                }
'''
main = replace_once(main, old_call, new_call, 'persist native log checkpoints during inference')
main = replace_once(main,
'''                    AppDiagnostics.beginOperation(this@MainActivity, "model_inference", "model=${loadedModelFileName ?: "unknown"}; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; promptChars=${prompt.length}")
''',
'''                    AppDiagnostics.beginOperation(this@MainActivity, "model_inference", "model=${loadedModelFileName ?: "unknown"}; architecture=${loadedModelProfile?.architecture ?: "unknown"}; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; promptChars=${prompt.length}; cpuFlashAttention=disabled")
''', 'include architecture and CPU attention mode in inference log')
main_path.write_text(main, encoding='utf-8')

gradle = gradle_path.read_text(encoding='utf-8')
gradle = replace_once(gradle, 'versionCode = 27', 'versionCode = 28', 'increment versionCode')
gradle = replace_once(gradle, 'versionName = "0.10.5"', 'versionName = "0.10.6"', 'increment versionName')
gradle_path.write_text(gradle, encoding='utf-8')

for rel in ['tests/test_progress_audit.py', 'tests/test_native_build_setup.py', 'tests/test_stability_regression.py']:
    p=root/rel
    if not p.exists(): raise SystemExit(f'Missing test file: {rel}')
    t=p.read_text(encoding='utf-8')
    t=t.replace(r'versionCode\s*=\s*27\b', r'versionCode\s*=\s*28\b')
    t=t.replace('versionCode = 27', 'versionCode = 28')
    t=t.replace('0.10.5', '0.10.6')
    t=t.replace('source-27', 'source-28')
    p.write_text(t, encoding='utf-8')

reg=root/'tests/test_stability_regression.py'
t=reg.read_text(encoding='utf-8')
insert='''\n    def test_cpu_inference_disables_android_flash_attention(self):
        self.assertIn("ctx_params.flash_attn_type = session->active_gpu_layers == 0", self.cpp)
        self.assertIn("LLAMA_FLASH_ATTN_TYPE_DISABLED", self.cpp)
        self.assertIn("ctx_params.offload_kqv = session->active_gpu_layers > 0", self.cpp)

    def test_native_inference_has_phase_breadcrumbs_and_persisted_log_monitor(self):
        for marker in ("tokenization_begin", "prompt_prefill_batch_begin", "first_sampler_sample_begin", "first_generated_token_decode_begin"):
            self.assertIn(marker, self.cpp)
        self.assertIn('"llama_inference_checkpoint"', self.main)
        self.assertIn('"native_inference_final_tail"', self.main)
'''
anchor='''    def test_new_version_preserves_application_id(self):
'''
t=replace_once(t, anchor, insert+'\n'+anchor, 'add flash attention and inference log regression checks')
reg.write_text(t,encoding='utf-8')

# Add explicit regression expectations to source tests to catch accidental re-enablement.
combined = cpp_path.read_text(encoding='utf-8') + main_path.read_text(encoding='utf-8') + gradle_path.read_text(encoding='utf-8')
for required in ['LLAMA_FLASH_ATTN_TYPE_DISABLED','ctx_params.offload_kqv = session->active_gpu_layers > 0','prompt_prefill_batch_begin','first_sampler_sample_begin','llama_inference_checkpoint','native_inference_final_tail','versionCode = 28','versionName = "0.10.6"']:
    if required not in combined:
        raise SystemExit('Post-patch assertion failed: ' + required)
print('Patched source revision 28 / v0.10.6: Android CPU flash attention disabled, KQV GPU offload disabled on CPU, native inference phase logs persisted during generation.')
