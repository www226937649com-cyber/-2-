"""Source-level guardrails for runtime task visibility and truthful capability reporting.

These tests do not replace Android/Gradle compilation or device tests; they guard against
accidentally removing visible task stages or claiming unsupported native features.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt"
BUILD = ROOT / "app/build.gradle.kts"


class RuntimeProgressAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = MAIN.read_text(encoding="utf-8")
        cls.build = BUILD.read_text(encoding="utf-8")

    def test_profile_has_more_features_entry(self):
        self.assertIn('sectionLabel("更多功能")', self.main)
        self.assertIn('styledButton("✦ 打开更多功能"', self.main)
        self.assertIn('private fun showMoreFeaturesScreen()', self.main)

    def test_task_center_keeps_bounded_persistent_journal(self):
        self.assertIn('"runtime_task_journal"', self.main)
        self.assertIn('"runtime_task_current"', self.main)
        self.assertIn('最近任务日志（每秒刷新', self.main)
        self.assertIn('上次任务未留下完成记录', self.main)
        self.assertIn('没有底层真实进度回调时只显示阶段', self.main)

    def test_common_request_routes_emit_visible_stages(self):
        for stage in (
            '"任务路由"', '"检查当前话题记忆"', '"按需定位"',
            '"获取一次位置"', '"请求天气数据"', '"解析城市并查询天气"',
            '"即时闲聊回复"', '"本地算式处理"', '"联网检索"',
            '"构建本地提示词"', '"保存并展示搜索结果"', '"组合历史上下文和来源"',
        ):
            with self.subTest(stage=stage):
                self.assertIn(stage, self.main)

    def test_request_cancellation_does_not_overwrite_new_task_status(self):
        self.assertIn('recordTaskJournalOnly(trackedName, "已取消/被替代"', self.main)
        self.assertIn('不覆盖新请求的当前状态', self.main)

    def test_engine_status_and_system_info_are_refreshable(self):
        self.assertIn('刷新获取当前引擎状态', self.main)
        self.assertIn('private fun refreshEngineAndSystem', self.main)
        self.assertIn('NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)', self.main)
        self.assertIn('📱 系统版本介绍', self.main)
        self.assertIn('FEATURE_VULKAN_HARDWARE_LEVEL', self.main)

    def test_search_results_wait_for_explicit_synthesis_confirmation(self):
        self.assertIn('要不要我把这些资料整合起来', self.main)
        self.assertIn('savePendingSearchResearch(question, results)', self.main)
        self.assertIn('private suspend fun synthesizePendingSearchResearch', self.main)
        self.assertIn('private fun loadPendingSearchResearch', self.main)

    def test_search_confirmation_is_explicit_and_not_a_generic_question_prefix(self):
        self.assertIn('需要整合|要整合|继续整合', self.main)
        self.assertIn('整合刚才的资料', self.main)
        # Avoid a broad "请/帮我/需要" prefix consuming a new unrelated request.
        self.assertNotRegex(self.main, r'\|请\|帮我\|把\.\*\(整合')

    def test_chat_recall_and_context_are_broader(self):
        self.assertIn('你前面最近问过这些', self.main)
        self.assertIn('maxChars: Int = 6800', self.main)
        self.assertIn('takeLast(24)', self.main)

    def test_gpu_and_streaming_capabilities_are_reported_cautiously(self):
        self.assertIn('GPU 层配置', self.main)
        self.assertIn('GPU_RETRY_MARKER', (ROOT / 'app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt').read_text(encoding='utf-8'))
        self.assertIn('NativeLlamaEngine.generate', self.main)
        self.assertIn('不能单独证明 GPU 已参与当前推理', self.main)
        self.assertIn('正文随 Token 逐步预览', self.main)
        self.assertNotIn('当前引擎在整段生成完成后显示答案', self.main)

    def test_temperature_management_is_absent_by_requirement(self):
        for forbidden in (
            'temperature_monitor_auto', 'temperature_auto_guard',
            'showTemperatureScreen', 'BatteryManager', 'PowerManager',
            '温度监控', '热保护',
        ):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, self.main)

    def test_task_journal_records_elapsed_duration(self):
        self.assertIn('.put("elapsedMs", elapsedMs)', self.main)
        self.assertIn('总耗时：', self.main)
        self.assertIn('耗时 ', self.main)

    def test_version_and_package_are_stable(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', self.build)
        self.assertRegex(self.build, r'versionCode\s*=\s*23\b')
        self.assertIn('versionName = "0.10.2"', self.build)
        # Native libraries are currently built only for arm64-v8a.
        self.assertIn('abiFilters += listOf("arm64-v8a")', self.build)


if __name__ == "__main__":
    unittest.main()
