# 东巴壳 AI 管家 · source-24 开发交付包

- **应用名称：** 东巴壳 AI 管家
- **Android `applicationId`：** `com.aiguanjia.app`（保持不变）
- **应用版本：** `versionCode = 22`，`versionName = 0.10.0`
- **目标 ABI：** `arm64-v8a`
- **本地模型格式：** GGUF；模型权重不包含在源码包内。
- **推理引擎目标：** 上游 `ggml-org/llama.cpp` 发布标签 `v0.6.0`，CPU 后端 + Vulkan 动态后端；CPU 是后备路线，GPU 层卸载按请求配置。

## source-24 修改内容

1. 将旧的 `dev.ffmpegkit-maintained:llama-android:0.1.1` 完整文本调用替换为 C++/JNI 原生推理桥接；按 Token 回调输出、支持取消标记、模型上下文与 CPU 线程参数，并在 GPU 路径的上下文创建/预填充失败时尝试释放 GPU 配置模型、重新加载 CPU 模型。
2. 在“个人中心 → 打开更多功能”增加可刷新的“推理引擎 / GPU 状态”与“系统版本介绍”。报告会分别显示原生库是否加载、Vulkan 插件注册、系统 Vulkan 物理设备枚举、GGML 后端/设备数量、已加载模型的 GPU 层请求与配置；不会把系统识别到 GPU 说成 GPU 已经参与推理。
3. 联网搜索成功后先向用户展示搜索资料及原始链接，并询问是否整合；待用户在当前话题回复“整合 / 总结 / 综合”等明确确认后，才调用本地模型综合检索摘要与对话上下文。待整合结果按当前会话 ID 保存。
4. 扩展“前面问了什么”类历史回顾匹配，并在模型提示词中纳入当前会话最近最多 24 条有效消息（有长度上限），帮助本地模型理解多轮对话。
5. 增加 source-24 原生构建工作流：先获取并核验 `llama.cpp` 的 `v0.6.0` 标签，再用 Android NDK 编译 arm64 CPU + Vulkan 后端、把核心共享库与动态后端打包到 `jniLibs`，然后运行源码测试和 Gradle 单测、构建 Debug/Release APK，并归档日志与产物。

## 状态说明

**已经在源码中实现：** JNI 推理桥接代码、逐 Token 回调、取消标记、GPU→CPU 的预填充失败回退路径、引擎状态刷新、系统版本信息、联网搜索后的显式整合确认、按会话保存待整合资料、历史对话回顾扩展，以及用于云端构建的 workflow。

**尚未得到实证的部分：** 本次没有 Android SDK/NDK，也没有本机 Gradle 环境，因此无法在当前容器确认 C++/JNI、APK 的真实编译结果。当前也未运行目标手机实测（按要求不安排手机实测），所以不能宣称 Vulkan 在 Redmi Note 11T Pro 上已经实际执行或一定提速。源码里配置了 Vulkan，不等于 GPU 运行已验证。

要拿到真实 APK 和构建数据：把 `DongBaKe-source-24.zip` 放在 GitHub 仓库根目录，并把同名 workflow 文件放到仓库 `.github/workflows/build-apk-workflow-source-24.yml`，然后手动运行 `DongBaKe Android build - source-24 CPU + Vulkan`。成功时 Actions 将上传 APK、原生库、Gradle 报告和真实日志；失败时也会尽量上传已生成的诊断文件。

## 本地可重复检查

```bash
python3 -m unittest discover -s tests -v
bash tools/test_model_profile.sh
bash tools/test_math_parser.sh
bash tools/test_source_audit.sh
bash -n tools/build_llama_cpp_android_vulkan.sh
```

这些源码/脚本测试不等于 Android 工程编译、APK 生成或设备端 GPU 推理验证。
