package com.aiguanjia.app

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Process
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/** 本地诊断日志；不会记录聊天正文。 */
object AppDiagnostics {
    private const val LOG = "dongbake-runtime.log"
    private const val OLD_LOG = "dongbake-runtime.1.log"
    private const val MARKER = "dongbake-active-operation.txt"
    private const val MAX_BYTES = 512L * 1024L
    private val lock = Any()
    @Volatile private var handlerInstalled = false

    fun initialize(context: Context) {
        val app = context.applicationContext
        synchronized(lock) {
            val marker = File(app.filesDir, MARKER)
            if (marker.isFile) {
                val unfinished = runCatching { marker.readText(Charsets.UTF_8) }.getOrDefault("unknown")
                writeLocked(app, "FATAL", "previous_run", "上次进程疑似异常退出；最后未完成操作：" + oneLine(unfinished))
                runCatching { marker.delete() }
            }
            writeLocked(app, "INFO", "startup",
                "启动 Android=${Build.VERSION.RELEASE}/API${Build.VERSION.SDK_INT}; device=${Build.MANUFACTURER} ${Build.MODEL}; " +
                "ABI=${Build.SUPPORTED_ABIS.joinToString(",")}; version=${version(app)}; ${memorySnapshot(app)}")
            if (!handlerInstalled) {
                val previous = Thread.getDefaultUncaughtExceptionHandler()
                Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                    runCatching { logThrowable(app, "FATAL", "uncaught_exception", "thread=${thread.name}", error) }
                    if (previous != null) previous.uncaughtException(thread, error)
                    else { Process.killProcess(Process.myPid()); exitProcess(10) }
                }
                handlerInstalled = true
            }
        }
    }

    fun log(context: Context, level: String, event: String, details: String = "") {
        runCatching { synchronized(lock) { writeLocked(context.applicationContext, level, event, details) } }
    }

    fun logThrowable(context: Context, level: String, event: String, details: String, error: Throwable) {
        val out = StringWriter()
        runCatching { error.printStackTrace(PrintWriter(out)) }
        log(context, level, event, details + "\n" + out.toString())
    }

    fun beginOperation(context: Context, operation: String, details: String) {
        val app = context.applicationContext
        synchronized(lock) {
            runCatching {
                FileOutputStream(File(app.filesDir, MARKER), false).use {
                    it.write((operation + "|" + now() + "|" + oneLine(details)).toByteArray(Charsets.UTF_8))
                    it.fd.sync()
                }
            }
            writeLocked(app, "INFO", operation + "_begin", details)
        }
    }

    fun finishOperation(context: Context, operation: String, outcome: String, details: String = "") {
        val app = context.applicationContext
        synchronized(lock) {
            writeLocked(app, if (outcome == "success") "INFO" else "WARN", operation + "_" + outcome, details)
            runCatching {
                val marker = File(app.filesDir, MARKER)
                if (marker.isFile && marker.readText(Charsets.UTF_8).substringBefore("|") == operation) marker.delete()
            }
        }
    }

    fun memorySnapshot(context: Context): String = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        "available=${info.availMem}; total=${info.totalMem}; lowMemory=${info.lowMemory}; vmMax=${Runtime.getRuntime().maxMemory()}; nativeHeap=${android.os.Debug.getNativeHeapAllocatedSize()}"
    }.getOrDefault("memorySnapshot=unavailable")

    fun readAll(context: Context): String = synchronized(lock) {
        val dir = context.applicationContext.filesDir
        val chunks = listOf(OLD_LOG, LOG).mapNotNull { name ->
            val file = File(dir, name)
            if (file.isFile) runCatching { file.readText(Charsets.UTF_8) }.getOrNull() else null
        }
        if (chunks.isEmpty()) "暂无运行日志。\n" else chunks.joinToString("\n")
    }

    fun clear(context: Context) {
        synchronized(lock) {
            runCatching { File(context.filesDir, LOG).delete() }
            runCatching { File(context.filesDir, OLD_LOG).delete() }
            writeLocked(context.applicationContext, "INFO", "logs_cleared", "用户清空了日志。")
        }
    }

    private fun version(context: Context) = runCatching {
        val p = context.packageManager.getPackageInfo(context.packageName, 0)
        "${p.versionName.orEmpty()} (${p.longVersionCode})"
    }.getOrDefault("unknown")

    private fun writeLocked(context: Context, level: String, event: String, details: String) {
        runCatching {
            val file = File(context.filesDir, LOG)
            if (file.exists() && file.length() >= MAX_BYTES) {
                val old = File(context.filesDir, OLD_LOG)
                runCatching { old.delete() }
                runCatching { file.renameTo(old) }
            }
            val line = "${now()} [${level}] [${event}] ${details.trimEnd()}\n"
            FileOutputStream(file, true).use {
                it.write(line.toByteArray(Charsets.UTF_8))
                it.fd.sync()
            }
        }
    }

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
    private fun oneLine(value: String) = value.replace('\r', ' ').replace('\n', ' ').take(4000)
}
