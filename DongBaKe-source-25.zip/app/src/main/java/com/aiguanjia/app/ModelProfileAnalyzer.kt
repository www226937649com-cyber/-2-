package com.aiguanjia.app

import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

internal data class ModelProfile(
    val displayName: String,
    val architecture: String,
    val quantizationHint: String,
    val supportsReasoningTemplate: Boolean,
    val modelBytes: Long,
    val notes: String,
    val ggufVersion: Long = 0L,
    val tensorCount: Long = 0L,
    val metadataCount: Long = 0L,
    val tensorQuantizationSummary: String = "",
    val parameterCount: Long? = null,
    val tokenizerModel: String = "",
    val hasChatTemplate: Boolean = false
) {
    val modeLabels: List<String>
        get() = if (supportsReasoningTemplate) listOf("快速", "均衡", "深度") else listOf("快速", "详细回答")
}

/** Parses GGUF metadata without loading model weights or executing file contents. */
internal object ModelProfileAnalyzer {
    private val knownArchitectures = listOf(
        "qwen3", "qwen2", "qwen", "deepseek2", "deepseek", "llama", "mistral", "mixtral",
        "gemma", "phi3", "phi", "glm4", "chatglm", "internlm2", "internlm", "command-r", "granite",
        "falcon", "yi", "baichuan", "starcoder2", "codeshell", "minicpm", "jamba"
    )

    private data class Metadata(
        var architecture: String = "",
        var name: String = "",
        var template: String = "",
        var fileType: Long? = null,
        var ggufVersion: Long = 0L,
        var tensorCount: Long = 0L,
        var metadataCount: Long = 0L,
        var parameterCount: Long? = null,
        var tokenizerModel: String = "",
        var hasChatTemplate: Boolean = false,
        val tensorQuantTypes: MutableMap<Int, Long> = linkedMapOf()
    )

    fun analyze(file: File): ModelProfile {
        require(file.isFile && file.canRead() && file.length() >= 24L) { "模型文件不存在、不可读或太小，无法分析 GGUF 元数据" }
        // Malformed/non-GGUF input must fail loudly instead of being mislabeled as a model.
        val metadata = parseMetadata(file)
        val nameAndArchitecture = "${file.name} ${metadata.name} ${metadata.architecture}".lowercase(Locale.ROOT)
        val architecture = metadata.architecture.ifBlank {
            knownArchitectures.firstOrNull { nameAndArchitecture.contains(it) } ?: "未知架构"
        }
        val tensorTypes = metadata.tensorQuantTypes.entries.sortedByDescending { it.value }
        val tensorSummary = tensorTypes.joinToString("、") { "${ggmlTypeName(it.key)}×${it.value}" }
        val quantization = metadata.fileType?.let(::fileTypeName)
            ?: when {
                tensorTypes.isNotEmpty() && tensorTypes.map { it.key }.distinct().size > 1 -> "混合张量类型（以扫描摘要为准）"
                tensorTypes.size == 1 -> ggmlTypeName(tensorTypes.first().key)
                else -> Regex("(?i)\\b(Q[2-8]_[KMSL][A-Z_]*|IQ[1-4]_[A-Z0-9_]+|F16|F32|BF16)\\b")
                    .find(file.name)?.value?.uppercase(Locale.ROOT) ?: "GGUF 元数据未提供明确类型"
            }
        val evidence = "${metadata.name} ${metadata.template} ${file.name}".lowercase(Locale.ROOT)
        val templateReasoning = listOf("<think>", "</think>", "/think", "enable_thinking", "reasoning_effort").any { evidence.contains(it) }
        val familyReasoning = listOf("qwen3", "deepseek-r1", "deepseek_r1", "qwq", "reasoner").any { evidence.contains(it) }
        val reasoning = templateReasoning || familyReasoning
        val notes = buildString {
            append("GGUF 版本：${metadata.ggufVersion}；头部声明张量数：${metadata.tensorCount}；元数据条目数：${metadata.metadataCount}；")
            append(if (architecture == "未知架构") "未能可靠识别模型架构；" else "检测到架构：$architecture；")
            append(if (metadata.name.isNotBlank()) "模型元数据名称：${metadata.name.take(90)}；" else "没有读取到通用模型名称；")
            append(metadata.parameterCount?.let { "参数量元数据：$it；" } ?: "未读取到准确参数量元数据；")
            append(if (metadata.tokenizerModel.isNotBlank()) "分词器类型：${metadata.tokenizerModel.take(60)}；" else "分词器类型字段未识别；")
            append(if (metadata.hasChatTemplate) "存在 tokenizer.chat_template 元数据；" else "没有确认 tokenizer.chat_template；")
            append(if (tensorSummary.isNotBlank()) "张量目录量化/数据类型统计：$tensorSummary；" else "未读取到张量目录类型统计；")
            append(if (metadata.fileType != null) "总体量化标签来自 GGUF general.file_type 元数据；" else "总体量化标签不是由 general.file_type 确认；")
            append(if (reasoning) "发现原生思考模板或推理模型线索，可选快速/均衡/深度；" else "未确认原生思考模板，使用快速/详细回答；")
            append("本分析读取头部、元数据和张量目录，不读取全部权重张量，也未进行推理能力或性能跑分。")
        }
        return ModelProfile(
            displayName = metadata.name.ifBlank { file.nameWithoutExtension }.take(100),
            architecture = architecture,
            quantizationHint = quantization,
            supportsReasoningTemplate = reasoning,
            modelBytes = file.length(),
            notes = notes,
            ggufVersion = metadata.ggufVersion,
            tensorCount = metadata.tensorCount,
            metadataCount = metadata.metadataCount,
            tensorQuantizationSummary = tensorSummary,
            parameterCount = metadata.parameterCount,
            tokenizerModel = metadata.tokenizerModel,
            hasChatTemplate = metadata.hasChatTemplate
        )
    }

    private fun parseMetadata(file: File): Metadata = RandomAccessFile(file, "r").use { raf ->
        val metadata = Metadata()
        if (readAscii(raf, 4) != "GGUF") error("不是 GGUF 文件（魔数不匹配）")
        val version = readU32(raf)
        if (version !in 2L..3L) error("暂不识别 GGUF 版本 $version")
        val tensorCount = readU64(raf)
        val kvCount = readU64(raf)
        if (tensorCount !in 0L..1_000_000L || kvCount !in 0L..100_000L) error("GGUF 张量/元数据计数异常")
        metadata.ggufVersion = version
        metadata.tensorCount = tensorCount
        metadata.metadataCount = kvCount
        repeat(kvCount.toInt()) {
            if (raf.filePointer >= raf.length()) error("GGUF 元数据不完整")
            val key = readString(raf, 4096)
            val type = readU32(raf).toInt()
            when (key) {
                "general.architecture" -> metadata.architecture = readTypedString(raf, type).take(100)
                "general.name" -> metadata.name = readTypedString(raf, type).take(256)
                "tokenizer.ggml.model" -> metadata.tokenizerModel = readTypedString(raf, type).take(100)
                "tokenizer.chat_template" -> {
                    metadata.hasChatTemplate = type == 8
                    metadata.template = readTypedString(raf, type).take(250_000)
                }
                "general.file_type" -> metadata.fileType = readTypedInteger(raf, type)
                "general.parameter_count" -> metadata.parameterCount = readTypedInteger(raf, type)
                else -> skipValue(raf, type)
            }
        }
        // Tensor descriptors sit after metadata. This reads names/shapes/type IDs, not multi-GB tensor payloads.
        repeat(tensorCount.toInt()) {
            if (raf.filePointer >= raf.length()) error("GGUF 张量目录不完整")
            readString(raf, 4096)
            val dimensions = readU32(raf).toInt()
            if (dimensions !in 1..8) error("GGUF 张量维度数异常：$dimensions")
            repeat(dimensions) {
                val dim = readU64(raf)
                if (dim <= 0L) error("GGUF 张量形状异常")
            }
            val tensorType = readU32(raf).toInt()
            val offset = readU64(raf)
            if (offset < 0L) error("GGUF 张量偏移量异常")
            metadata.tensorQuantTypes[tensorType] = (metadata.tensorQuantTypes[tensorType] ?: 0L) + 1L
        }
        metadata
    }

    private fun readTypedString(raf: RandomAccessFile, type: Int): String {
        if (type != 8) { skipValue(raf, type); return "" }
        return readString(raf, 250_000)
    }

    private fun readTypedInteger(raf: RandomAccessFile, type: Int): Long? = when (type) {
        0, 1, 7 -> raf.readUnsignedByte().toLong()
        2, 3 -> readU16(raf)
        4, 5 -> readU32(raf)
        10, 11 -> readU64(raf)
        else -> { skipValue(raf, type); null }
    }

    private fun skipValue(raf: RandomAccessFile, type: Int) {
        when (type) {
            0, 1, 7 -> skip(raf, 1L)
            2, 3 -> skip(raf, 2L)
            4, 5, 6 -> skip(raf, 4L)
            10, 11, 12 -> skip(raf, 8L)
            8 -> skip(raf, readLength(raf))
            9 -> {
                val itemType = readU32(raf).toInt()
                val count = readU64(raf)
                if (count < 0L || count > 10_000_000L) error("GGUF 数组长度异常")
                val itemSize = when (itemType) {
                    0, 1, 7 -> 1L
                    2, 3 -> 2L
                    4, 5, 6 -> 4L
                    10, 11, 12 -> 8L
                    else -> 0L
                }
                if (itemSize > 0L) skip(raf, Math.multiplyExact(count, itemSize))
                else if (itemType == 8) repeat(count.toInt()) { skip(raf, readLength(raf)) }
                else error("不支持的 GGUF 数组类型 $itemType")
            }
            else -> error("不支持的 GGUF 元数据类型 $type")
        }
    }

    private fun readString(raf: RandomAccessFile, maxBytes: Int): String {
        val length = readLength(raf)
        if (length > maxBytes.toLong()) {
            skip(raf, length)
            return ""
        }
        val data = ByteArray(length.toInt())
        raf.readFully(data)
        return String(data, Charsets.UTF_8)
    }

    private fun readLength(raf: RandomAccessFile): Long {
        val length = readU64(raf)
        if (length < 0L || length > raf.length() - raf.filePointer) error("GGUF 字符串长度异常")
        return length
    }

    private fun readU16(raf: RandomAccessFile): Long = java.lang.Short.toUnsignedLong(java.lang.Short.reverseBytes(raf.readShort()))
    private fun readU32(raf: RandomAccessFile): Long = Integer.toUnsignedLong(Integer.reverseBytes(raf.readInt()))
    private fun readU64(raf: RandomAccessFile): Long = java.lang.Long.reverseBytes(raf.readLong())
    private fun readAscii(raf: RandomAccessFile, n: Int): String = ByteArray(n).also(raf::readFully).let { String(it, Charsets.US_ASCII) }

    private fun skip(raf: RandomAccessFile, bytes: Long) {
        if (bytes < 0L || bytes > raf.length() - raf.filePointer) error("GGUF 元数据超出文件边界")
        raf.seek(raf.filePointer + bytes)
    }

    private fun fileTypeName(type: Long): String = when (type) {
        0L -> "F32"; 1L -> "F16"; 2L -> "Q4_0"; 3L -> "Q4_1"
        7L -> "Q8_0"; 8L -> "Q5_0"; 9L -> "Q5_1"
        10L -> "Q2_K"; 11L -> "Q3_K_S"; 12L -> "Q3_K_M"; 13L -> "Q3_K_L"
        14L -> "Q4_K_S"; 15L -> "Q4_K_M"; 16L -> "Q5_K_S"; 17L -> "Q5_K_M"; 18L -> "Q6_K"
        19L -> "IQ2_XXS"; 20L -> "IQ2_XS"; 21L -> "IQ3_XXS"; 22L -> "IQ1_S"
        23L -> "IQ4_NL"; 24L -> "IQ3_S"; 25L -> "IQ2_S"; 26L -> "IQ4_XS"; 27L -> "IQ1_M"
        30L -> "BF16"; else -> "GGUF file_type=$type"
    }

    private fun ggmlTypeName(type: Int): String = when (type) {
        0 -> "F32"; 1 -> "F16"; 2 -> "Q4_0"; 3 -> "Q4_1"; 6 -> "Q5_0"; 7 -> "Q5_1"
        8 -> "Q8_0"; 9 -> "Q8_1"; 10 -> "Q2_K"; 11 -> "Q3_K"; 12 -> "Q4_K"; 13 -> "Q5_K"
        14 -> "Q6_K"; 15 -> "Q8_K"; 16 -> "IQ2_XXS"; 17 -> "IQ2_XS"; 18 -> "IQ3_XXS"
        19 -> "IQ1_S"; 20 -> "IQ4_NL"; 21 -> "IQ3_S"; 22 -> "IQ2_S"; 23 -> "IQ4_XS"
        24 -> "I8"; 25 -> "I16"; 26 -> "I32"; 27 -> "I64"; 28 -> "F64"; 29 -> "IQ1_M"
        30 -> "BF16"; 31 -> "Q4_0_4_4"; 32 -> "Q4_0_4_8"; 33 -> "Q4_0_8_8"
        34 -> "TQ1_0"; 35 -> "TQ2_0"; 36 -> "IQ4_NL_4_4"; 37 -> "IQ4_NL_4_8"; 38 -> "IQ4_NL_8_8"
        else -> "ggml_type=$type"
    }

}
