"""Guardrails for the reproducible Android Vulkan engine build stage."""
from pathlib import Path
import re
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "tools/build_llama_cpp_android_vulkan.sh"
WORKFLOW = ROOT / ".github/workflows/build-apk-workflow-source-24.yml"
BUILD = ROOT / "app/build.gradle.kts"


class NativeVulkanBuildSetupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.script = SCRIPT.read_text(encoding="utf-8")
        cls.workflow = WORKFLOW.read_text(encoding="utf-8")
        cls.build = BUILD.read_text(encoding="utf-8")

    def test_shell_script_parses(self):
        result = subprocess.run(["bash", "-n", str(SCRIPT)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_missing_ndk_fails_before_any_network_operation(self):
        import os
        env = os.environ.copy()
        env["ANDROID_NDK"] = "/definitely/missing/android-ndk"
        env.pop("ANDROID_HOME", None)
        result = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("Android NDK not found", result.stderr)

    def test_upstream_tag_and_target_are_pinned(self):
        self.assertIn('LLAMA_CPP_TAG="v0.6.0"', self.script)
        self.assertIn("ANDROID_ABI=arm64-v8a", self.script)
        self.assertIn("-DGGML_NATIVE=OFF", self.script)
        self.assertIn("-DGGML_VULKAN=ON", self.script)
        self.assertIn("-DGGML_CPU=ON", self.script)
        self.assertIn("-DGGML_BACKEND_DL=ON", self.script)
        self.assertIn("-DBUILD_SHARED_LIBS=ON", self.script)
        self.assertIn("-DLLAMA_BUILD_TESTS=OFF", self.script)
        self.assertIn('describe --tags --exact-match HEAD', self.script)

    def test_missing_toolchain_fails_instead_of_claiming_success(self):
        for required in ("Android NDK not found", "glslc is required", "SPIRV-Headers CMake package not found"):
            with self.subTest(required=required):
                self.assertIn(required, self.script)
        self.assertIn("does not prove Vulkan execution", self.script)
        self.assertIn("Vulkan plugin libggml-vulkan.so was not found", self.script)
        self.assertIn("GGML backend registry library libggml.so was not found", self.script)
        self.assertIn("find \"$LLAMA_CPP_INSTALL_DIR\" \\( -type f -o -type l \\) -name 'libggml-*.so'", self.script)
        self.assertIn("CPU plugin libggml-cpu.so was not found", self.script)
        self.assertIn("Staged dynamic backend", self.script)
        self.assertIn('cp -Lf "$LLAMA_LIBRARY" "$JNI_LIB_DIR/libllama.so"', self.script)
        self.assertIn('cp -Lf "$GGML_BASE_LIBRARY" "$JNI_LIB_DIR/libggml-base.so"', self.script)

    def test_ci_build_compiles_engine_before_integrated_apk(self):
        self.assertIn("tools/build_llama_cpp_android_vulkan.sh", self.workflow)
        self.assertIn("Build llama.cpp v0.6.0 for Android arm64 CPU + Vulkan", self.workflow)
        self.assertIn(":app:assembleDebug :app:assembleRelease", self.workflow)
        self.assertIn("app/src/main/jniLibs/arm64-v8a/libllama.so", self.workflow)
        self.assertIn("app/src/main/jniLibs/arm64-v8a/libggml.so", self.workflow)
        self.assertIn("app/src/main/jniLibs/arm64-v8a/libggml-base.so", self.workflow)
        self.assertIn("app/src/main/jniLibs/arm64-v8a/libggml-vulkan.so", self.workflow)
        self.assertIn("app/build/outputs/apk/**/*.apk", self.workflow)

    def test_workflow_unpacks_source_zip_and_uses_actual_project_root(self):
        self.assertIn('test -f "$GITHUB_WORKSPACE/DongBaKe-source-24.zip"', self.workflow)
        self.assertIn('unzip -q "$GITHUB_WORKSPACE/DongBaKe-source-24.zip" -d "$GITHUB_WORKSPACE/buildsrc"', self.workflow)
        self.assertIn('working-directory: ${{ github.workspace }}/buildsrc', self.workflow)
        self.assertIn('--project-dir "$GITHUB_WORKSPACE/buildsrc"', self.workflow)
        self.assertIn('test -f "$GITHUB_WORKSPACE/buildsrc/settings.gradle.kts"', self.workflow)
        self.assertIn('test -f "$GITHUB_WORKSPACE/buildsrc/app/build.gradle.kts"', self.workflow)


    def test_jni_uses_public_decode_api_and_explains_backend_states(self):
        cpp = (ROOT / "app/src/main/cpp/dongbake_llama_jni.cpp").read_text(encoding="utf-8")
        self.assertIn("llama_batch_get_one", cpp)
        self.assertIn("llama_decode(ctx, batch)", cpp)
        self.assertIn('ggml_backend_reg_by_name("Vulkan")', cpp)
        self.assertIn('llama_log_set(capture_llama_log, nullptr)', cpp)
        self.assertIn("最近 llama.cpp 原生日志", cpp)
        self.assertIn("当前模型已在 GPU 上执行", cpp)
        self.assertIn("std::unordered_map<jlong, std::shared_ptr<NativeSession>>", cpp)
        self.assertIn("auto session = remove_session(handle)", cpp)
        self.assertIn("Cancellation is reset by the Kotlin caller", cpp)
        self.assertNotIn("reinterpret_cast<NativeSession *>(handle)", cpp)
        self.assertNotIn("llama_batch_ext", cpp)
        self.assertNotIn("LLAMA_PROCESS_TYPE_DECODE", cpp)

    def test_application_version_increments_without_package_change(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', self.build)
        self.assertRegex(self.build, r'versionCode\s*=\s*24\b')
        self.assertIn('versionName = "0.10.2"', self.build)
        self.assertIn('abiFilters += listOf("arm64-v8a")', self.build)


if __name__ == "__main__":
    unittest.main()
