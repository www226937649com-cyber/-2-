#include <jni.h>
#include <vulkan/vulkan.h>
#include <android/log.h>

#include "llama.h"
#include "ggml-backend.h"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <atomic>
#include <exception>
#include <cstdint>
#include <cstddef>
#include <mutex>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace {
constexpr const char * kLogTag = "DongBaKeLlama";
std::once_flag g_backend_init_once;
std::mutex g_backend_dir_mutex;
std::string g_backend_dir;
std::mutex g_native_log_mutex;
std::string g_native_log_tail;

void append_native_log_tail(const char * text) noexcept {
    if (text == nullptr || text[0] == '\0') return;
    try {
        std::lock_guard<std::mutex> lock(g_native_log_mutex);
        g_native_log_tail.append(text);
        constexpr size_t kMaxNativeLogChars = 12000;
        if (g_native_log_tail.size() > kMaxNativeLogChars) {
            g_native_log_tail.erase(0, g_native_log_tail.size() - kMaxNativeLogChars);
        }
    } catch (...) {
        // Never allow diagnostics allocation failure to escape through a C logging callback.
    }
}

void record_native_event(int priority, const std::string & message) noexcept {
    append_native_log_tail(message.c_str());
    append_native_log_tail("\n");
    __android_log_print(priority, kLogTag, "%s", message.c_str());
}

void capture_llama_log(enum ggml_log_level /* level */, const char * text, void * /* user_data */) {
    append_native_log_tail(text);
}

std::string native_log_snapshot() {
    std::lock_guard<std::mutex> lock(g_native_log_mutex);
    return g_native_log_tail;
}

struct NativeSession {
    llama_model * model = nullptr;
    std::string model_path;
    int context_size = 2048;
    int threads = 4;
    int requested_gpu_layers = 0;
    int active_gpu_layers = 0;
    bool cpu_retry_used = false;
    int kv_cache_quantization = 0; // 0=F16 (compatibility default), 1=Q8_0 (experimental)
    bool gpu_flash_attention = true;
    int observed_gpu_layers = -1;
    int observed_total_layers = -1;
    int last_prompt_tokens = 0;
    int last_generated_tokens = 0;
    int64_t last_first_token_ms = -1;
    int64_t last_prefill_ms = -1;
    int64_t last_decode_ms = -1;
    bool last_inference_cancelled = false;
    std::atomic<bool> cancelled{false};
    std::atomic<bool> closing{false};
    std::mutex generation_mutex;
};

// Handles are stable registry IDs, not raw pointers. A shared session reference
// keeps in-flight JNI calls alive while release removes the public handle and waits
// for generation to leave the model mutex.
std::mutex g_sessions_mutex;
std::unordered_map<jlong, std::shared_ptr<NativeSession>> g_sessions;
jlong g_next_session_handle = 1;

jlong register_session(const std::shared_ptr<NativeSession> & session) {
    std::lock_guard<std::mutex> lock(g_sessions_mutex);
    const jlong handle = g_next_session_handle++;
    g_sessions.emplace(handle, session);
    return handle;
}

std::shared_ptr<NativeSession> find_session(jlong handle) {
    if (handle == 0) return {};
    std::lock_guard<std::mutex> lock(g_sessions_mutex);
    const auto found = g_sessions.find(handle);
    return found == g_sessions.end() ? std::shared_ptr<NativeSession>{} : found->second;
}

std::shared_ptr<NativeSession> remove_session(jlong handle) {
    std::lock_guard<std::mutex> lock(g_sessions_mutex);
    const auto found = g_sessions.find(handle);
    if (found == g_sessions.end()) return {};
    auto session = found->second;
    g_sessions.erase(found);
    return session;
}

int64_t elapsed_milliseconds(std::chrono::steady_clock::time_point start) {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - start).count();
}

bool should_abort_native_compute(void * user_data) {
    const auto * session = static_cast<NativeSession *>(user_data);
    return session == nullptr || session->cancelled.load(std::memory_order_acquire) ||
           session->closing.load(std::memory_order_acquire);
}

void record_gpu_offload_evidence(NativeSession * session) {
    if (session == nullptr) return;
    const std::string logs = native_log_snapshot();
    const size_t marker = logs.rfind("offloaded ");
    if (marker == std::string::npos) return;
    const char * start = logs.c_str() + marker + std::string("offloaded ").size();
    char * end = nullptr;
    const long offloaded = std::strtol(start, &end, 10);
    if (end == start || *end != '/') return;
    const char * total_start = end + 1;
    const long total = std::strtol(total_start, &end, 10);
    if (end == total_start || std::string(end).find(" layers to GPU") == std::string::npos ||
        offloaded < 0 || total < 0 || offloaded > total) return;
    session->observed_gpu_layers = static_cast<int>(offloaded);
    session->observed_total_layers = static_cast<int>(total);
}

void ensure_backend() {
    std::call_once(g_backend_init_once, []() {
        // Capture genuine upstream engine/backend messages so the status screen can show
        // Vulkan plugin discovery and model offload evidence instead of guessed status.
        llama_log_set(capture_llama_log, nullptr);
        std::string backend_dir;
        {
            std::lock_guard<std::mutex> lock(g_backend_dir_mutex);
            backend_dir = g_backend_dir;
        }
        // v0.6.0 uses dynamically loadable backend plugins when GGML_BACKEND_DL=ON.
        // Loading them by the APK's nativeLibraryDir ensures Vulkan and CPU plugins are discoverable.
        if (!backend_dir.empty()) ggml_backend_load_all_from_path(backend_dir.c_str());
        llama_backend_init();
    });
}

std::string describe_vulkan_devices() {
    VkApplicationInfo app_info{};
    app_info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app_info.pApplicationName = "DongBaKe AI GuanJia";
    app_info.applicationVersion = 1;
    app_info.pEngineName = "llama.cpp";
    app_info.engineVersion = 1;
    app_info.apiVersion = VK_API_VERSION_1_0;

    VkInstanceCreateInfo create_info{};
    create_info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    create_info.pApplicationInfo = &app_info;

    VkInstance instance = VK_NULL_HANDLE;
    const VkResult create_result = vkCreateInstance(&create_info, nullptr, &instance);
    if (create_result != VK_SUCCESS || instance == VK_NULL_HANDLE) {
        std::ostringstream out;
        out << "Vulkan 实例创建失败（VkResult=" << static_cast<int>(create_result) << "）";
        return out.str();
    }

    uint32_t count = 0;
    VkResult result = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (result != VK_SUCCESS || count == 0) {
        vkDestroyInstance(instance, nullptr);
        return "系统 Vulkan Loader 可调用，但未枚举到物理 GPU 设备";
    }

    std::vector<VkPhysicalDevice> devices(count);
    result = vkEnumeratePhysicalDevices(instance, &count, devices.data());
    if (result != VK_SUCCESS) {
        vkDestroyInstance(instance, nullptr);
        return "Vulkan 设备枚举失败";
    }

    std::ostringstream out;
    out << "检测到 " << count << " 个 Vulkan 物理设备：";
    for (uint32_t i = 0; i < count; ++i) {
        VkPhysicalDeviceProperties props{};
        vkGetPhysicalDeviceProperties(devices[i], &props);
        if (i > 0) out << "；";
        out << props.deviceName << " (vendor=0x" << std::hex << props.vendorID
            << ", device=0x" << props.deviceID << std::dec << ")";
    }
    vkDestroyInstance(instance, nullptr);
    return out.str();
}

std::string current_engine_info() {
    ensure_backend();
    std::ostringstream out;
    const bool vulkan_plugin_registered = ggml_backend_reg_by_name("Vulkan") != nullptr;
    out << "主引擎：ggml-org/llama.cpp v0.6.0\n"
        << "构建目标：Android arm64-v8a · CPU + Vulkan 动态后端\n"
        << "Vulkan 后端插件注册：" << (vulkan_plugin_registered ? "已注册" : "未注册/加载失败") << "\n"
        << "llama.cpp GPU offload 能力：" << (llama_supports_gpu_offload() ? "后端报告支持" : "后端未报告支持") << "\n"
        << "已注册 GGML 后端数量：" << ggml_backend_reg_count() << "；可枚举 GGML 设备数量：" << ggml_backend_dev_count() << "\n"
        << describe_vulkan_devices() << "\n"
        << "说明：系统枚举到 GPU 不等于 Vulkan 插件已注册；插件注册也不等于当前模型已在 GPU 上执行。模型报告会区分请求层数和卸载配置。";
    const std::string logs = native_log_snapshot();
    if (!logs.empty()) out << "\n\n最近 llama.cpp 原生日志（最多保留 12000 字符；可查找 Vulkan 设备与模型层卸载记录）：\n" << logs;
    return out.str();
}

std::vector<jchar> utf8_to_utf16(const std::string & value) {
    std::vector<jchar> output;
    output.reserve(value.size());
    size_t i = 0;
    while (i < value.size()) {
        const uint8_t first = static_cast<uint8_t>(value[i]);
        uint32_t cp = 0xFFFD;
        size_t count = 1;
        if (first < 0x80) {
            cp = first;
        } else if ((first & 0xE0) == 0xC0 && i + 1 < value.size()) {
            const uint8_t b1 = static_cast<uint8_t>(value[i + 1]);
            if ((b1 & 0xC0) == 0x80) { cp = ((first & 0x1F) << 6) | (b1 & 0x3F); count = 2; }
        } else if ((first & 0xF0) == 0xE0 && i + 2 < value.size()) {
            const uint8_t b1 = static_cast<uint8_t>(value[i + 1]);
            const uint8_t b2 = static_cast<uint8_t>(value[i + 2]);
            if ((b1 & 0xC0) == 0x80 && (b2 & 0xC0) == 0x80) {
                cp = ((first & 0x0F) << 12) | ((b1 & 0x3F) << 6) | (b2 & 0x3F); count = 3;
            }
        } else if ((first & 0xF8) == 0xF0 && i + 3 < value.size()) {
            const uint8_t b1 = static_cast<uint8_t>(value[i + 1]);
            const uint8_t b2 = static_cast<uint8_t>(value[i + 2]);
            const uint8_t b3 = static_cast<uint8_t>(value[i + 3]);
            if ((b1 & 0xC0) == 0x80 && (b2 & 0xC0) == 0x80 && (b3 & 0xC0) == 0x80) {
                cp = ((first & 0x07) << 18) | ((b1 & 0x3F) << 12) | ((b2 & 0x3F) << 6) | (b3 & 0x3F); count = 4;
            }
        }
        i += count;
        if (cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) cp = 0xFFFD;
        if (cp <= 0xFFFF) {
            output.push_back(static_cast<jchar>(cp));
        } else {
            cp -= 0x10000;
            output.push_back(static_cast<jchar>(0xD800 + (cp >> 10)));
            output.push_back(static_cast<jchar>(0xDC00 + (cp & 0x3FF)));
        }
    }
    return output;
}

size_t complete_utf8_prefix_length(const std::string & value) {
    size_t i = 0;
    while (i < value.size()) {
        const uint8_t first = static_cast<uint8_t>(value[i]);
        size_t count = 1;
        if ((first & 0x80) == 0) count = 1;
        else if ((first & 0xE0) == 0xC0) count = 2;
        else if ((first & 0xF0) == 0xE0) count = 3;
        else if ((first & 0xF8) == 0xF0) count = 4;
        else { ++i; continue; }
        if (i + count > value.size()) break;
        bool continuations_valid = true;
        for (size_t j = 1; j < count; ++j) {
            if ((static_cast<uint8_t>(value[i + j]) & 0xC0) != 0x80) { continuations_valid = false; break; }
        }
        if (!continuations_valid) { ++i; continue; }
        i += count;
    }
    return i;
}

jstring to_java_string(JNIEnv * env, const std::string & value) {
    const auto utf16 = utf8_to_utf16(value);
    static const jchar kEmpty = 0;
    return env->NewString(utf16.empty() ? &kEmpty : utf16.data(), static_cast<jsize>(utf16.size()));
}

std::string apply_chat_template(NativeSession * session, const std::string & system_prompt, const std::string & prompt) {
    const char * tmpl = llama_model_chat_template(session->model, nullptr);
    if (tmpl == nullptr || tmpl[0] == '\0') {
        return system_prompt + "\n\n" + prompt;
    }
    const llama_chat_message messages[] = {
        {"system", system_prompt.c_str()},
        {"user", prompt.c_str()}
    };
    int32_t needed = llama_chat_apply_template(tmpl, messages, 2, true, nullptr, 0);
    if (needed < 0) {
        __android_log_print(ANDROID_LOG_WARN, kLogTag, "Chat template unsupported; using plain system/user prompt.");
        return system_prompt + "\n\n" + prompt;
    }
    std::vector<char> buffer(static_cast<size_t>(needed) + 1, '\0');
    int32_t written = llama_chat_apply_template(tmpl, messages, 2, true, buffer.data(), static_cast<int32_t>(buffer.size()));
    if (written < 0) return system_prompt + "\n\n" + prompt;
    return std::string(buffer.data(), static_cast<size_t>(std::min<int32_t>(written, static_cast<int32_t>(buffer.size() - 1))));
}

bool tokenise_prompt(const llama_vocab * vocab, const std::string & prompt, std::vector<llama_token> & tokens) {
    const int32_t needed = llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, true);
    if (needed >= 0) {
        tokens.resize(static_cast<size_t>(needed));
    } else {
        tokens.resize(static_cast<size_t>(-needed));
    }
    if (tokens.empty()) return false;
    const int32_t written = llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), tokens.data(), static_cast<int32_t>(tokens.size()), true, true);
    if (written < 0) return false;
    tokens.resize(static_cast<size_t>(written));
    return !tokens.empty();
}

void emit_token(JNIEnv * env, jobject listener, jmethodID method, const std::string & piece) {
    if (piece.empty() || listener == nullptr || method == nullptr) return;
    jstring value = to_java_string(env, piece);
    if (value == nullptr) return;
    env->CallVoidMethod(listener, method, value);
    env->DeleteLocalRef(value);
}
} // namespace

extern "C" JNIEXPORT void JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeInitializeBackend(JNIEnv * env, jobject /* thiz */, jstring java_library_dir) {
    if (java_library_dir == nullptr) return;
    const char * directory = env->GetStringUTFChars(java_library_dir, nullptr);
    if (directory == nullptr) return;
    {
        std::lock_guard<std::mutex> lock(g_backend_dir_mutex);
        if (g_backend_dir.empty()) g_backend_dir = directory;
    }
    env->ReleaseStringUTFChars(java_library_dir, directory);
    try { ensure_backend(); }
    catch (...) { __android_log_print(ANDROID_LOG_ERROR, kLogTag, "Failed to initialize llama.cpp backends."); }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeEngineInfo(JNIEnv * env, jobject /* thiz */) {
    try {
        return to_java_string(env, current_engine_info());
    } catch (...) {
        return to_java_string(env, "llama.cpp v0.6.0 · CPU/Vulkan 状态读取发生未知错误");
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLastLogTail(JNIEnv * env, jobject /* thiz */) {
    try { return to_java_string(env, native_log_snapshot()); }
    catch (...) { return to_java_string(env, "读取原生日志失败"); }
}

extern "C" JNIEXPORT void JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeClearLogTail(JNIEnv * /* env */, jobject /* thiz */) {
    try {
        std::lock_guard<std::mutex> lock(g_native_log_mutex);
        g_native_log_tail.clear();
    } catch (...) {
        __android_log_print(ANDROID_LOG_WARN, kLogTag, "Could not clear native log tail.");
    }
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLoadModel(JNIEnv * env, jobject /* thiz */, jstring java_path,
                                                         jint context_size, jint threads, jint gpu_layers,
                                                         jint kv_cache_quantization, jboolean gpu_flash_attention) {
    if (java_path == nullptr) return 0;
    const char * path_chars = env->GetStringUTFChars(java_path, nullptr);
    if (path_chars == nullptr) return 0;
    const std::string path(path_chars);
    env->ReleaseStringUTFChars(java_path, path_chars);

    try {
        ensure_backend();
        auto session = std::make_shared<NativeSession>();
        session->context_size = std::max(512, static_cast<int>(context_size));
        session->threads = std::max(1, static_cast<int>(threads));
        session->requested_gpu_layers = std::max(0, static_cast<int>(gpu_layers));
        session->kv_cache_quantization = kv_cache_quantization == 1 ? 1 : 0;
        session->gpu_flash_attention = gpu_flash_attention == JNI_TRUE;
        session->model_path = path;

        bool vulkan_plugin_registered = false;
        bool gpu_build_available = false;
        bool device_seen = false;
        int chosen_layers = 0;
        // Stability mode is CPU-only by default. Do not load/probe Vulkan drivers unless GPU offload was explicitly requested.
        if (session->requested_gpu_layers > 0) {
            vulkan_plugin_registered = ggml_backend_reg_by_name("Vulkan") != nullptr;
            gpu_build_available = vulkan_plugin_registered && llama_supports_gpu_offload();
            const std::string device_report = describe_vulkan_devices();
            device_seen = device_report.find("检测到 ") == 0;
            if (gpu_build_available && device_seen) chosen_layers = session->requested_gpu_layers;
        }

        if (session->requested_gpu_layers > 0 && chosen_layers == 0) {
            record_native_event(ANDROID_LOG_WARN,
                "gpu_offload_unavailable requested_layers=" + std::to_string(session->requested_gpu_layers) +
                " vulkan_plugin_registered=" + std::string(vulkan_plugin_registered ? "true" : "false") +
                " gpu_build_available=" + std::string(gpu_build_available ? "true" : "false") +
                " device_seen=" + std::string(device_seen ? "true" : "false") +
                " fallback=CPU");
        }

        auto load_with_layers = [&](int layers) -> llama_model * {
            llama_model_params params = llama_model_default_params();
            params.n_gpu_layers = layers;
            // IMPORTANT for Android CPU mode: AUTO inspects every registered device and may
            // disable mmap because an unused Vulkan device does not advertise mmap support.
            // That can turn a 2.8 GB file-backed model into a multi-GB resident allocation.
            // CPU-only loading explicitly forces mmap; GPU-offload requests retain AUTO behavior.
            params.load_mode = layers == 0 ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_AUTO;
            record_native_event(ANDROID_LOG_INFO,
                std::string("model_load_params layers=") + std::to_string(layers) +
                " load_mode=" + (layers == 0 ? "MMAP" : "AUTO") +
                " use_extra_bufts=" + (params.use_extra_bufts ? "true" : "false"));
            return llama_model_load_from_file(path.c_str(), params);
        };

        record_native_event(ANDROID_LOG_INFO,
            "model_load_begin context=" + std::to_string(session->context_size) +
            " threads=" + std::to_string(session->threads) +
            " requested_gpu_layers=" + std::to_string(session->requested_gpu_layers) +
            " kv_cache=" + std::string(session->kv_cache_quantization == 1 ? "Q8_0" : "F16") +
            " gpu_flash_attention=" + std::string(session->gpu_flash_attention ? "auto" : "disabled") +
            " file=" + path);
        session->model = load_with_layers(chosen_layers);
        if (session->model == nullptr && chosen_layers > 0) {
            record_native_event(ANDROID_LOG_WARN, "GPU model-load path failed; retrying CPU-only.");
            session->cpu_retry_used = true;
            chosen_layers = 0;
            session->model = load_with_layers(0);
        }
        if (session->model == nullptr) {
            record_native_event(ANDROID_LOG_ERROR, "llama_model_load_from_file returned null; model loading failed. Check the captured llama.cpp log tail.");
            return 0;
        }

        session->active_gpu_layers = chosen_layers;
        if (!gpu_build_available || !device_seen) session->active_gpu_layers = 0;
        record_gpu_offload_evidence(session.get());
        __android_log_print(ANDROID_LOG_INFO, kLogTag,
                            "Model loaded. requested_gpu_layers=%d active_gpu_layers_config=%d cpu_threads=%d gpu_build=%d vulkan_device=%d cpu_retry=%d",
                            session->requested_gpu_layers, session->active_gpu_layers, session->threads,
                            gpu_build_available ? 1 : 0, device_seen ? 1 : 0, session->cpu_retry_used ? 1 : 0);
        record_native_event(ANDROID_LOG_INFO, "model_load_success active_gpu_layers_config=" + std::to_string(session->active_gpu_layers));
        return register_session(session);
    } catch (const std::exception & error) {
        record_native_event(ANDROID_LOG_ERROR, std::string("nativeLoadModel exception: ") + error.what());
        return 0;
    } catch (...) {
        record_native_event(ANDROID_LOG_ERROR, "nativeLoadModel failed with an unknown native exception.");
        return 0;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeGenerate(JNIEnv * env, jobject /* thiz */, jlong handle,
                                                        jstring java_prompt, jstring java_system_prompt,
                                                        jint max_tokens, jobject listener) {
    auto session = find_session(handle);
    if (!session || java_prompt == nullptr || java_system_prompt == nullptr) {
        return to_java_string(env, "当前原生模型不可用或 CPU 后备失败，请重新加载 GGUF 模型。");
    }
    const char * prompt_chars = env->GetStringUTFChars(java_prompt, nullptr);
    const char * system_chars = env->GetStringUTFChars(java_system_prompt, nullptr);
    if (prompt_chars == nullptr || system_chars == nullptr) {
        if (prompt_chars) env->ReleaseStringUTFChars(java_prompt, prompt_chars);
        if (system_chars) env->ReleaseStringUTFChars(java_system_prompt, system_chars);
        return to_java_string(env, "");
    }
    const std::string raw_prompt(prompt_chars);
    const std::string system_prompt(system_chars);
    env->ReleaseStringUTFChars(java_prompt, prompt_chars);
    env->ReleaseStringUTFChars(java_system_prompt, system_chars);

    std::lock_guard<std::mutex> generation_lock(session->generation_mutex);
    if (session->closing.load(std::memory_order_acquire) || session->model == nullptr) {
        return to_java_string(env, "当前模型正在释放或不可用，请重新加载后再提问。");
    }
    // Cancellation is reset by the Kotlin caller immediately before this JNI call.
    // Do not reset here: a user cancel racing with JNI entry must not be lost.
    llama_context * ctx = nullptr;
    llama_sampler * sampler = nullptr;
    std::string answer;
    std::string pending_stream_text;
    jclass listener_class = nullptr;
    const auto inference_started = std::chrono::steady_clock::now();
    session->last_prompt_tokens = 0;
    session->last_generated_tokens = 0;
    session->last_first_token_ms = -1;
    session->last_prefill_ms = -1;
    session->last_decode_ms = -1;
    session->last_inference_cancelled = false;
    try {
        record_native_event(ANDROID_LOG_INFO,
            "inference_begin context=" + std::to_string(session->context_size) +
            " threads=" + std::to_string(session->threads) +
            " gpu_layers=" + std::to_string(session->active_gpu_layers) +
            " user_prompt_chars=" + std::to_string(raw_prompt.size()) +
            " system_prompt_chars=" + std::to_string(system_prompt.size()));
        const std::string formatted = apply_chat_template(session.get(), system_prompt, raw_prompt);
        record_native_event(ANDROID_LOG_INFO, "chat_template_complete formatted_chars=" + std::to_string(formatted.size()));
        const llama_vocab * vocab = llama_model_get_vocab(session->model);
        std::vector<llama_token> prompt_tokens;
        record_native_event(ANDROID_LOG_INFO, "tokenization_begin formatted_chars=" + std::to_string(formatted.size()));
        if (!tokenise_prompt(vocab, formatted, prompt_tokens)) {
            return to_java_string(env, "模型输入无法转换为 Token，请检查模型模板或输入内容。");
        }

        record_native_event(ANDROID_LOG_INFO, "tokenization_complete prompt_tokens=" + std::to_string(prompt_tokens.size()));
        const int output_limit = std::min(std::max(1, static_cast<int>(max_tokens)), std::max(1, session->context_size - 64));
        const size_t max_prompt_tokens = static_cast<size_t>(std::max(64, session->context_size - output_limit));
        if (prompt_tokens.size() > max_prompt_tokens) {
            // Keep the tail of the formatted prompt so the immediate question remains present.
            prompt_tokens.erase(prompt_tokens.begin(), prompt_tokens.begin() + static_cast<std::ptrdiff_t>(prompt_tokens.size() - max_prompt_tokens));
        }
        session->last_prompt_tokens = static_cast<int>(prompt_tokens.size());

        llama_context_params ctx_params = llama_context_default_params();
        ctx_params.n_ctx = static_cast<uint32_t>(session->context_size);
        // Keep the full requested context/KV capacity, but bound each prompt prefill batch.
        // Chunked prefill below avoids allocating a context-sized compute batch for long prompts.
        ctx_params.n_batch = static_cast<uint32_t>(std::min(session->context_size, 512));
        ctx_params.n_ubatch = std::min<uint32_t>(ctx_params.n_ubatch, ctx_params.n_batch);
        ctx_params.n_threads = session->threads;
        ctx_params.n_threads_batch = session->threads;
        // F16 is the compatibility-first default. Q8_0 is an explicit experimental
        // option for memory-constrained devices and remains opt-in by the user.
        const enum ggml_type cache_type = session->kv_cache_quantization == 1
            ? GGML_TYPE_Q8_0 : GGML_TYPE_F16;
        ctx_params.type_k = cache_type;
        ctx_params.type_v = cache_type;
        // On Android AArch64, keep CPU Flash Attention disabled for the portable path.
        // GPU Flash Attention stays opt-in through settings and is disabled for Q8_0 KV
        // cache because this combination is not uniformly supported by backend builds.
        const bool gpu_flash_attention_enabled = session->active_gpu_layers > 0 &&
            session->gpu_flash_attention && session->kv_cache_quantization == 0;
        ctx_params.flash_attn_type = gpu_flash_attention_enabled
            ? LLAMA_FLASH_ATTN_TYPE_AUTO : LLAMA_FLASH_ATTN_TYPE_DISABLED;
        ctx_params.offload_kqv = session->active_gpu_layers > 0 && session->kv_cache_quantization == 0;
        // Upstream abort callback lets native stop interrupt a running graph/decode,
        // not merely the Kotlin coroutine or the gap between batches/tokens.
        ctx_params.abort_callback = should_abort_native_compute;
        ctx_params.abort_callback_data = session.get();
        ctx_params.no_perf = false;
        record_native_event(ANDROID_LOG_INFO,
            std::string("context_init_begin flash_attention=") +
            (ctx_params.flash_attn_type == LLAMA_FLASH_ATTN_TYPE_DISABLED ? "disabled" : "auto") +
            " offload_kqv=" + (ctx_params.offload_kqv ? "true" : "false") +
            " kv_cache=" + std::string(session->kv_cache_quantization == 1 ? "Q8_0" : "F16") +
            " abort_callback=enabled" +
            " n_ctx=" + std::to_string(ctx_params.n_ctx) +
            " n_batch=" + std::to_string(ctx_params.n_batch) +
            " n_ubatch=" + std::to_string(ctx_params.n_ubatch));
        ctx = llama_init_from_model(session->model, ctx_params);
        if (ctx == nullptr) {
            record_native_event(ANDROID_LOG_ERROR, "llama_init_from_model returned null; contextSize=" + std::to_string(session->context_size));
            if (session->active_gpu_layers > 0) return to_java_string(env, "__DONGBAKE_GPU_RETRY_CPU__");
            return to_java_string(env, "无法创建本地推理上下文，可能是内存不足或模型与上下文设置不兼容。");
        }

        record_native_event(ANDROID_LOG_INFO, "context_init_complete; beginning sampler initialization.");
        sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
        if (sampler == nullptr) {
            record_native_event(ANDROID_LOG_ERROR, "llama_sampler_chain_init returned null.");
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, "无法初始化 Token 采样器。");
        }
        llama_sampler * temp_sampler = llama_sampler_init_temp(0.7f);
        llama_sampler * dist_sampler = llama_sampler_init_dist(LLAMA_DEFAULT_SEED);
        if (temp_sampler == nullptr || dist_sampler == nullptr) {
            if (temp_sampler) llama_sampler_free(temp_sampler);
            if (dist_sampler) llama_sampler_free(dist_sampler);
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            record_native_event(ANDROID_LOG_ERROR, "A llama sampler could not be allocated.");
            return to_java_string(env, "无法分配 Token 采样器，可能是内存不足。");
        }
        llama_sampler_chain_add(sampler, temp_sampler);
        llama_sampler_chain_add(sampler, dist_sampler);
        record_native_event(ANDROID_LOG_INFO, "sampler_init_complete; prompt_prefill_begin tokens=" + std::to_string(prompt_tokens.size()));

        int32_t prefill_result = 0;
        size_t prefill_offset = 0;
        const auto prefill_started = std::chrono::steady_clock::now();
        while (prefill_offset < prompt_tokens.size()) {
            if (session->cancelled.load(std::memory_order_acquire)) break;
            const size_t chunk_count = std::min<size_t>(ctx_params.n_batch, prompt_tokens.size() - prefill_offset);
            record_native_event(ANDROID_LOG_INFO, "prompt_prefill_batch_begin offset=" + std::to_string(prefill_offset) +
                " count=" + std::to_string(chunk_count));
            llama_batch prompt_batch = llama_batch_get_one(
                prompt_tokens.data() + prefill_offset, static_cast<int32_t>(chunk_count));
            prefill_result = llama_decode(ctx, prompt_batch);
            if (prefill_result != 0) {
                record_native_event(ANDROID_LOG_ERROR, "prompt_prefill_batch_failed result=" + std::to_string(prefill_result));
                break;
            }
            prefill_offset += chunk_count;
            record_native_event(ANDROID_LOG_INFO, "prompt_prefill_batch_complete offset=" + std::to_string(prefill_offset));
        }
        session->last_prefill_ms = elapsed_milliseconds(prefill_started);
        if (session->cancelled.load(std::memory_order_acquire)) {
            session->last_inference_cancelled = true;
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, answer);
        }
        if (prefill_result != 0) {
            record_native_event(ANDROID_LOG_ERROR, "Prompt prefill failed with llama_decode=" + std::to_string(prefill_result));
            if (session->active_gpu_layers > 0) {
                llama_sampler_free(sampler); sampler = nullptr;
                llama_free(ctx); ctx = nullptr;
                return to_java_string(env, "__DONGBAKE_GPU_RETRY_CPU__");
            }
            llama_sampler_free(sampler); sampler = nullptr;
            llama_free(ctx); ctx = nullptr;
            return to_java_string(env, "模型预填充失败（llama_decode=" + std::to_string(prefill_result) + "）。");
        }

        record_native_event(ANDROID_LOG_INFO, "prompt_prefill_complete tokens=" + std::to_string(prefill_offset) + "; first_sampler_sample_begin.");
        listener_class = listener ? env->GetObjectClass(listener) : nullptr;
        jmethodID on_token = listener_class ? env->GetMethodID(listener_class, "onToken", "(Ljava/lang/String;)V") : nullptr;
        std::vector<char> piece_buffer(256, '\0');
        const auto decode_started = std::chrono::steady_clock::now();
        for (int32_t generated = 0; generated < output_limit; ++generated) {
            if (session->cancelled.load(std::memory_order_acquire)) break;
            if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_sampler_sample_begin");
            llama_token token = llama_sampler_sample(sampler, ctx, -1);
            if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_sampler_sample_complete token_id=" + std::to_string(token));
            if (llama_vocab_is_eog(vocab, token)) {
                record_native_event(ANDROID_LOG_INFO, "sampler_emitted_end_of_generation");
                break;
            }
            ++session->last_generated_tokens;

            std::fill(piece_buffer.begin(), piece_buffer.end(), '\0');
            if (piece_buffer.size() < 256) piece_buffer.resize(256);
            int32_t piece_size = llama_token_to_piece(vocab, token, piece_buffer.data(), static_cast<int32_t>(piece_buffer.size()), 0, false);
            if (piece_size < 0) {
                piece_buffer.resize(static_cast<size_t>(-piece_size) + 1);
                piece_size = llama_token_to_piece(vocab, token, piece_buffer.data(), static_cast<int32_t>(piece_buffer.size()), 0, false);
            }
            if (piece_size > 0) {
                const std::string piece(piece_buffer.data(), static_cast<size_t>(piece_size));
                answer += piece;
                pending_stream_text += piece;
                const size_t safe_prefix = complete_utf8_prefix_length(pending_stream_text);
                if (safe_prefix > 0) {
                    emit_token(env, listener, on_token, pending_stream_text.substr(0, safe_prefix));
                    if (session->last_first_token_ms < 0) {
                        session->last_first_token_ms = elapsed_milliseconds(inference_started);
                        record_native_event(ANDROID_LOG_INFO, "first_visible_token_ms=" + std::to_string(session->last_first_token_ms));
                    }
                    pending_stream_text.erase(0, safe_prefix);
                }
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    session->cancelled.store(true, std::memory_order_release);
                    break;
                }
            }

            if (generated + 1 < output_limit && !session->cancelled.load(std::memory_order_acquire)) {
                // llama_batch_get_one tracks position for a single sequence automatically.
                if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_generated_token_decode_begin");
                llama_batch next_batch = llama_batch_get_one(&token, 1);
                const int32_t decode_result = llama_decode(ctx, next_batch);
                if (generated == 0) record_native_event(ANDROID_LOG_INFO, "first_generated_token_decode_complete result=" + std::to_string(decode_result));
                if (decode_result != 0) {
                    record_native_event(ANDROID_LOG_WARN, "Decode stopped with result=" + std::to_string(decode_result) + " after " + std::to_string(generated + 1) + " tokens.");
                    break;
                }
            }
        }
        if (!pending_stream_text.empty() && !session->cancelled.load(std::memory_order_acquire)) {
            emit_token(env, listener, on_token, pending_stream_text);
            if (session->last_first_token_ms < 0) session->last_first_token_ms = elapsed_milliseconds(inference_started);
        }
        session->last_decode_ms = elapsed_milliseconds(decode_started);
        session->last_inference_cancelled = session->cancelled.load(std::memory_order_acquire);
        record_native_event(ANDROID_LOG_INFO,
            "inference_complete generated_chars=" + std::to_string(answer.size()) +
            " prompt_tokens=" + std::to_string(session->last_prompt_tokens) +
            " generated_tokens=" + std::to_string(session->last_generated_tokens) +
            " first_visible_token_ms=" + std::to_string(session->last_first_token_ms) +
            " prefill_ms=" + std::to_string(session->last_prefill_ms) +
            " decode_ms=" + std::to_string(session->last_decode_ms) +
            " cancelled=" + std::string(session->last_inference_cancelled ? "true" : "false"));
    } catch (const std::exception & error) {
        record_native_event(ANDROID_LOG_ERROR, std::string("Native inference exception: ") + error.what());
    } catch (...) {
        record_native_event(ANDROID_LOG_ERROR, "Unhandled native inference exception.");
    }
    if (listener_class) env->DeleteLocalRef(listener_class);
    if (sampler) llama_sampler_free(sampler);
    if (ctx) llama_free(ctx);
    return to_java_string(env, answer);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeRetryCpuOnly(JNIEnv * /* env */, jobject /* thiz */, jlong handle) {
    auto session = find_session(handle);
    if (!session) return JNI_FALSE;
    std::lock_guard<std::mutex> lock(session->generation_mutex);
    if (session->closing.load(std::memory_order_acquire) || session->cancelled.load(std::memory_order_acquire) || session->model == nullptr || session->model_path.empty()) return JNI_FALSE;
    const std::string model_path = session->model_path;
    // Drop the GPU-configured model before loading the CPU copy to avoid two full model copies in RAM.
    llama_model_free(session->model);
    session->model = nullptr;
    llama_model_params params = llama_model_default_params();
    params.n_gpu_layers = 0;
    params.load_mode = LLAMA_LOAD_MODE_MMAP;
    record_native_event(ANDROID_LOG_WARN, "gpu_to_cpu_retry_load_params layers=0 load_mode=MMAP");
    llama_model * cpu_model = llama_model_load_from_file(model_path.c_str(), params);
    if (cpu_model == nullptr) {
        record_native_event(ANDROID_LOG_ERROR, "gpu_to_cpu_retry_model_load_failed load_mode=MMAP");
        return JNI_FALSE;
    }
    if (session->closing.load(std::memory_order_acquire) || session->cancelled.load(std::memory_order_acquire)) {
        llama_model_free(cpu_model);
        return JNI_FALSE;
    }
    session->model = cpu_model;
    session->active_gpu_layers = 0;
    session->cpu_retry_used = true;
    // Keep the cancellation flag untouched: cancellation may race with this reload.
    __android_log_print(ANDROID_LOG_WARN, kLogTag, "GPU prefill failed; model reloaded CPU-only as fallback.");
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeResetCancel(JNIEnv * /* env */, jobject /* thiz */, jlong handle) {
    auto session = find_session(handle);
    if (session && !session->closing.load(std::memory_order_acquire)) {
        session->cancelled.store(false, std::memory_order_release);
        // Close/cancel may race between the first check and store; prefer stopping.
        if (session->closing.load(std::memory_order_acquire)) session->cancelled.store(true, std::memory_order_release);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeCancel(JNIEnv * /* env */, jobject /* thiz */, jlong handle) {
    auto session = find_session(handle);
    if (session) session->cancelled.store(true, std::memory_order_release);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeReleaseModel(JNIEnv * /* env */, jobject /* thiz */, jlong handle) {
    auto session = remove_session(handle);
    if (!session) return;
    session->closing.store(true, std::memory_order_release);
    session->cancelled.store(true, std::memory_order_release);
    {
        std::lock_guard<std::mutex> lock(session->generation_mutex);
        if (session->model) llama_model_free(session->model);
        session->model = nullptr;
    }
    // Any JNI calls that already acquired a shared reference will observe closing
    // under the mutex and return safely; the object is destroyed after their refs end.
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLastInferenceMetrics(JNIEnv * env, jobject /* thiz */, jlong handle) {
    auto session = find_session(handle);
    if (!session) return to_java_string(env, "available=false; reason=no_model");
    std::lock_guard<std::mutex> lock(session->generation_mutex);
    const double tokens_per_second = session->last_decode_ms > 0
        ? (static_cast<double>(session->last_generated_tokens) * 1000.0 / static_cast<double>(session->last_decode_ms))
        : 0.0;
    std::ostringstream out;
    out << "promptTokens=" << session->last_prompt_tokens
        << "; generatedTokens=" << session->last_generated_tokens
        << "; firstVisibleTokenMs=" << session->last_first_token_ms
        << "; prefillMs=" << session->last_prefill_ms
        << "; decodeMs=" << session->last_decode_ms
        << "; decodeTokensPerSecond=" << std::fixed << std::setprecision(2) << tokens_per_second
        << "; cancelled=" << (session->last_inference_cancelled ? "true" : "false");
    return to_java_string(env, out.str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aiguanjia_app_NativeLlamaEngine_nativeLoadedModelInfo(JNIEnv * env, jobject /* thiz */, jlong handle) {
    auto session = find_session(handle);
    if (!session) return to_java_string(env, "当前没有加载模型。");
    std::lock_guard<std::mutex> lock(session->generation_mutex);
    if (session->model == nullptr || session->closing.load(std::memory_order_acquire)) return to_java_string(env, "当前没有加载模型。");
    std::ostringstream out;
    out << "模型：已加载至 llama.cpp\n"
        << "CPU 线程：" << session->threads << "\n"
        << "上下文长度：" << session->context_size << " tokens\n"
        << "GPU 卸载请求层数：" << session->requested_gpu_layers << "\n"
        << "GPU 后端/设备检测后的卸载配置：" << session->active_gpu_layers << " 层\n"
        << "实际层卸载日志证据：";
    if (session->observed_gpu_layers >= 0 && session->observed_total_layers >= 0) {
        out << session->observed_gpu_layers << "/" << session->observed_total_layers << " 层被报告卸载到 GPU\n";
    } else {
        out << "尚未从本次加载日志中解析到\n";
    }
    out << "KV Cache 类型：" << (session->kv_cache_quantization == 1 ? "Q8_0（实验性）" : "F16（默认）") << "\n"
        << "GPU Flash Attention：" << (session->gpu_flash_attention ? "允许 AUTO（仍受 GPU/KV 配置限制）" : "用户已关闭") << "\n"
        << "CPU 后备：" << (session->cpu_retry_used ? "已在加载阶段回退到 CPU" : "保留在原生引擎中；GPU 路径失败时会尝试 CPU") << "\n"
        << "注意：后端发现、卸载配置和日志报告是不同层级的证据；这些信息不能单独证明 GPU 实际计算性能。";
    return to_java_string(env, out.str());
}
