#!/usr/bin/env bash
# Build upstream llama.cpp v0.6.0 for Android arm64-v8a with CPU + dynamic Vulkan backend plugins.
# The JNI bridge loads ggml plugins from ApplicationInfo.nativeLibraryDir at runtime.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LLAMA_CPP_TAG="v0.6.0"
LLAMA_CPP_SOURCE_DIR="${LLAMA_CPP_SOURCE_DIR:-${ROOT_DIR}/third_party/llama.cpp}"
LLAMA_CPP_BUILD_DIR="${LLAMA_CPP_BUILD_DIR:-${ROOT_DIR}/build/llama.cpp-android-vulkan}"
LLAMA_CPP_INSTALL_DIR="${LLAMA_CPP_INSTALL_DIR:-${ROOT_DIR}/build/llama.cpp-install-android-vulkan}"
ANDROID_ABIS="${ANDROID_ABIS:-arm64-v8a x86_64}"
ANDROID_NDK="${ANDROID_NDK:-${ANDROID_HOME:-}/ndk/27.2.12479018}"
BUILD_JOBS="${BUILD_JOBS:-2}"

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 2; }
[[ -n "$ANDROID_NDK" && -f "$ANDROID_NDK/build/cmake/android.toolchain.cmake" ]] || \
  fail "Android NDK not found. Set ANDROID_NDK to an installed NDK root (CI pins r27c)."
command -v git >/dev/null 2>&1 || fail "git is required to fetch the pinned upstream source."
CMAKE_BIN="${CMAKE_BIN:-}"
if [[ -z "$CMAKE_BIN" && -n "${ANDROID_HOME:-}" && -x "$ANDROID_HOME/cmake/3.22.1/bin/cmake" ]]; then
  CMAKE_BIN="$ANDROID_HOME/cmake/3.22.1/bin/cmake"
fi
if [[ -z "$CMAKE_BIN" ]]; then CMAKE_BIN="$(command -v cmake || true)"; fi
[[ -n "$CMAKE_BIN" && -x "$CMAKE_BIN" ]] || fail "cmake is required. Install CMake 3.22.1 or compatible."
export PATH="$(dirname "$CMAKE_BIN"):$PATH"
command -v ninja >/dev/null 2>&1 || fail "ninja is required by this build. Install it or ensure it is on PATH."
command -v glslc >/dev/null 2>&1 || fail "glslc is required for Vulkan shader compilation; install a host glslc package."

SPIRV_HEADERS_CONFIG="${SPIRV_HEADERS_CONFIG:-}"
if [[ -z "$SPIRV_HEADERS_CONFIG" ]]; then
  for candidate in \
    /usr/share/spirv_headers/cmake/SPIRV-HeadersConfig.cmake \
    /usr/lib/cmake/SPIRV-Headers/SPIRV-HeadersConfig.cmake \
    /usr/lib/x86_64-linux-gnu/cmake/SPIRV-Headers/SPIRV-HeadersConfig.cmake; do
    if [[ -f "$candidate" ]]; then SPIRV_HEADERS_CONFIG="$candidate"; break; fi
  done
  if [[ -z "$SPIRV_HEADERS_CONFIG" ]]; then
    SPIRV_HEADERS_CONFIG="$(find /usr /opt -type f -name 'SPIRV-HeadersConfig.cmake' -print -quit 2>/dev/null || true)"
  fi
fi
[[ -n "$SPIRV_HEADERS_CONFIG" && -f "$SPIRV_HEADERS_CONFIG" ]] || \
  fail "SPIRV-Headers CMake package not found. Install spirv-headers or set SPIRV_HEADERS_CONFIG."
SPIRV_HEADERS_DIR="$(dirname "$SPIRV_HEADERS_CONFIG")"

VULKAN_HEADERS_DIR="${VULKAN_HEADERS_DIR:-${ROOT_DIR}/build/Vulkan-Headers}"
if [[ ! -f "$VULKAN_HEADERS_DIR/include/vulkan/vulkan.hpp" ]]; then
  rm -rf "$VULKAN_HEADERS_DIR"
  git clone --depth 1 --branch "v1.3.296" https://github.com/KhronosGroup/Vulkan-Headers.git "$VULKAN_HEADERS_DIR"
fi
[[ -f "$VULKAN_HEADERS_DIR/include/vulkan/vulkan.hpp" ]] || fail "Vulkan-Headers C++ wrapper was not downloaded correctly."
if [[ ! -f "$VULKAN_HEADERS_DIR/include/spirv/unified1/spirv.hpp" ]]; then
  SPIRV_HEADER_FILE="$(find /usr/include /opt -type f -path '*/spirv/unified1/spirv.hpp' -print -quit 2>/dev/null || true)"
  [[ -n "$SPIRV_HEADER_FILE" ]] || fail "SPIRV-Headers unified1/spirv.hpp was not found."
  SPIRV_INCLUDE_ROOT="$(dirname "$(dirname "$(dirname "$SPIRV_HEADER_FILE")")")"
  cp -a "$SPIRV_INCLUDE_ROOT/spirv" "$VULKAN_HEADERS_DIR/include/"
fi

if [[ ! -d "$LLAMA_CPP_SOURCE_DIR/.git" ]]; then
  mkdir -p "$(dirname "$LLAMA_CPP_SOURCE_DIR")"
  git clone --filter=blob:none https://github.com/ggml-org/llama.cpp.git "$LLAMA_CPP_SOURCE_DIR"
fi

git -C "$LLAMA_CPP_SOURCE_DIR" fetch --depth 1 origin "refs/tags/${LLAMA_CPP_TAG}:refs/tags/${LLAMA_CPP_TAG}"
git -C "$LLAMA_CPP_SOURCE_DIR" checkout --detach "$LLAMA_CPP_TAG"
actual_commit="$(git -C "$LLAMA_CPP_SOURCE_DIR" rev-parse HEAD)"
actual_tag="$(git -C "$LLAMA_CPP_SOURCE_DIR" describe --tags --exact-match HEAD 2>/dev/null || true)"
[[ "$actual_tag" == "$LLAMA_CPP_TAG" ]] || fail "Upstream tag verification failed: expected $LLAMA_CPP_TAG, got ${actual_tag:-no tag}"

printf '%s\n' "Upstream llama.cpp tag: $actual_tag" "Resolved commit: $actual_commit" \
  "Target ABIs: $ANDROID_ABIS" "CPU backend: ON" "Vulkan backend: ON" \
  "Dynamic backend loading: ON" "Install base directory: $LLAMA_CPP_INSTALL_DIR"

for abi in $ANDROID_ABIS; do
  case "$abi" in arm64-v8a|x86_64) ;; *) fail "Unsupported ABI requested: $abi (supported: arm64-v8a x86_64)" ;; esac
  ABI_BUILD_DIR="${LLAMA_CPP_BUILD_DIR}-${abi}"
  ABI_INSTALL_DIR="${LLAMA_CPP_INSTALL_DIR}/${abi}"
  JNI_LIB_DIR="${ROOT_DIR}/app/src/main/jniLibs/${abi}"
  printf '\n=== Building llama.cpp for ABI %s ===\n' "$abi"
  "$CMAKE_BIN" -S "$LLAMA_CPP_SOURCE_DIR" -B "$ABI_BUILD_DIR" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$abi" \
    -DANDROID_PLATFORM=android-29 \
    -DBUILD_SHARED_LIBS=ON \
    -DLLAMA_BUILD_TESTS=OFF \
    -DLLAMA_BUILD_TOOLS=OFF \
    -DLLAMA_BUILD_EXAMPLES=OFF \
    -DLLAMA_BUILD_SERVER=OFF \
    -DLLAMA_BUILD_APP=OFF \
    -DLLAMA_BUILD_COMMON=OFF \
    -DGGML_NATIVE=OFF \
    -DGGML_CPU=ON \
    -DGGML_BACKEND_DL=ON \
    -DGGML_OPENMP=OFF \
    -DGGML_LLAMAFILE=OFF \
    -DLLAMA_OPENSSL=OFF \
    -DGGML_VULKAN=ON \
    -DGGML_VULKAN_CHECK_RESULTS=OFF \
    -DVulkan_GLSLC_EXECUTABLE="$(command -v glslc)" \
    -DVulkan_INCLUDE_DIR="$VULKAN_HEADERS_DIR/include" \
    -DSPIRV-Headers_DIR="$SPIRV_HEADERS_DIR" \
    -DCMAKE_INSTALL_PREFIX="$ABI_INSTALL_DIR"

  "$CMAKE_BIN" --build "$ABI_BUILD_DIR" --config Release --parallel "$BUILD_JOBS"
  "$CMAKE_BIN" --install "$ABI_BUILD_DIR" --config Release
  LLAMA_LIBRARY="$(find "$ABI_INSTALL_DIR" \( -type f -o -type l \) -name 'libllama.so' -print -quit)"
  GGML_LIBRARY="$(find "$ABI_INSTALL_DIR" \( -type f -o -type l \) -name 'libggml.so' -print -quit)"
  GGML_BASE_LIBRARY="$(find "$ABI_INSTALL_DIR" \( -type f -o -type l \) -name 'libggml-base.so' -print -quit)"
  VULKAN_LIBRARY="$(find "$ABI_INSTALL_DIR" \( -type f -o -type l \) -name 'libggml-vulkan.so' -print -quit)"
  CPU_BACKEND_LIBRARY="$(find "$ABI_INSTALL_DIR" \( -type f -o -type l \) -name 'libggml-cpu.so' -print -quit)"
  [[ -n "$LLAMA_LIBRARY" ]] || fail "[$abi] libllama.so not found."
  [[ -n "$GGML_LIBRARY" ]] || fail "[$abi] libggml.so not found."
  [[ -n "$GGML_BASE_LIBRARY" ]] || fail "[$abi] libggml-base.so not found."
  [[ -n "$VULKAN_LIBRARY" ]] || fail "[$abi] libggml-vulkan.so missing; refusing to claim a Vulkan build."
  [[ -n "$CPU_BACKEND_LIBRARY" ]] || fail "[$abi] libggml-cpu.so missing; refusing to claim CPU fallback."
  [[ -f "$ABI_INSTALL_DIR/include/llama.h" ]] || fail "[$abi] llama.h header missing."
  [[ -f "$ABI_INSTALL_DIR/include/ggml-backend.h" ]] || fail "[$abi] ggml-backend.h header missing."

  mkdir -p "$JNI_LIB_DIR"
  cp -Lf "$LLAMA_LIBRARY" "$JNI_LIB_DIR/libllama.so"
  cp -Lf "$GGML_LIBRARY" "$JNI_LIB_DIR/libggml.so"
  cp -Lf "$GGML_BASE_LIBRARY" "$JNI_LIB_DIR/libggml-base.so"
  find "$JNI_LIB_DIR" -maxdepth 1 -type f -name 'libggml-*.so' ! -name 'libggml-base.so' -delete
  find "$ABI_INSTALL_DIR" \( -type f -o -type l \) -name 'libggml-*.so' \
    ! -name 'libggml.so' ! -name 'libggml-base.so' -print -exec cp -Lf {} "$JNI_LIB_DIR/" \; \
    | sed "s#^#[$abi] Staged dynamic backend: #"
  test -f "$JNI_LIB_DIR/libllama.so"
  test -f "$JNI_LIB_DIR/libggml.so"
  test -f "$JNI_LIB_DIR/libggml-base.so"
  test -f "$JNI_LIB_DIR/libggml-cpu.so"
  test -f "$JNI_LIB_DIR/libggml-vulkan.so"
  printf '[%s] LLM, GGML core, CPU and Vulkan backend staging succeeded.\n' "$abi"
done

printf 'Native compilation and backend staging succeeded for %s. This proves build artifacts only; it does not prove Vulkan execution or measurable speedup on a device.\n' "$ANDROID_ABIS"
