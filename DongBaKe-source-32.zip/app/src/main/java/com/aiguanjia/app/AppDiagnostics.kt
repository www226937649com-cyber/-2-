package com.aiguanjia.app

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.os.Process
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/** 本地诊断日志；不会记录聊天正文。 */
object AppDiagnostics {
    private const val LOG = "dongbake-runtime.log"
    private const val OLD_LOG = "dongbake-runtime.1.log"
    private const val MARKER = "dongbake-active-operation.txt"
    private const val MAX_BYTES = 512L * 1024L
    private const val EXIT_PREFS = "dongbake-diagnostic-state"
    private const val EXIT_TS_KEY = "last_recorded_exit_timestamp"
    private val lock = Any()
    @Volatile private var handlerInstalled = false

    fun initialize(context: Context) {
        val app = context.applicationContext
        synchronized(lock) {
            recordRecentProcessExitsLocked(app)
            val marker = File(app.filesDir, MARKER)
            if (marker.isFile) {
                val unfinished = runCatching { marker.readText(Charsets.UTF_8) }.getOrDefault("unknown")
                writeLocked(app, "FATAL", "previous_run", "上次进程疑似异常退出；最后未完成操作：" + oneLine(unfinished))
                runCatching { marker.delete() }
            }
            val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "API<31 (SoC API unavailable)"
            writeLocked(app, "INFO", "startup",
                "启动 Android=${Build.VERSION.RELEASE}/API${Build.VERSION.SDK_INT}; device=${Build.MANUFACTURER} ${Build.MODEL}; " +
                "deviceCode=${Build.DEVICE}; hardware=${Build.HARDWARE}; board=${Build.BOARD}; soc=$soc; " +
                "ABI=${Build.SUPPORTED_ABIS.joinToString(",")}; version=${version(app)}; ${memorySnapshot(app)}; ${processMemorySnapshot()}")
            if (!handlerInstalled) {
                val previous = Thread.getDefaultUncaughtExceptionHandler()
                Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                    runCatching { logThrowable(app, "FATAL", "uncaught_exception", "thread=${thread.name}", error) }
                    if (previous != null) previous.uncaughtException(thread, error)
                    else { Process.killProcess(Process.myPid()); exitProcess(10) }
                }
                handlerInstalled = true
            }
        }
    }

    fun log(context: Context, level: String, event: String, details: String = "") {
        runCatching { synchronized(lock) { writeLocked(context.applicationContext, level, event, details) } }
    }

    fun logThrowable(context: Context, level: String, event: String, details: String, error: Throwable) {
        val out = StringWriter()
        runCatching { error.printStackTrace(PrintWriter(out)) }
        log(context, level, event, details + "\n" + out.toString())
    }

    fun beginOperation(context: Context, operation: String, details: String) {
        val app = context.applicationContext
        synchronized(lock) {
            runCatching {
                FileOutputStream(File(app.filesDir, MARKER), false).use {
                    it.write((operation + "|" + now() + "|" + oneLine(details)).toByteArray(Charsets.UTF_8))
                    it.fd.sync()
                }
            }
            writeLocked(app, "INFO", operation + "_begin", details)
        }
    }

    fun finishOperation(context: Context, operation: String, outcome: String, details: String = "") {
        val app = context.applicationContext
        synchronized(lock) {
            writeLocked(app, if (outcome == "success") "INFO" else "WARN", operation + "_" + outcome, details)
            runCatching {
                val marker = File(app.filesDir, MARKER)
                if (marker.isFile && marker.readText(Charsets.UTF_8).substringBefore("|") == operation) marker.delete()
            }
        }
    }

    fun memorySnapshot(context: Context): String = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        "available=${info.availMem}; total=${info.totalMem}; lowMemory=${info.lowMemory}; " +
            "vmMax=${Runtime.getRuntime().maxMemory()}; nativeHeap=${android.os.Debug.getNativeHeapAllocatedSize()}"
    }.getOrDefault("memorySnapshot=unavailable")

    fun memoryTotalBytes(context: Context): Long = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        info.totalMem
    }.getOrDefault(0L)

    fun deviceSnapshot(context: Context): String = runCatching {
        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "unknown (API<31)"
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        "manufacturer=${Build.MANUFACTURER}; model=${Build.MODEL}; device=${Build.DEVICE}; hardware=${Build.HARDWARE}; board=${Build.BOARD}; soc=$soc; abi=${Build.SUPPORTED_ABIS.joinToString(",")}; totalMem=${info.totalMem}; availableMem=${info.availMem}"
    }.getOrDefault("deviceSnapshot=unavailable")

    fun processSnapshot(): String = processMemorySnapshot()

    private fun processMemorySnapshot(): String = runCatching {
        val status = File("/proc/self/status").takeIf { it.canRead() }?.readText().orEmpty()
        val keys = listOf("VmRSS", "VmHWM", "VmSize", "VmPeak", "VmSwap")
        val values = status.lineSequence().filter { line -> keys.any { line.startsWith("$it:") } }.joinToString(";")
        val cgCurrent = File("/sys/fs/cgroup/memory.current").takeIf { it.canRead() }?.readText()?.trim()
        val cgMax = File("/sys/fs/cgroup/memory.max").takeIf { it.canRead() }?.readText()?.trim()
        "procStatus=[$values]; cgroupMemoryCurrent=${cgCurrent ?: "n/a"}; cgroupMemoryMax=${cgMax ?: "n/a"}"
    }.getOrDefault("processMemorySnapshot=unavailable")

    private fun recordRecentProcessExitsLocked(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        runCatching {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val prefs = context.getSharedPreferences(EXIT_PREFS, Context.MODE_PRIVATE)
            val lastTimestamp = prefs.getLong(EXIT_TS_KEY, 0L)
            val exits = manager.getHistoricalProcessExitReasons(context.packageName, 0, 8)
                .filter { it.processName == context.packageName || it.processName.startsWith(context.packageName + ":") }
                .sortedBy { it.timestamp }
            for (exit in exits) {
                if (exit.timestamp <= lastTimestamp) continue
                val reason = when (exit.reason) {
                    ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
                    ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY"
                    ApplicationExitInfo.REASON_CRASH -> "JAVA_CRASH"
                    ApplicationExitInfo.REASON_SIGNALED -> "OS_SIGNAL"
                    ApplicationExitInfo.REASON_ANR -> "ANR"
                    ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE_USAGE"
                    ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
                    ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
                    ApplicationExitInfo.REASON_USER_STOPPED -> "USER_STOPPED"
                    else -> "OTHER_${exit.reason}"
                }
                writeLocked(context, "FATAL", "previous_process_exit",
                    "timestamp=${exit.timestamp}; reason=$reason; status=${exit.status}; importance=${exit.importance}; " +
                    "process=${exit.processName}; pssKB=${exit.pss}; rssKB=${exit.rss}; description=${exit.description.orEmpty().take(2000)}")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val traceText = runCatching {
                        val stream = exit.traceInputStream ?: return@runCatching ""
                        val out = java.io.ByteArrayOutputStream()
                        stream.use { input ->
                            val buffer = ByteArray(4096)
                            var remaining = 65536
                            while (remaining > 0) {
                                val read = input.read(buffer, 0, minOf(buffer.size, remaining))
                                if (read <= 0) break
                                out.write(buffer, 0, read)
                                remaining -= read
                            }
                        }
                        val raw = out.toByteArray().toString(Charsets.ISO_8859_1)
                        Regex("[ -~]{8,}").findAll(raw).map { it.value.trim() }
                            .filter { it.contains("/", true) || it.contains("signal", true) || it.contains("fault", true) || it.contains("crash", true) || it.contains("DongBaKe", true) || it.contains("llama", true) }
                            .distinct().take(45).joinToString(" | ").take(6000)
                    }.getOrDefault("")
                    if (traceText.isNotBlank()) writeLocked(context, "FATAL", "previous_exit_trace_preview", traceText)
                }
            }
            val newest = exits.maxOfOrNull { it.timestamp } ?: lastTimestamp
            if (newest > lastTimestamp) prefs.edit().putLong(EXIT_TS_KEY, newest).apply()
        }.onFailure { writeLocked(context, "WARN", "process_exit_history_unavailable", it.javaClass.simpleName + ": " + it.message.orEmpty()) }
    }

    fun readAll(context: Context): String = synchronized(lock) {
        val dir = context.applicationContext.filesDir
        val chunks = listOf(OLD_LOG, LOG).mapNotNull { name ->
            val file = File(dir, name)
            if (file.isFile) runCatching { file.readText(Charsets.UTF_8) }.getOrNull() else null
        }
        if (chunks.isEmpty()) "暂无运行日志。\n" else chunks.joinToString("\n")
    }

    fun clear(context: Context) {
        synchronized(lock) {
            runCatching { File(context.filesDir, LOG).delete() }
            runCatching { File(context.filesDir, OLD_LOG).delete() }
            writeLocked(context.applicationContext, "INFO", "logs_cleared", "用户清空了日志。")
        }
    }

    private fun version(context: Context) = runCatching {
        val p = context.packageManager.getPackageInfo(context.packageName, 0)
        "${p.versionName.orEmpty()} (${p.longVersionCode})"
    }.getOrDefault("unknown")

    private fun writeLocked(context: Context, level: String, event: String, details: String) {
        runCatching {
            val file = File(context.filesDir, LOG)
            if (file.exists() && file.length() >= MAX_BYTES) {
                val old = File(context.filesDir, OLD_LOG)
                runCatching { old.delete() }
                runCatching { file.renameTo(old) }
            }
            val line = "${now()} [${level}] [${event}] ${details.trimEnd()}\n"
            FileOutputStream(file, true).use {
                it.write(line.toByteArray(Charsets.UTF_8))
                it.fd.sync()
            }
        }
    }

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
    private fun oneLine(value: String) = value.replace('\r', ' ').replace('\n', ' ').take(4000)
}
