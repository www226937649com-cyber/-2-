package com.aiguanjia.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.UUID

/** Local-only, bounded learning journal. Unverified lessons never enter the model context. */
internal data class LearningRecord(
    val id: String,
    val createdAt: Long,
    val kind: String,
    val question: String,
    val correction: String,
    val verified: Boolean
)

internal object LearningMemoryStore {
    private const val KEY = "learning_journal_v1"
    private const val MAX_RECORDS = 100

    fun load(preferences: SharedPreferences): List<LearningRecord> = try {
        val array = JSONArray(preferences.getString(KEY, "[]").orEmpty())
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            LearningRecord(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                createdAt = o.optLong("createdAt", 0L),
                kind = o.optString("kind", "复盘"),
                question = o.optString("question").take(500),
                correction = o.optString("correction").take(700),
                verified = o.optBoolean("verified", false)
            )
        }.takeLast(MAX_RECORDS)
    } catch (_: Exception) { emptyList() }

    fun addPending(preferences: SharedPreferences, kind: String, question: String, correction: String): Boolean {
        if (question.isBlank() && correction.isBlank()) return false
        val current = load(preferences).toMutableList()
        val normalized = correction.trim().lowercase(Locale.ROOT)
        if (current.any { it.correction.trim().lowercase(Locale.ROOT) == normalized && it.question == question }) return false
        current.add(LearningRecord(UUID.randomUUID().toString(), System.currentTimeMillis(), kind,
            question.trim().take(500), correction.trim().take(700), false))
        save(preferences, current)
        return true
    }

    fun setVerified(preferences: SharedPreferences, id: String, verified: Boolean) {
        save(preferences, load(preferences).map { if (it.id == id) it.copy(verified = verified) else it })
    }

    fun delete(preferences: SharedPreferences, id: String) = save(preferences, load(preferences).filterNot { it.id == id })
    fun clear(preferences: SharedPreferences) = preferences.edit().remove(KEY).apply()

    fun validatedLessons(preferences: SharedPreferences, limit: Int = 5): List<String> =
        load(preferences).filter { it.verified }.takeLast(limit).map { record ->
            "已验证经验：问题=${record.question.take(150)}；纠正/经验=${record.correction.take(220)}"
        }

    fun storageBytes(preferences: SharedPreferences): Long {
        val memoryKeys = listOf(
            KEY, "personalization_memories", "personalization_height", "personalization_weight",
            "personalization_interests", "personalization_daily_preferences", "personalization_chat_preferences",
            "personalization_user_requests"
        )
        return memoryKeys.sumOf { key ->
            (preferences.getString(key, "") ?: "").toByteArray(StandardCharsets.UTF_8).size.toLong()
        }
    }

    private fun save(preferences: SharedPreferences, records: List<LearningRecord>) {
        val array = JSONArray()
        records.takeLast(MAX_RECORDS).forEach { r ->
            array.put(JSONObject().put("id", r.id).put("createdAt", r.createdAt).put("kind", r.kind)
                .put("question", r.question.take(500)).put("correction", r.correction.take(700)).put("verified", r.verified))
        }
        preferences.edit().putString(KEY, array.toString()).apply()
    }
}
