package com.aiguanjia.app

import java.util.Locale

/**
 * Pure Kotlin normalization and extraction of explicitly written arithmetic expressions.
 * It deliberately rejects leftover prose instead of matching a numeric prefix.
 */
internal object LocalizedMathExpression {
    private val removablePhrases = listOf(
        "只回答数字", "请帮我计算", "帮我计算", "请帮我算一下", "请帮我算", "帮我算一下", "帮我算", "请算一下", "请计算", "计算一下", "计算", "算一算", "算一下", "算算", "求值",
        "结果是多少", "等于多少", "等于几", "是多少", "的结果", "请问", "帮我", "等于", "多少", "一下", "结果"
    )
    private val fallbackFillers = listOf(
        "只回答数字", "请帮我计算", "帮我计算", "请帮我算一下", "请帮我算", "帮我算一下", "帮我算", "请计算", "计算一下", "计算", "算一下", "算算", "等于多少", "等于几", "是多少", "结果是多少", "结果", "求值", "请问", "麻烦", "帮我", "请", "等于", "多少", "一下"
    )
    private val allowedWords = setOf("pi", "e", "sqrt", "sin", "cos", "tan", "log", "log10", "exp", "abs", "ceil", "floor", "factorial", "radians", "degrees")

    fun normalizeLocalizedMath(raw: String): String {
        var q = raw.lowercase(Locale.ROOT)
        // Convert Chinese scale words before validating the full expression.
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*万"""), "($1*10000)")
        // Common spoken forms: “5的根号3” / “5根号3” mean 5 × √3.
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*的\s*根号\s*(\d+(?:\.\d+)?)"""), "$1*sqrt($2)")
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*根号\s*(\d+(?:\.\d+)?)"""), "$1*sqrt($2)")
        q = q.replace(Regex("""(?:√|根号)\s*(\d+(?:\.\d+)?)"""), "sqrt($1)")
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*的平方"""), "($1**2)")
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*的立方"""), "($1**3)")
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*平方"""), "($1**2)")
        q = q.replace(Regex("""(\d+(?:\.\d+)?)\s*立方"""), "($1**3)")
        return q
    }

    fun direct(question: String): String {
        var q = question.lowercase(Locale.ROOT)
        removablePhrases.forEach { q = q.replace(it, " ") }
        q = normalizeLocalizedMath(q)
            .replace("相乘", "*").replace("乘以", "*").replace("乘", "*").replace("×", "*").replace("✕", "*")
            .replace("除以", "/").replace("除于", "/").replace("÷", "/")
            .replace("加上", "+").replace("加", "+").replace("减去", "-").replace("减", "-")
            .replace("^", "**").replace("＝", " ").replace("=", " ")
            .replace("？", " ").replace("?", " ").replace("。", " ").replace("，", " ").replace(",", " ")
            .replace(Regex("[：:;；]"), " ").trim()
        // Remove only function names/constants that the evaluator explicitly accepts.
        val wordsRemoved = q.replace(Regex("(?i)\\b(sqrt|sin|cos|tan|log10|log|exp|abs|ceil|floor|factorial|radians|degrees|pi|e)\\b"), " ")
        val residue = wordsRemoved.replace(Regex("[0-9\\s()+*/%.\\-]"), "")
        if (residue.isNotBlank()) return ""
        if (!Regex("[+*/%\\-]|\\*\\*|\\b(sqrt|sin|cos|tan|log|abs|factorial)\\b", RegexOption.IGNORE_CASE).containsMatchIn(q)) return ""
        return sanitize(q)
    }

    fun fallback(question: String): String {
        var q = normalizeLocalizedMath(question)
        fallbackFillers.forEach { q = q.replace(it, " ") }
        q = q.replace("相乘", "*").replace("乘以", "*").replace("乘", "*").replace("×", "*").replace("✕", "*")
            .replace("除以", "/").replace("除于", "/").replace("÷", "/")
            .replace("加上", "+").replace("加", "+").replace("减去", "-").replace("减", "-")
            .replace("^", "**").replace("＝", " ").replace("=", " ")
            .replace(Regex("[？?。，,：:；;]"), " ").trim()
        if (q.isBlank()) return ""
        return sanitize(q)
    }

    fun sanitize(raw: String): String {
        val value = raw.replace("×", "*").replace("✕", "*").replace("÷", "/").replace("^", "**").replace("π", "pi")
            .replace(Regex("(?i)^expr\\s*[:=]\\s*"), "").trim()
        if (value.length > 180 || value.isBlank()) return ""
        if (!Regex("^[0-9eEpiPIa-zA-Z_+*/().,%\\-\\s]+$").matches(value)) return ""
        val words = Regex("[a-zA-Z_]+", RegexOption.IGNORE_CASE).findAll(value).map { it.value.lowercase(Locale.ROOT) }.toList()
        if (words.any { it !in allowedWords }) return ""
        return value.replace(Regex("\\s+"), " ").trim()
    }
}
