package com.aiguanjia.app

import java.net.URI
import java.util.Locale

/** Chooses official-domain hints and trust-aware ranking features for general web search. */
internal object SearchSourcePolicy {
    fun queryFor(question: String): String {
        val q = question.trim()
        val hints = when {
            listOf("疾病", "症状", "药", "健康", "疫苗", "医学", "医疗").any { q.contains(it) } -> "site:who.int OR site:nhc.gov.cn OR site:cdc.gov"
            listOf("宇宙", "航天", "NASA", "行星", "天文", "太空", "暗物质", "黑洞", "量子", "物理", "科学研究").any { q.contains(it, true) } -> "site:nasa.gov OR site:esa.int OR site:nature.com OR site:science.org"
            listOf("经济", "GDP", "贫困", "发展", "世界银行").any { q.contains(it, true) } -> "site:worldbank.org OR site:imf.org OR site:oecd.org"
            listOf("法律", "法规", "政策", "条例", "政府").any { q.contains(it) } -> "site:gov.cn OR site:npc.gov.cn OR site:europa.eu"
            listOf("论文", "研究成果", "学术", "引用文献").any { q.contains(it) } -> "site:pubmed.ncbi.nlm.nih.gov OR site:crossref.org OR site:nature.com"
            listOf("安卓", "Android", "软件开发", "API", "GitHub", "编程", "代码", "GGUF", "模型部署").any { q.contains(it, true) } -> "site:developer.android.com OR site:docs.github.com OR site:github.com OR site:huggingface.co"
            listOf("历史", "历史事件", "档案", "古代史").any { q.contains(it) } -> "site:britannica.com OR site:loc.gov OR site:archives.gov OR site:un.org"
            else -> ""
        }
        return if (hints.isBlank()) q else "$q ($hints)"
    }

    fun authorityScore(url: String): Int {
        val host = try { URI(url).host.orEmpty().lowercase(Locale.ROOT).removePrefix("www.") } catch (_: Exception) { "" }
        if (host.isBlank()) return 0
        val trusted = listOf(
            "who.int", "cdc.gov", "nhc.gov.cn", "nasa.gov", "esa.int", "worldbank.org", "imf.org",
            "gov.cn", "npc.gov.cn", "pubmed.ncbi.nlm.nih.gov", "crossref.org", "un.org", "oecd.org",
            "stats.gov.cn", "data.gov", "europa.eu", "nih.gov", "nature.com", "science.org"
        )
        return if (trusted.any { host == it || host.endsWith(".$it") }) 5 else 0
    }
}
