package com.aiguanjia.app

/**
 * 统一工具调度入口。让确定性工具先处理确定性任务，避免每条输入都启动本地大模型。
 * 这里负责选择处理通道；网络请求、文件操作和模型推理仍由 MainActivity 的工具执行器完成。
 */
internal enum class TaskKind {
    DIRECT_SOCIAL, QUICK_CHAT, CALCULATION, WEATHER, LOCATION, WEB_SEARCH, LOCAL_MODEL
}

internal data class TaskRoute(
    val kind: TaskKind,
    val requiresModel: Boolean,
    val timeoutMillis: Long,
    val statusLabel: String
)

internal object ToolDecisionEngine {
    fun route(
        hasInstantSocialReply: Boolean,
        isQuickChat: Boolean,
        isMathQuestion: Boolean,
        hasSafeMathExpression: Boolean,
        isWeatherQuestion: Boolean,
        isLocationQuestion: Boolean,
        webSearchEnabled: Boolean,
        shouldSearch: Boolean
    ): TaskRoute = when {
        isMathQuestion -> TaskRoute(
            kind = TaskKind.CALCULATION,
            requiresModel = !hasSafeMathExpression,
            timeoutMillis = 5_000L,
            statusLabel = "优先使用本地计算器；必要时转交 Python"
        )
        isWeatherQuestion -> TaskRoute(
            kind = TaskKind.WEATHER,
            requiresModel = false,
            timeoutMillis = 12_000L,
            statusLabel = "查询天气数据后直接整理结果"
        )
        isLocationQuestion -> TaskRoute(
            kind = TaskKind.LOCATION,
            requiresModel = false,
            timeoutMillis = 10_000L,
            statusLabel = "按需读取位置，不进行后台跟踪"
        )
        hasInstantSocialReply -> TaskRoute(
            kind = TaskKind.DIRECT_SOCIAL,
            requiresModel = false,
            timeoutMillis = 1_000L,
            statusLabel = "闲聊快速回应，不调用模型"
        )
        isQuickChat -> TaskRoute(
            kind = TaskKind.QUICK_CHAT,
            requiresModel = true,
            timeoutMillis = 15_000L,
            statusLabel = "轻量闲聊：缩短上下文与回答长度，不联网搜索"
        )
        webSearchEnabled && shouldSearch -> TaskRoute(
            kind = TaskKind.WEB_SEARCH,
            requiresModel = false,
            timeoutMillis = 10_000L,
            statusLabel = "联网检索并先判断能否直接回答"
        )
        else -> TaskRoute(
            kind = TaskKind.LOCAL_MODEL,
            requiresModel = true,
            timeoutMillis = 0L,
            statusLabel = "本地模型处理一般或复杂问题（当前原生接口无法保证硬中断）"
        )
    }
}
