"""Small, offline, safe arithmetic engine for AI GuanJia.
Only numeric constants, approved operators and selected math functions are allowed.
"""
import ast
import math
import operator

_BINARY = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}
_FUNCTIONS = {
    "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "log": math.log, "log10": math.log10, "exp": math.exp, "abs": abs,
    "ceil": math.ceil, "floor": math.floor, "factorial": math.factorial,
    "radians": math.radians, "degrees": math.degrees,
}
_CONSTANTS = {"pi": math.pi, "e": math.e}

class _SafeEvaluator(ast.NodeVisitor):
    def visit_Expression(self, node):
        return self.visit(node.body)

    def visit_Constant(self, node):
        if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
            raise ValueError("只支持数字常量")
        if isinstance(node.value, int) and abs(node.value) > 10**100:
            raise ValueError("整数过大")
        return node.value

    def visit_Name(self, node):
        name = node.id.lower()
        if name in _CONSTANTS:
            return _CONSTANTS[name]
        raise ValueError("不支持的数学常量")

    def visit_BinOp(self, node):
        fn = _BINARY.get(type(node.op))
        if fn is None:
            raise ValueError("不支持该运算符")
        left, right = self.visit(node.left), self.visit(node.right)
        if isinstance(node.op, ast.Pow) and abs(float(right)) > 1000:
            raise ValueError("指数过大，已阻止计算")
        result = fn(left, right)
        return self._check(result)

    def visit_UnaryOp(self, node):
        fn = _UNARY.get(type(node.op))
        if fn is None:
            raise ValueError("不支持该运算")
        return self._check(fn(self.visit(node.operand)))

    def visit_Call(self, node):
        if not isinstance(node.func, ast.Name) or node.func.id.lower() not in _FUNCTIONS:
            raise ValueError("不支持该函数")
        if node.keywords or len(node.args) > 2:
            raise ValueError("函数参数不受支持")
        args = [self.visit(arg) for arg in node.args]
        if node.func.id.lower() == "factorial" and (len(args) != 1 or int(args[0]) != args[0] or args[0] < 0 or args[0] > 1000):
            raise ValueError("阶乘参数需要是 0 到 1000 的整数")
        return self._check(_FUNCTIONS[node.func.id.lower()](*args))

    def generic_visit(self, node):
        raise ValueError("表达式包含不允许的语法")

    @staticmethod
    def _check(value):
        if isinstance(value, complex):
            raise ValueError("结果为复数，当前不支持")
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("结果不是有限数值")
        if isinstance(value, int) and abs(value) > 10**200:
            raise ValueError("计算结果过大")
        return value

def evaluate(expression):
    """Evaluate a restricted math expression and return a stable display string."""
    try:
        if not isinstance(expression, str) or not expression.strip() or len(expression) > 180:
            raise ValueError("表达式为空或过长")
        tree = ast.parse(expression, mode="eval")
        result = _SafeEvaluator().visit(tree)
        if isinstance(result, float):
            if not math.isfinite(result):
                raise ValueError("结果不是有限数值")
            if result.is_integer() and abs(result) < 10**16:
                return str(int(result))
            return format(result, ".12g")
        return str(result)
    except ZeroDivisionError:
        return "ERROR: 除数不能为 0"
    except OverflowError:
        return "ERROR: 计算结果超出范围"
    except Exception as exc:
        return "ERROR: " + str(exc)
