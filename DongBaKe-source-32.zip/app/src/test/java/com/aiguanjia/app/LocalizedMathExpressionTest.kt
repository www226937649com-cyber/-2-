package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalizedMathExpressionTest {
    @Test fun chineseScaleMultiplicationKeepsFullExpression() {
        assertEquals("(75*10000)*102", LocalizedMathExpression.direct("75万×102 等于多少"))
    }

    @Test fun spokenSquareRootKeepsMultiplication() {
        assertEquals("5*sqrt(3)", LocalizedMathExpression.direct("5的根号3等于多少"))
    }

    @Test fun fallbackPathKeepsScaleMultiplier() {
        assertEquals("(75*10000)*102", LocalizedMathExpression.fallback("75万乘以102"))
    }

    @Test fun refusesPartialNumberFromProse() {
        assertTrue(LocalizedMathExpression.direct("这句话里面有75但是不是算式").isBlank())
    }

    @Test fun refusesCodeExecutionSyntax() {
        assertTrue(LocalizedMathExpression.sanitize("__import__('os').system('id')").isBlank())
    }
}
