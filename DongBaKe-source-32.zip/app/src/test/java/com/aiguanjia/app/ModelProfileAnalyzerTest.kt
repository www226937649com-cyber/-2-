package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ModelProfileAnalyzerTest {
    @Test fun parsesMinimalGgufHeaderMetadataAndTensorDirectory() {
        val file = writeMinimalGguf()
        try {
            val profile = ModelProfileAnalyzer.analyze(file)
            assertEquals(3L, profile.ggufVersion)
            assertEquals("llama", profile.architecture)
            assertEquals("Q4_K_M", profile.quantizationHint)
            assertEquals(1L, profile.tensorCount)
            assertEquals("Q4_0×1", profile.tensorQuantizationSummary)
            assertTrue(profile.hasChatTemplate)
            assertEquals("llama", profile.tokenizerModel)
        } finally { file.delete() }
    }

    @Test fun rejectsWrongMagic() {
        val file = File.createTempFile("not-gguf", ".bin")
        try {
            file.writeBytes("NOTG".toByteArray() + ByteArray(40))
            val error = runCatching { ModelProfileAnalyzer.analyze(file) }.exceptionOrNull()
            assertNotNull(error)
            assertTrue(error!!.message.orEmpty().contains("魔数"))
        } finally { file.delete() }
    }

    @Test fun rejectsTruncatedHeader() {
        val file = File.createTempFile("trunc-gguf", ".bin")
        try {
            file.writeBytes("GGUF".toByteArray() + le32(3) + le64(1) + le64(20))
            assertNotNull(runCatching { ModelProfileAnalyzer.analyze(file) }.exceptionOrNull())
        } finally { file.delete() }
    }

    private fun writeMinimalGguf(): File {
        val out = ByteArrayOutputStream()
        out.write("GGUF".toByteArray())
        out.write(le32(3)); out.write(le64(1)); out.write(le64(5))
        writeString(out, "general.architecture"); out.write(le32(8)); writeString(out, "llama")
        writeString(out, "general.name"); out.write(le32(8)); writeString(out, "Minimal test model")
        writeString(out, "general.file_type"); out.write(le32(4)); out.write(le32(15))
        writeString(out, "tokenizer.ggml.model"); out.write(le32(8)); writeString(out, "llama")
        writeString(out, "tokenizer.chat_template"); out.write(le32(8)); writeString(out, "{{ messages }}")
        writeString(out, "token_embd.weight"); out.write(le32(1)); out.write(le64(32)); out.write(le32(2)); out.write(le64(0))
        return File.createTempFile("valid-gguf", ".gguf").apply { writeBytes(out.toByteArray()) }
    }

    private fun writeString(out: ByteArrayOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        out.write(le64(bytes.size.toLong()))
        out.write(bytes)
    }

    private fun le32(value: Int): ByteArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array()
    private fun le64(value: Long): ByteArray = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(value).array()
}
