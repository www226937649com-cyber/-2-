# Vulkan + CPU 混合推理接入阶段记录

## Source-21 当前阶段：建立可复现的原生引擎构建入口

- 上游：`ggml-org/llama.cpp`
- 固定提交：`091b6a7fc561b78da90a0ed2d524ec995458c657`
- 架构：Android `arm64-v8a`
- NDK：`27.2.12479018`（r27c）
- 后端构建选项：`GGML_CPU=ON` + `GGML_VULKAN=ON`，同时保留 GGML CPU 后端
- 当前应用版本：`versionCode=20` / `versionName=0.9.6`

构建入口：`tools/build_llama_cpp_android_vulkan.sh`。脚本会校验 NDK、CMake、宿主机 `glslc`、SPIRV-Headers，验证上游 Git 提交 SHA，然后构建并安装原生引擎库。固定上游提交可避免每次构建偷偷追随变化的 `main` 分支。

## 当前尚未完成的事情

1. 本阶段脚本只负责编译上游引擎，尚未把生成的 `.so` 放进 APK，也没有 JNI 推理桥接。
2. 仍需实现模型加载、聊天模板、逐 Token 回调、原生取消、GPU 层卸载设置以及安全释放模型的生命周期。
3. 需将 GPU 设备枚举、实际后端选择、卸载层数和生成指标写入运行日志；只有库编译成功不能标记 GPU 已参与推理。
4. 需要在可用 Android SDK/NDK 的环境执行真正的构建。当前工作容器缺少 SDK/NDK，并且无法直接解析 GitHub；本地没有执行成功的原生编译结果。
5. 按用户要求，不安排目标手机实测。没有设备侧证据时，不报告实际 GPU 速度或加速百分比。

## 环境准备（Ubuntu / CI）

安装 Android NDK r27c 与 CMake 3.22.1，并安装宿主机 Vulkan shader 编译工具和 SPIRV-Headers。然后运行：

```bash
export ANDROID_NDK="$ANDROID_HOME/ndk/27.2.12479018"
bash tools/build_llama_cpp_android_vulkan.sh
```

脚本输出“Compilation succeeded”只表示原生引擎编译阶段成功，不代表已完成应用集成或 GPU 运行验证。
