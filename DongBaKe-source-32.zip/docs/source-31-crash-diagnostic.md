# source-31 原生闪退诊断构建（v0.10.9 / versionCode 31）

## 本轮目的

本构建用于隔离验证历史的 `llama_init_from_model` → `sched_reserve` / `graph_reserve` SIGSEGV 是否与上下文初始化时的计算图预留压力有关。现有日志不足以证明根因，因此不把本轮标记为已修复。

## 唯一核心变量

- 保留用户选择的上下文长度（默认 2048），不自动改变模型、线程、KV Cache 类型或 GPU 层数。
- 将 `n_batch` 上限从 512 降至 128。
- 将 `n_ubatch` 上限降至 64。
- 常规推理和可选推测解码中的目标/草稿上下文使用同一低批次上限。
- 原生日志在 `context_init_begin` 记录 `profile=source31-low-batch-diagnostic`、`n_ctx`、`n_batch` 与 `n_ubatch`，便于确认测试是否使用了目标配置。

## 如何验证

1. 先保留原版和模型文件，不要清除应用数据。此版本 `applicationId` 保持不变、versionCode 升为 31。
2. 在“推理参数”中设 GPU / Vulkan 卸载层数为 0、推测解码关闭、KV Cache 选择 F16，保存后退出并重新加载模型。这样首轮只测试 CPU 路径，避免把 GPU 兼容性混入实验。
3. 先发送短提示词（例如“只回答数字 2”），记录是否能完成首轮生成。然后查看应用内原生日志，确认 `n_batch=128`、`n_ubatch=64`。
4. 若仍闪退，请从系统“应用退出历史”或 `adb logcat` 保存 SIGSEGV tombstone、故障线程和寄存器信息；若通过，则再单独测试上下文长度与 GPU 层数，不要一次同时改变多项参数。

## 解释边界

- 如果低批次构建能够运行，只能说明该配置绕开了问题，不能单凭这一结果证明具体 C++ 根因。
- 如果仍然在 `graph_reserve` 闪退，需要完整 tombstone 及崩溃前原生日志，再决定是否更换 llama.cpp 版本或调整特定算子/后端。
- 本构建只做 CPU 路径优先诊断；不宣布 Vulkan、混合推理、Flash Attention、推测解码或 NPU/APU 已兼容。
