# source-32 运行诊断与 CPU-only 隔离构建（v0.11.0-diagnostics / versionCode 32）

## 应用内诊断入口

“更多功能 → 推理诊断实验室”提供固定短提示词的原生推理自测与完整诊断报告导出。报告汇总应用/系统版本、设备与内存快照、当前参数、选中/加载模型的元数据、原生引擎后端状态、最近推理指标、最近原生日志与应用运行日志。报告不主动导出聊天历史或聊天正文。

原生推理如果直接导致进程 SIGSEGV，Kotlin 的异常处理通常无法捕获；自测会先持久化未完成操作标记，应用下次启动时将记录中断测试。

## 后端配置

构建脚本支持 `BACKEND_PROFILE=cpu-only` 或 `BACKEND_PROFILE=vulkan`。CPU-only 构建用 `GGML_VULKAN=OFF` 构建上游引擎、不打包 `libggml-vulkan.so`，并让 JNI 编译时排除 Vulkan API 头文件/链接项。这比 `gpuLayers=0` 更严格，因为它不注册 Vulkan 动态后端。

Gradle 通过 `-PdongbakeNativeBackend=cpu` 选择 CPU-only 配置，或 `-PdongbakeNativeBackend=vulkan` 选择原有 CPU + Vulkan 配置。应用内引擎报告会标出实际编译模式；后端枚举不被解释成模型正在 GPU 运算的证明。

## 首轮验证建议

1. 先使用 CPU-only 构建，不卸载/清除现有应用数据；如果签名冲突，不要为了安装而贸然卸载。
2. 手动加载同一 GGUF，保持上下文 2048、F16 KV cache、GPU 层数 0、关闭推测解码，运行“最小推理自测”。
3. 导出完整报告，检查 `context_init_begin` 的 `n_ctx/n_batch/n_ubatch`、`context_init_complete`、首个 Token 和结束状态。
4. 只有在 CPU-only 稳定后，再用独立 Vulkan profile 做对照。一个 profile 通过构建不代表真机已验证。
