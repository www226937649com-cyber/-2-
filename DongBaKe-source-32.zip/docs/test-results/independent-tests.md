# Source-20 独立测试执行记录

执行日期：2026-10-14（本次会话容器时间）

## 已实际运行并通过

1. `python3 -m unittest discover -s tests -v`：**14/14 通过**。
   - 计算器安全与回归：6 项。
   - 任务进度、耗时日志、温度功能缺席、版本与能力声明审计：8 项。
2. `bash tools/test_model_profile.sh`：通过最小 GGUF v3 元数据/张量描述符测试；拒绝非 GGUF 和截断文件。
3. `bash tools/test_math_parser.sh`：通过中文大数算式、口述平方根、回退提取及拒绝自然语言/危险代码用例。
4. `bash tools/test_source_audit.sh`：**8/8 源码审计通过**。
5. 单独对 `MainActivity.kt` 检查温控相关符号：确认运行源码中不再有温度监控、热状态读取、热保护 UI 或阻止模型加载/推理的热保护逻辑。
6. `kotlinc MainActivity.kt -d ...` 结构扫描：**未通过编译**，因为当前 classpath 缺少 Android、AndroidX、Chaquopy、llama-android 等依赖；输出主要是 `unresolved reference`，未检出 `expecting` / `unexpected tokens` 一类语法诊断。该扫描不等于成功编译。

## 当前未能验证

- Android `:app:testDebugUnitTest`、`assembleDebug`、`assembleRelease` 没有执行。
- 环境缺少 `gradle`、Gradle Wrapper、Android SDK/NDK、`android.jar` 与 `adb`。
- 尝试检查上游源代码下载连接时，容器 Git 网络返回 DNS 无法解析 `github.com`。公开文档可通过联网检索读取，但无法在此容器完整克隆上游原生工程。
- 因而没有生成或验证 APK，也没有确认 `MainActivity.kt` 与全部 Android/AndroidX/Chaquopy/llama-android 依赖一起编译成功。
- 没有实现或验证 Vulkan/GPU 实际推理、Token 级原生流、native 硬取消；它们必须继续标为未实现。
- **按照用户明确要求，不执行 Redmi Note 11T Pro 实机测试。** 不报告设备端 TTFT、Prefill、Decode Tokens/s、GPU 利用率或内存峰值。
