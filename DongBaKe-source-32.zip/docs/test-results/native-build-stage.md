# Source-21 原生构建阶段当前验收

日期：2026-10-14。此处记录当前容器真实运行结果，不把 CI 预期写成已发生结果。

## 已运行并通过

- `bash -n tools/build_llama_cpp_android_vulkan.sh`：脚本语法通过。
- `python3 -m unittest discover -s tests -v`：20/20 通过，包括新增的原生构建脚本静态审计用例 6 项。
- `bash tools/test_model_profile.sh`：通过合成 GGUF v3 元数据/张量描述符用例，并拒绝非 GGUF、截断文件。
- `bash tools/test_math_parser.sh`：通过中文算式提取、安全回退、危险表达式拒绝用例。
- `bash tools/test_source_audit.sh`：8/8 通过。
- 在设置了无效 NDK 路径的情况下运行新构建脚本：返回退出码 2，并输出 `Android NDK not found`。这是正确的前置条件失败行为，不是构建成功。
- `app/build.gradle.kts`：版本号为 `versionCode=20`、`versionName=0.9.6`，包名与 `arm64-v8a` ABI 保持不变。

## 当前未验证 / 未完成

- 真实 `llama.cpp` CMake Android Vulkan 编译尚未运行。当前容器没有 Android SDK/NDK，并且 Git 无法解析 `github.com`。
- 上游源码 commit 固定为 `091b6a7fc561b78da90a0ed2d524ec995458c657`；CI 原生构建 job 已配置，但不能在本地声称该 job 已运行或通过。
- 尚未将 native `.so` 打包入 APK，没有 JNI 桥接，没有 GPU 设备枚举/卸载层诊断，也没有 Token 流式和 native 取消。
- Android Gradle 单元测试与 Debug/Release APK 构建未执行。
- 按用户要求，不安排 Redmi Note 11T Pro 实机测试；没有设备端 TTFT、tokens/s、GPU 利用率、内存或性能提升数据。
