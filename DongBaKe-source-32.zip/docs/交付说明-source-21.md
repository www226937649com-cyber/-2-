# 东巴壳 AI 管家 source-21 分析与验收报告

日期：2026-10-14  
基线：source-20  
版本：`versionCode=20`，`versionName=0.9.6`，`applicationId=com.aiguanjia.app`，ABI `arm64-v8a`

## 本次真正完成的内容

1. 新增 `tools/build_llama_cpp_android_vulkan.sh`：固定上游 `ggml-org/llama.cpp` 提交 `091b6a7fc561b78da90a0ed2d524ec995458c657`，检查 Android NDK、CMake、Ninja、`glslc`、SPIRV-Headers，配置 `GGML_CPU=ON` 与 `GGML_VULKAN=ON`，构建结束后同时要求找到 `libllama.so` 与 `libggml-vulkan.so`。该脚本尚未在此环境完成真正的上游编译。
2. 更新 `.github/workflows/android-build.yml`：保留应用测试和 APK 构建任务，另增 `native-vulkan-engine` 任务，在 CI 中编译固定版本的 ARM64 Android Vulkan 原生引擎并归档诊断结果。这个工作流目前只是写入源码，不能标记为已执行或通过。
3. 新增 `tests/test_native_build_setup.py`，共 6 个静态/失败路径测试；应用版本递增至 `20 / 0.9.6`，应用 ID 与目标 ABI 不变。
4. 新增/更新阶段文档和验收日志。保留原有 CPU 推理可用路径；没有加入温度管理、热保护或自动改动用户推理参数的逻辑。

## 当前验证结果

- Python unittest：**20/20 通过**。
- `bash -n tools/build_llama_cpp_android_vulkan.sh`：通过。
- `bash tools/test_model_profile.sh`：通过，包含拒绝无效和截断 GGUF 的用例。
- `bash tools/test_math_parser.sh`：通过。
- `bash tools/test_source_audit.sh`：8/8 通过。
- 无效 NDK 路径检查：按预期以退出码 2 终止并提示 `Android NDK not found`。
- `.github/workflows/android-build.yml`：通过 PyYAML 语法解析；识别到 `build` 和 `native-vulkan-engine` 两个 job。

详细的实际命令输出在 `docs/test-results/source-21-validation.log`。

## 尚未完成，不能对外宣称已实现

- 新版 `llama.cpp` 原生引擎尚未实际编译：当前容器没有设置 `ANDROID_HOME` / `ANDROID_NDK`，也没有 `gradle` 命令；GitHub 域名在当前容器的 DNS 查询失败。
- 没有 Android Gradle 构建结果，没有 APK。
- 没有 JNI 桥接，没有把 `.so` 打包进 APK，没有真正接上聊天主流程。
- 没有实际 Vulkan 设备枚举、GPU 层卸载、GPU/CPU 混合推理运行证据。
- 没有 Token 逐步回调和底层原生取消。
- 没有报告速度提升、TTFT 或 tokens/s，因为没有相应运行数据。
- 按用户要求，未安排或执行 Redmi Note 11T Pro 实机测试。

## 下一步开发顺序

1. 在已安装 Android SDK/NDK、`glslc` 和 SPIRV-Headers 的 CI 环境真正跑通 `native-vulkan-engine` job；以真实错误日志调整构建脚本，直到成功产出依赖完整的原生库。
2. 依据该固定提交的真实头文件实现 JNI 引擎封装：模型载入和释放、聊天模板、Token 回调、可取消生成、串行化生命周期和安全清理。
3. 将原生库及依赖打包进 APK，并以明确状态记录 CPU / Vulkan 后端、实际卸载层数、生成耗时和取消状态。未验证的 GPU 功能不显示为已启用。
4. 保留 CPU 后备，但不悄悄覆盖用户已选的线程、上下文、生成 Token 数或 GPU 卸载设置。

**本交付是第 1 阶段的构建准备与自动化验收包，不是已完成 GPU 推理的 APK。**
