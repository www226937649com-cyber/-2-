# 东巴壳 AI 管家 source-24 交付说明

## 本版内容

- **应用版本：** `versionCode=22` / `versionName=0.10.0`；包名仍为 `com.aiguanjia.app`。
- **推理引擎：** 固定上游 `llama.cpp` 的 `v0.6.0` 发布标签。源码目标是 CPU + Vulkan 后端组合，而不是并行运行两套互不相关的框架。
- **状态页面：** 从原生 JNI 获取后端/设备报告；系统版本页面读取 Android RELEASE、SDK/API、系统安全补丁日期、设备型号、ABI、应用版本和 Vulkan 系统特性。
- **搜索体验：** 搜索只负责检索与展示；后续综合分析需用户明确确认，原问题、资料摘要和链接按当前会话保存。
- **聊天上下文：** 回顾近期用户问题，并给模型提供当前话题最近消息作为上下文。

## 构建与验证边界

当前容器没有 Gradle 命令，也未配置 `ANDROID_HOME`、`ANDROID_SDK_ROOT` 或 Android NDK。因此本次交付的是源码与云端 workflow，不包含已验证可安装的 APK。工作流会在 Android NDK 环境里构建 native backend、随后构建 APK 并保存日志，但**workflow 文件存在不代表它已经运行过**。

用户明确不需要手机实测，所以此交付不包含目标手机性能结果。没有运行日志前，不应把 Vulkan 插件编译/注册、系统 GPU 枚举、模型 GPU 层配置和实际 GPU 执行视为同一件事。

## 文件

- `DongBaKe-source-24.zip`：扁平工程源码包（ZIP 根目录直接包含 Gradle 根文件与 `app/`）。
- `build-apk-workflow-source-24.yml`：需复制到仓库 `.github/workflows/` 的 GitHub Actions workflow。
- `docs/源码差异清单-source-24.md`：本版改动与限制。
- `docs/构建验证记录-source-24.md`：本地实际运行的静态/源码测试记录，以及未执行项。

## 上传到 GitHub 后的使用方法

1. 将 `DongBaKe-source-24.zip` 放在仓库根目录。
2. 将 `build-apk-workflow-source-24.yml` 放到仓库的 `.github/workflows/build-apk-workflow-source-24.yml`。
3. 提交并推送后，在 GitHub 的 Actions 页面手动运行 **DongBaKe Android build - source-24 CPU + Vulkan**；工作流会先构建原生 CPU/Vulkan 后端，再构建 Debug/Release APK，并上传构建日志和产物。
4. 只有 Actions 真实运行通过后，才有可下载 APK。当前助手没有改动远端仓库，也没有替你触发工作流。
