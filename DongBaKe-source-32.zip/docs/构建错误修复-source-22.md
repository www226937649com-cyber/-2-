# source-22 构建路径错误修复记录

## 用户提供的失败日志

Gradle 报错目录为：`/home/runner/work/ai-guan-jia/ai-guan-jia/buildsrc`，并提示该目录不含 `settings.gradle`、`settings.gradle.kts` 或根构建文件。日志执行的命令是 `gradle --no-daemon assembleDebug`。

## 定位结论

这属于 Gradle **项目根目录/工作目录解析错误**，不是日志当前所显示的 Kotlin 编译、Android SDK、NDK 或 Vulkan 编译错误。source-21 压缩包中的 `settings.gradle.kts`、根 `build.gradle.kts` 和 `app/build.gradle.kts` 位于项目根目录，并没有放在 `buildsrc/` 下。

source-21 压缩包内的 `.github/workflows/android-build.yml` 原本执行的是 `gradle --no-daemon --stacktrace clean :app:testDebugUnitTest :app:assembleDebug :app:assembleRelease`，与用户日志中的单独 `gradle --no-daemon assembleDebug` 不同。因此，用户这次触发的 Actions 工作流与压缩包内此文件不一致，或存在其他工作目录配置；仅凭日志无法确定 GitHub 仓库里具体是哪一个文件设置了 `buildsrc`。

## source-22 修改

1. 在构建前新增根目录检查，要求 `settings.gradle.kts`、根 `build.gradle.kts` 和 `app/build.gradle.kts` 存在；若不存在，会打印仓库中找到的 settings 文件位置。
2. Gradle 步骤显式设置 `working-directory: ${{ github.workspace }}`。
3. Gradle 命令新增 `--project-dir "$GITHUB_WORKSPACE"`，避免继承 `buildsrc` 作为项目根目录。
4. 应用版本号递增至 `versionCode = 21`、`versionName = "0.9.7"`。

## 验收边界

这是对工作流配置的定向修复，尚未代表 GitHub Actions 已重新运行或 APK 已生成。本环境没有可用的 Android SDK/Gradle 命令，因此未在本容器完成 Android APK 构建。须将 source-22 对应文件提交到实际运行 Actions 的仓库，再检查新的构建日志及 APK Artifact。若根目录检查失败，说明仓库布局和本压缩包假设不一致，应根据检查日志调整项目路径。
