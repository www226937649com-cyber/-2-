# source-24 构建验证记录

> 本文件只记录本次执行的命令与结果，不将源码层测试误当成 Android 编译或设备实测。

## 环境检查

- `gradle` 命令：未安装/不在 PATH。
- `ANDROID_HOME`：未设置。
- `ANDROID_SDK_ROOT`：未设置。
- `ANDROID_NDK_HOME`：未设置。
- `kotlinc`：可用（用于两个独立 Kotlin 纯逻辑 smoke test）。
- 目标手机实测：未执行，按用户要求不安排。
- GitHub Actions：本次没有触发或访问用户仓库，故无云端构建结果与 APK。

## 本地命令结果

本地 Python 测试、独立 GGUF/数学解析测试、Shell 语法、源码审计和 Workflow YAML 检查均记录在外部交付文件 `DongBaKe-source-24-代码检查日志.txt`。已通过官方上游发布标签 `v0.6.0` 的 `llama.h`、`ggml-backend.h` 与 CMake 配置核对当前公开 API 及 CPU/Vulkan 动态后端结构，但这不替代 Android NDK 编译。独立测试脚本（GGUF 元数据分析、数学表达式解析、源码审计）需单独运行，以日志中实际显示的 PASS/FAIL 为准。

## 尚未验证

- 在 Android NDK + Vulkan shader compiler 下编译上游 llama.cpp `v0.6.0`。
- 在 Android CMake/Gradle 中编译 JNI、Kotlin、资源与最终 APK。
- 任何设备端 Vulkan 后端初始化、模型加载、GPU 实际推理或速度提升。

## 风险/注意

1. 上游 API、NDK 交叉编译和 Vulkan/SPIR-V 依赖的最终兼容性必须由工作流日志确认。
2. 本设备只有共享内存，CPU/GPU 混合执行不保证比 CPU-only 快；GPU 层数需在实际允许的测试条件下比较。
3. 用户取消通过原生取消标记传递；`llama_decode` 中 GPU 算子不一定能在每个内部算子执行中即时中断，当前是在 Token/解码阶段检查取消标记。
