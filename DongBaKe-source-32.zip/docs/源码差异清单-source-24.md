# source-24 源码差异清单

## 推理引擎与 JNI

- 移除旧 `llama-android:0.1.1` AAR 依赖。
- 增加 `NativeLlamaEngine.kt`，用 JNI 调用 `llama.cpp` 原生模型加载、上下文创建、采样、Token 回调、取消与释放接口。
- JNI 采用当前上游公开的文本 Token 推理接口 `llama_batch_get_one` / `llama_decode`；对普通文本聊天不启用面向混合 Token/Embedding 输入的扩展 batch 流程。
- 添加 Vulkan 插件注册检查、后端注册数/设备数与 Vulkan 设备枚举报告。
- GPU 层配置默认请求 16 层，但这不是实际 GPU 执行的证明；上下文创建或预填充失败时尝试 CPU 模型回退。
- 云端脚本固定上游 `v0.6.0` 正式发布标签，打开 `GGML_VULKAN` 和动态后端加载，递归查找安装树中的共享库/插件（兼容 `.so` 符号链接），核验并打包 `libllama.so`、`libggml.so`、`libggml-base.so`、`libggml-cpu.so`、`libggml-vulkan.so`。

## UI 与系统信息

- 更多功能中的引擎/GPU状态增加刷新操作，调用原生状态检测。
- 增加系统版本说明：Android release、API/SDK、补丁日期、设备型号、ABI、应用版本及系统 Vulkan feature 声明。
- 输出分别说明后端是否注册、系统是否能枚举 Vulkan GPU、模型请求/配置了多少 GPU 层；不把这些单独写成实际运行成功。

## 搜索流程

- 成功获取结果后保存到 `SharedPreferences`，键包含当前会话 ID。
- 先展示标题、摘要/片段与链接，再明确询问是否把资料整合。
- 用户明确确认后，才调用本地模型；提示词包含最初问题、最近聊天上下文、来源编号、原始链接，并提醒模型区分网页资料与指令。
- 用户拒绝时清除当前待整合状态；整合生成失败时保留资料供当前话题重试。

## 历史上下文

- 扩展“我前面问了什么”一类问句识别，直接从当前话题保存的 transcript 回顾。
- 给模型的上下文提升为最近最多 24 条有效消息、最多 6800 字符；保留长度上限，避免无限膨胀。

## 交付/版本

- `versionCode=22`、`versionName=0.10.0`，包名保持不变。
- 新建 `build-apk-workflow-source-24.yml`，先跑源码检查，再构建原生 CPU + Vulkan backend，之后测试及构建 APK，并归档实际日志。
- 没有修改 GitHub 远端仓库，也没有声称 workflow 已实际运行。
