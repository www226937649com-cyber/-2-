package com.aiguanjia.app

object LocalizedMathExpressionSmokeTest {
    @JvmStatic
    fun main(args: Array<String>) {
        check(LocalizedMathExpression.direct("75万×102 等于多少") == "(75*10000)*102") {
            "Large Chinese scale expression was not parsed as a whole: ${LocalizedMathExpression.direct("75万×102 等于多少")}"
        }
        check(LocalizedMathExpression.direct("5的根号3等于多少") == "5*sqrt(3)") {
            "Spoken square-root expression was not normalized: ${LocalizedMathExpression.direct("5的根号3等于多少")}"
        }
        check(LocalizedMathExpression.fallback("75万乘以102") == "(75*10000)*102") {
            "Fallback parsing did not preserve scale multiplier: ${LocalizedMathExpression.fallback("75万乘以102")}"
        }
        check(LocalizedMathExpression.direct("这句话里面有75但是不是算式").isBlank()) {
            "Parser must reject residual natural-language prose instead of extracting 75"
        }
        check(LocalizedMathExpression.sanitize("__import__('os').system('id')").isBlank()) {
            "Unsafe expression should be rejected"
        }
        println("PASS: 75万×102 is preserved as (75*10000)*102")
        println("PASS: 5的根号3 is preserved as 5*sqrt(3)")
        println("PASS: fallback parser preserves the full expression")
        println("PASS: prose fragments and unsafe code are rejected")
    }
}
