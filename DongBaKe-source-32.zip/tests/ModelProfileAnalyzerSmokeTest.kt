package com.aiguanjia.app

import java.io.File
import java.io.RandomAccessFile

/** Lightweight standalone smoke test; does not need Android SDK or model weights. */
object ModelProfileAnalyzerSmokeTest {
    @JvmStatic
    fun main(args: Array<String>) {
        require(args.size == 3) { "usage: <valid-minimal.gguf> <invalid-magic.gguf> <truncated.gguf>" }
        val good = File(args[0])
        val profile = ModelProfileAnalyzer.analyze(good)
        check(profile.ggufVersion == 3L) { "Wrong GGUF version: ${profile.ggufVersion}" }
        check(profile.architecture == "llama") { "Wrong architecture: ${profile.architecture}" }
        check(profile.quantizationHint == "Q4_K_M") { "Wrong file type: ${profile.quantizationHint}" }
        check(profile.tensorCount == 1L) { "Wrong tensor count: ${profile.tensorCount}" }
        check(profile.tensorQuantizationSummary == "Q4_0×1") { "Wrong tensor map: ${profile.tensorQuantizationSummary}" }
        check(profile.hasChatTemplate) { "Chat template should be detected" }

        val invalid = runCatching { ModelProfileAnalyzer.analyze(File(args[1])) }.exceptionOrNull()
        check(invalid != null) { "Invalid non-GGUF file was accepted as a model profile" }
        val truncated = runCatching { ModelProfileAnalyzer.analyze(File(args[2])) }.exceptionOrNull()
        check(truncated != null) { "Truncated GGUF file was accepted as a valid profile" }
        println("PASS: GGUF v3; architecture=llama; fileType=Q4_K_M; tensorTypes=Q4_0×1; chatTemplate=true")
        println("PASS: invalid non-GGUF file rejected")
        println("PASS: truncated GGUF file rejected")
    }
}
