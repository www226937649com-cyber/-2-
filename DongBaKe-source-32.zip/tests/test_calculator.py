import importlib.util
import math
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "calculator", ROOT / "app" / "src" / "main" / "python" / "calculator.py"
)
calculator = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(calculator)


class CalculatorRegressionTests(unittest.TestCase):
    def test_large_multiplication(self):
        self.assertEqual(calculator.evaluate("75 * 10000 * 102"), "76500000")

    def test_square_root_expression(self):
        self.assertAlmostEqual(float(calculator.evaluate("5 * sqrt(3)")), 5 * math.sqrt(3), places=10)

    def test_division_by_zero_is_reported(self):
        self.assertTrue(calculator.evaluate("1 / 0").startswith("ERROR:"))

    def test_disallows_code_execution(self):
        self.assertTrue(calculator.evaluate("__import__('os').system('echo unsafe')").startswith("ERROR:"))

    def test_large_exponent_is_blocked(self):
        self.assertTrue(calculator.evaluate("2 ** 1001").startswith("ERROR:"))

    def test_rejects_non_finite_result(self):
        self.assertTrue(calculator.evaluate("1e308 * 1e308").startswith("ERROR:"))


if __name__ == "__main__":
    unittest.main()
