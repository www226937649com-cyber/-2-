#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v kotlinc >/dev/null || { echo "ERROR: kotlinc is required; install Kotlin compiler." >&2; exit 2; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc "$ROOT/app/src/main/java/com/aiguanjia/app/LocalizedMathExpression.kt" "$ROOT/tests/LocalizedMathExpressionSmokeTest.kt" -include-runtime -d "$TMP/math-test.jar"
java -jar "$TMP/math-test.jar"
