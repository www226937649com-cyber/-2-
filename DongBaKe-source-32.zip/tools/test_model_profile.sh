#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v kotlinc >/dev/null || { echo "ERROR: kotlinc is required; install Kotlin compiler." >&2; exit 2; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
import struct, sys
from pathlib import Path
out = Path(sys.argv[1])

def u32(n): return struct.pack('<I', n)
def u64(n): return struct.pack('<Q', n)
def string(s):
    b = s.encode('utf-8')
    return u64(len(b)) + b
# GGUF metadata types: UINT32=4, STRING=8. Tensor: name, n_dims, dims, type, offset.
meta = [
    ("general.architecture", 8, string("llama")),
    ("general.name", 8, string("Minimal test model")),
    ("general.file_type", 4, u32(15)), # Q4_K_M
    ("tokenizer.ggml.model", 8, string("llama")),
    ("tokenizer.chat_template", 8, string("{{ messages }}")),
]
header = b'GGUF' + u32(3) + u64(1) + u64(len(meta))
body = b''.join(string(k) + u32(t) + v for k, t, v in meta)
tensor = string('token_embd.weight') + u32(1) + u64(32) + u32(2) + u64(0) # GGML_TYPE_Q4_0
(out / 'minimal.gguf').write_bytes(header + body + tensor)
(out / 'invalid.gguf').write_bytes(b'not-a-gguf-file-with-enough-bytes')
(out / 'truncated.gguf').write_bytes(b'GGUF' + u32(3) + u64(1) + u64(20))
PY
kotlinc "$ROOT/app/src/main/java/com/aiguanjia/app/ModelProfileAnalyzer.kt" "$ROOT/tests/ModelProfileAnalyzerSmokeTest.kt" -include-runtime -d "$TMP/profile-test.jar"
java -jar "$TMP/profile-test.jar" "$TMP/minimal.gguf" "$TMP/invalid.gguf" "$TMP/truncated.gguf"
