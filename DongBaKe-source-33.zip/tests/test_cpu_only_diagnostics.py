"""Regression checks for the CPU-only backend isolation and in-app diagnostics lab."""
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]

class CpuOnlyDiagnosticsTests(unittest.TestCase):
    def test_cpu_profile_can_be_built_without_vulkan_dependencies(self):
        script = (ROOT / "tools/build_llama_cpp_android_vulkan.sh").read_text(encoding="utf-8")
        cmake = (ROOT / "app/src/main/cpp/CMakeLists.txt").read_text(encoding="utf-8")
        cpp = (ROOT / "app/src/main/cpp/dongbake_llama_jni.cpp").read_text(encoding="utf-8")
        gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
        result = subprocess.run(["bash", "-n", str(ROOT / "tools/build_llama_cpp_android_vulkan.sh")], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('BACKEND_PROFILE="${BACKEND_PROFILE:-vulkan}"', script)
        self.assertIn('-DGGML_VULKAN=OFF', script)
        self.assertIn('DONGBAKE_CPU_ONLY_BUILD', cmake)
        self.assertIn('#ifndef DONGBAKE_CPU_ONLY_BUILD', cpp)
        self.assertIn('真正 CPU-only 诊断构建', cpp)
        self.assertIn('dongbakeNativeBackend', gradle)

    def test_diagnostic_ui_exports_snapshot_and_runs_minimal_native_test(self):
        main = (ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt").read_text(encoding="utf-8")
        engine = (ROOT / "app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt").read_text(encoding="utf-8")
        self.assertIn('runDiagnosticSelfTest()', main)
        self.assertIn('buildFullDiagnosticsReport()', main)
        self.assertIn('context_init_begin', main)
        self.assertIn('NativeLlamaEngine.lastNativeLogTail()', main)
        self.assertIn('NativeLlamaEngine.loadedModelReport(nativeModelHandle)', main)
        self.assertIn('diagnostic_self_test', main)
        self.assertIn('fun lastInferenceMetrics', engine)

    def test_diagnostic_self_test_checks_expected_answer_and_disables_thinking(self):
        main = (ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('outputLimit=24; purpose=diagnostic_self_test', main)
        self.assertIn('systemPrompt\\n/no_think", 24', main)
        self.assertIn('val answerCorrect = normalizedAnswer == "2"', main)
        self.assertIn('"answer_mismatch"', main)

if __name__ == "__main__":
    unittest.main()
