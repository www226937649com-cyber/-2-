plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

val dongbakeNativeBackend = providers.gradleProperty("dongbakeNativeBackend").orElse("vulkan").get()
require(dongbakeNativeBackend == "cpu" || dongbakeNativeBackend == "vulkan") {
    "dongbakeNativeBackend must be 'cpu' or 'vulkan'"
}
val dongbakeNativeInstallProfile = if (dongbakeNativeBackend == "cpu") "cpu-only" else "vulkan"

android {
    namespace = "com.aiguanjia.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aiguanjia.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 34
        versionName = "0.12.0-performance-management"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DLLAMA_CPP_INSTALL_DIR=${rootProject.projectDir}/build/llama.cpp-install-android-${dongbakeNativeInstallProfile}",
                    "-DDONGBAKE_CPU_ONLY_BUILD=${if (dongbakeNativeBackend == "cpu") "ON" else "OFF"}"
                )
                cppFlags += "-std=c++17"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jsoup:jsoup:1.18.3")

    testImplementation("junit:junit:4.13.2")
}
