package com.aiguanjia.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

/** Keeps a user-started model load/generation visible while the activity is backgrounded. */
class InferenceKeepAliveService : Service() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "本地 AI 长任务", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "用户主动发起的本地模型加载与回答任务"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val task = intent?.getStringExtra(EXTRA_TASK)?.take(100)?.ifBlank { null } ?: "正在执行本地模型任务"
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("东巴壳 AI 管家")
            .setContentText(task)
            .setContentIntent(openApp)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "dongbake_local_ai_tasks"
        private const val NOTIFICATION_ID = 3401
        private const val EXTRA_TASK = "task"

        /** Returns false rather than failing the inference if Android blocks the foreground service. */
        fun start(context: Context, task: String): Boolean = runCatching {
            val intent = Intent(context, InferenceKeepAliveService::class.java).putExtra(EXTRA_TASK, task)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
            true
        }.getOrElse {
            AppDiagnostics.log(context, "WARN", "foreground_service_start_failed", "task=$task; reason=${it.javaClass.simpleName}: ${it.message.orEmpty()}")
            false
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, InferenceKeepAliveService::class.java)) }
        }
    }
}
