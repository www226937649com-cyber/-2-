# 东巴壳 source-33：Android 快速响应与工具编排

## 目标

源设备实测显示，Qwen3.5 架构 GGUF 在 CPU-only 版本上的一次 200-token 输入，`prefillMs` 约 30.7 秒，`firstVisibleTokenMs` 约 30.8 秒，生成速度约 3.33 Token/s。主要体验故障是首字响应慢，其次是默认思考内容可能使回答继续等待。本版本只做第一轮安全、可测量的优化，不改变模型文件，也不打开未经验证的 GPU 路径。

## 代码变更

1. **更短的独立问题提示词：** 快速模式不再自动把长历史拼进每个独立问题；对短数字、选项和明确追问保留必要上下文。缩短上下文截断下限，避免 480 字符预算被强制抬高至 700。
2. **Qwen3.5 非思考提示兼容：** 当前 JNI C API 没有通用的 chat-template kwargs 参数。若 system prompt 明确包含 `/no_think` 且模型模板最终后缀严格为 `<|im_start|>assistant\n<think>\n`，就将其闭合为空思考块；否则不改模板，并记录诊断。
3. **按需工具路由：** 快速路径避免额外调用一次本地模型来“先规划工具”，这会再加一次预填充延迟。应用以意图/时效性规则先选工具；稳定概念题先用本地模型，明确搜索与新鲜数据按需联网，答案不确定时只允许一次受限搜索回退。复杂或资料综合提示词会告知工具能力。
4. **搜索自动综合：** 检索成功后直接由本地模型整合相关来源、回答原问题并附链接；无需用户二次确认。网页内容按不可信资料处理，不执行其中的指令。
5. **一次性 Android 位置权限：** 只有定位/无指定地点的天气问题触发系统权限请求，不进行后台持续定位。
6. **折叠思考记录：** 将模型输出中实际带有的 `<think>...</think>` 内容保存至聊天消息，并默认折叠在最终答案下；不把该记录拼进后续上下文。该内容是本地模型自己输出的文字，不保证是准确事实。
7. **ARM64 CPU 构建：** 通过 `GGML_CPU_KLEIDIAI=ON` 请求兼容内核；构建脚本会检查 Ninja 文件并对未确认的情况发警告。上游文档说明 KleidiAI 只加速部分兼容的量化/矩阵运算，运行时仍按设备 CPU 能力、张量格式与算子形状选择内核。

## 风险控制

- 不提高原有 `n_batch=128`、`n_ubatch=64` 诊断上限；这两项来自先前图预分配稳定性排查，不能在提速版里顺手撤掉。
- 不默认启用 Vulkan、Flash Attention、Q8_0 KV、推测解码或 NPU/APU。当前 CPU-only 基准 APK 仍不包含 Vulkan 后端。
- 快速模式的工具路由由应用本身控制，避免额外 LLM planning pass；深度/均衡模式会给模型简洁的能力说明。
- 模型 GGUF 文件已经量化/打包，不需要专门再编译模型权重。真正可以调整的是推理引擎、输入上下文、模型思考模式和硬件后端。

## 验收流程

1. `python3 -m unittest discover -s tests -v`
2. `bash tools/test_model_profile.sh`
3. `bash tools/test_math_parser.sh`
4. `bash tools/test_source_audit.sh`
5. `bash -n tools/build_llama_cpp_android_vulkan.sh`
6. 必须执行 Android Gradle/NDK 真正构建。
7. 在 Redmi Note 11T Pro 上对比同一模型、同一问题、同一 6 线程/2048 上下文设置下的 `promptTokens`、`prefillMs`、`firstVisibleTokenMs`、`decodeTokensPerSecond`，至少各重复 3 次。只用日志得出的结果评价是否提速，不预先承诺倍数。

## 当前尚未验证

- C++/Kotlin 真实 Android 编译结果（等待 CI）。
- 新 build 下 Qwen3.5 模板尾部是否匹配关闭 thinking 的条件。日志若出现 `chat_template_reasoning_control=disabled_via_qwen35_suffix`，只能证明模板变换已执行；仍需确认模型真的不再生成长思考块。
- KleidiAI 选项是否被该 pinned llama.cpp 源码实际纳入构建，以及在 MediaTek MT6895 上是否产生实测速度收益。
- Vulkan/Mali-G610 路径，留到 CPU 快速响应基线稳定后单独验证。
