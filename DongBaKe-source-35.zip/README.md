# 东巴壳 AI 管家 · source-33 移动端快速响应与工具编排

- 当前修复分支版本：`0.12.1-cpu-backend-isolation`，`versionCode=35`；包名保持 `com.aiguanjia.app`。
- 构建 ABI：`arm64-v8a` 与 `x86_64`；目标手机为 arm64-v8a。
- 推理引擎：上游 llama.cpp v0.6.0；CPU 与 Vulkan 动态后端分别构建并按 ABI 打包。


## source-33（v0.11.1-mobile-fast-path）更新

- 默认快速回答路径不再把整段旧聊天上下文塞进每个独立问题；只有明显的追问/指代才附带受限的近期上下文，避免多余的 CPU 预填充。
- 压缩快速模式的系统提示词，并让工具路由更保守：简单/稳定概念先本地回答，明确要求搜索和时效性信息才优先联网，模型回答不确定时最多触发一次受限回退。
- 联网搜索后直接自动综合来源并回答，不再额外询问用户是否要整合。
- 需要当前位置时才请求 Android 位置权限，仅用于当前请求，不启动后台持续定位。
- 保存模型输出中显式标记的 `<think>...</think>` 文本，并在最终答案下默认折叠显示，可展开查看；思考记录不回灌到下一轮提示词。
- 对 Qwen3.5 风格模板，在 `/no_think` 快速/常规请求下尝试关闭模板默认的开放 `<think>` 前缀，避免无必要的思考 token 占用时间；只在末尾模板后缀完全匹配时变换，其他模板保持原样。
- ARM64 Android CPU 构建请求启用上游 KleidiAI 优化内核。只有构建日志实际确认相关目标后，才把它当作已启用；是否提速仍需 Redmi 真机 A/B 实测。

**重要验收边界：** 本次修改面向 Android 手机，不是桌面端。模型 GGUF 已是量化模型文件，不需要另行“编译权重”；变化在于更短的输入、模型思考模式控制和更合适的 ARM64 原生 CPU 构建。源码测试通过并不代表 APK 已编译，也不代表实际提速，必须看云端 Android/NDK 构建和手机端日志。

## 本次功能工作

1. 推理设置新增 GPU 层卸载请求、KV Cache F16/Q8_0 选择、GPU Flash Attention AUTO/关闭；参数只在重新加载模型后生效。F16 和 CPU Flash Attention 关闭保持默认，Q8_0 属于实验选项。
2. 将 GGML abort callback 接入原生计算上下文，让停止请求能传递到底层图执行，而不只是取消 Kotlin 协程或等待两个 Token 之间的间隙；响应速度仍受后端算子影响，必须实机测试。
3. 记录 prompt token 数、首次可显示 Token 延迟、prefill 耗时、decode 耗时、采样 token 数与 decode tokens/s。
4. 解析 `load_tensors: offloaded X/Y layers to GPU` 作为实际层卸载的日志证据，区分配置、后端探测和卸载结果。
5. GPU 路径转 CPU 的回退模型加载显式使用 MMAP，与常规 CPU-only 路径保持一致。
6. 原生构建扩展到 `arm64-v8a` 与 `x86_64`，各 ABI 使用独立安装目录。

7. 新增可选推测解码：用户在推理参数里手动选择第二份 GGUF 草稿模型后才启用；检查目标/草稿词表一致性，验证草稿 Token，不匹配时尝试回滚未接受的 KV Cache 后缀。默认单模型生成路径保留。
8. NPU/APU 继续标记为未实现：当前没有目标 SoC 厂商 SDK/驱动与算子映射，不能把 Vulkan 支持冒充为 NPU/APU 支持。

## 验收边界

- 源码测试、Android 单元测试、NDK 原生库编译和 APK 打包是构建证据，不等于目标手机推理通过。
- 本次刻意不处理用户报告的 `llama_context::graph_reserve` / `sched_reserve` SIGSEGV；该问题应在独立下一阶段结合新的日志/tombstone 单独定位。本次不能宣称该闪退已修复。
- Token 流式回调在 source-28 已有实现；本次增加原生推理指标并保留逐步 UI 展示路径。
- Q8_0 KV Cache 是实验选项；默认使用 F16。如果个别模型/后端不兼容，可恢复 F16。
- GPU 后端发现、卸载日志、实际 GPU 计算和性能收益是不同证据等级；仍需目标设备验证。
- 推测解码已实现为显式选择草稿模型才启用的可选路径，但尚未在目标手机运行验证；NPU/APU 仍未实现，需要具体厂商 SDK、驱动和算子映射。通用 llama.cpp Vulkan 构建不代表已支持。
- 未加入温度监控、热保护、自动降线程、自动降上下文或隐式资源降级。

---

# 东巴壳 AI 管家 · source-24 开发交付包

- **应用名称：** 东巴壳 AI 管家
- **Android `applicationId`：** `com.aiguanjia.app`（保持不变）
- **应用版本：** `versionCode = 22`，`versionName = 0.10.0`
- **目标 ABI：** `arm64-v8a`
- **本地模型格式：** GGUF；模型权重不包含在源码包内。
- **推理引擎目标：** 上游 `ggml-org/llama.cpp` 发布标签 `v0.6.0`，CPU 后端 + Vulkan 动态后端；CPU 是后备路线，GPU 层卸载按请求配置。

## source-24 修改内容

1. 将旧的 `dev.ffmpegkit-maintained:llama-android:0.1.1` 完整文本调用替换为 C++/JNI 原生推理桥接；按 Token 回调输出、支持取消标记、模型上下文与 CPU 线程参数，并在 GPU 路径的上下文创建/预填充失败时尝试释放 GPU 配置模型、重新加载 CPU 模型。
2. 在“个人中心 → 打开更多功能”增加可刷新的“推理引擎 / GPU 状态”与“系统版本介绍”。报告会分别显示原生库是否加载、Vulkan 插件注册、系统 Vulkan 物理设备枚举、GGML 后端/设备数量、已加载模型的 GPU 层请求与配置；不会把系统识别到 GPU 说成 GPU 已经参与推理。
3. 联网搜索成功后先向用户展示搜索资料及原始链接，并询问是否整合；待用户在当前话题回复“整合 / 总结 / 综合”等明确确认后，才调用本地模型综合检索摘要与对话上下文。待整合结果按当前会话 ID 保存。
4. 扩展“前面问了什么”类历史回顾匹配，并在模型提示词中纳入当前会话最近最多 24 条有效消息（有长度上限），帮助本地模型理解多轮对话。
5. 增加 source-24 原生构建工作流：先获取并核验 `llama.cpp` 的 `v0.6.0` 标签，再用 Android NDK 编译 arm64 CPU + Vulkan 后端、把核心共享库与动态后端打包到 `jniLibs`，然后运行源码测试和 Gradle 单测、构建 Debug/Release APK，并归档日志与产物。

## 状态说明

**已经在源码中实现：** JNI 推理桥接代码、逐 Token 回调、取消标记、GPU→CPU 的预填充失败回退路径、引擎状态刷新、系统版本信息、联网搜索后的显式整合确认、按会话保存待整合资料、历史对话回顾扩展，以及用于云端构建的 workflow。

**尚未得到实证的部分：** 本次没有 Android SDK/NDK，也没有本机 Gradle 环境，因此无法在当前容器确认 C++/JNI、APK 的真实编译结果。当前也未运行目标手机实测（按要求不安排手机实测），所以不能宣称 Vulkan 在 Redmi Note 11T Pro 上已经实际执行或一定提速。源码里配置了 Vulkan，不等于 GPU 运行已验证。

要拿到真实 APK 和构建数据：把 `DongBaKe-source-24.zip` 放在 GitHub 仓库根目录，并把同名 workflow 文件放到仓库 `.github/workflows/build-apk-workflow-source-24.yml`，然后手动运行 `DongBaKe Android build - source-24 CPU + Vulkan`。成功时 Actions 将上传 APK、原生库、Gradle 报告和真实日志；失败时也会尽量上传已生成的诊断文件。

## 本地可重复检查

```bash
python3 -m unittest discover -s tests -v
bash tools/test_model_profile.sh
bash tools/test_math_parser.sh
bash tools/test_source_audit.sh
bash -n tools/build_llama_cpp_android_vulkan.sh
```

这些源码/脚本测试不等于 Android 工程编译、APK 生成或设备端 GPU 推理验证。
