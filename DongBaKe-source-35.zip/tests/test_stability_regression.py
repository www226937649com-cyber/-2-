"""Regression checks for source-31 low-batch graph-reserve diagnostic profile. These complement Android/NDK builds."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt"
ENGINE = ROOT / "app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt"
CPP = ROOT / "app/src/main/cpp/dongbake_llama_jni.cpp"
GRADLE = ROOT / "app/build.gradle.kts"


class StabilityRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = MAIN.read_text(encoding="utf-8")
        cls.engine = ENGINE.read_text(encoding="utf-8")
        cls.cpp = CPP.read_text(encoding="utf-8")
        cls.gradle = GRADLE.read_text(encoding="utf-8")

    def test_model_file_size_never_blocks_loading(self):
        self.assertNotIn("safeModelLimit", self.main)
        self.assertNotIn("model_load_memory_preflight", self.main)
        self.assertIn('"model_load_memory_snapshot"', self.main)
        self.assertIn("admissionGate=disabled", self.main)

    def test_dynamic_cpu_backend_is_initialized_without_gpu_offload(self):
        load_pos = self.main.index('val requestedGpuLayers = configuredGpuLayers()')
        before = self.main[max(0, load_pos - 450):load_pos]
        self.assertIn("NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)", before)

    def test_context_is_preserved_and_prompt_prefill_is_chunked(self):
        self.assertIn("ctx_params.n_ctx = static_cast<uint32_t>(session->context_size)", self.cpp)
        self.assertIn("kDiagnosticBatchCap = 128", self.cpp)
        self.assertIn("kDiagnosticMicrobatchCap = 64", self.cpp)
        self.assertIn("profile=source35-cpu-backend-isolation", self.cpp)
        self.assertIn("while (prefill_offset < prompt_tokens.size())", self.cpp)
        self.assertIn("prompt_tokens.data() + prefill_offset", self.cpp)

    def test_native_load_log_tail_surfaces_into_app_diagnostics(self):
        self.assertIn("nativeLastLogTail", self.engine)
        self.assertIn("nativeLastLogTail", self.cpp)
        self.assertIn('"model_load_exception"', self.main)
        self.assertIn('"native_inference_exception"', self.main)
        self.assertIn('"model_inference"', self.main)

    def test_native_log_callback_cannot_throw_into_upstream_c_code(self):
        self.assertIn("void append_native_log_tail(const char * text) noexcept", self.cpp)
        self.assertIn("Never allow diagnostics allocation failure to escape", self.cpp)


    def test_cpu_inference_disables_android_flash_attention(self):
        self.assertIn("ctx_params.flash_attn_type = gpu_flash_attention_enabled", self.cpp)
        self.assertIn("LLAMA_FLASH_ATTN_TYPE_DISABLED", self.cpp)
        self.assertIn("ctx_params.offload_kqv = session->active_gpu_layers > 0 && session->kv_cache_quantization == 0", self.cpp)

    def test_native_inference_has_phase_breadcrumbs_and_persisted_log_monitor(self):
        for marker in ("tokenization_begin", "prompt_prefill_batch_begin", "first_sampler_sample_begin", "first_generated_token_decode_begin"):
            self.assertIn(marker, self.cpp)
        self.assertIn('"llama_inference_checkpoint"', self.main)
        self.assertIn('"native_inference_final_tail"', self.main)

    def test_diagnostics_abi_label_does_not_claim_device_abis_are_apk_abis(self):
        self.assertIn("设备支持的 ABI（不代表 APK 实际打包架构）", self.main)

    def test_new_version_preserves_application_id(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', self.gradle)
        self.assertRegex(self.gradle, r'versionCode\s*=\s*35\b')
        self.assertIn('versionName = "0.12.1-cpu-backend-isolation"', self.gradle)

    def test_cpu_only_model_loading_forces_file_backed_mmap(self):
        self.assertIn("params.load_mode = LLAMA_LOAD_MODE_MMAP", self.cpp)
        self.assertIn("params.load_mode = LLAMA_LOAD_MODE_MMAP", self.cpp)

    def test_cpu_default_does_not_register_vulkan_or_all_dynamic_backends(self):
        self.assertNotRegex(self.cpp, r"(?m)^\s*ggml_backend_load_all_from_path\s*\(")
        self.assertIn('ggml_backend_load(cpu_path.c_str())', self.cpp)
        self.assertIn('if (request_vulkan && ggml_backend_reg_by_name("Vulkan") == nullptr)', self.cpp)
        self.assertIn('reason=explicit_gpu_offload_request', self.cpp)
        self.assertIn('session->active_gpu_layers == 0 ? "CPU_ONLY" : "CPU_VULKAN"', self.cpp)

    def test_zero_gpu_layers_pins_model_to_cpu_and_disables_extra_bufts(self):
        self.assertIn('params.devices = cpu_devices;', self.cpp)
        self.assertIn('params.use_extra_bufts = false;', self.cpp)
        self.assertIn('device_scope=" + (layers == 0 ? "CPU_ONLY"', self.cpp)
        self.assertIn('model_load_params_failed reason=cpu_device_not_registered', self.cpp)
        self.assertIn('gpu_to_cpu_retry_load_params layers=0 load_mode=MMAP device_scope=CPU_ONLY use_extra_bufts=false', self.cpp)

    def test_native_log_tail_is_collected_while_model_load_blocks(self):
        self.assertIn("nativeLogCollector = lifecycleScope.launch(Dispatchers.IO)", self.main)
        self.assertIn("cancelAndJoin()", self.main)
        self.assertIn("nativeClearLogTail", self.engine)

    def test_android_exit_history_is_persisted_after_native_crash_or_lmk(self):
        self.assertIn("getHistoricalProcessExitReasons", (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8"))
        self.assertIn("REASON_CRASH_NATIVE", (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8"))
        self.assertIn("REASON_LOW_MEMORY", (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8"))

    def test_qwen35_fast_path_can_close_default_think_prefix(self):
        self.assertIn('system_prompt.find("/no_think")', self.cpp)
        self.assertIn(r'<|im_start|>assistant\n<think>\n', self.cpp)
        self.assertIn('</think>', self.cpp)
        self.assertIn('chat_template_reasoning_control=disabled_via_qwen35_suffix', self.cpp)

    def test_native_abort_callback_is_passed_into_context(self):
        self.assertIn("ctx_params.abort_callback = should_abort_native_compute", self.cpp)
        self.assertIn("ctx_params.abort_callback_data = session.get()", self.cpp)
        self.assertIn("cancelled.load(std::memory_order_acquire)", self.cpp)

    def test_kv_cache_q8_is_opt_in_and_f16_is_default(self):
        self.assertIn("GGML_TYPE_Q8_0", self.cpp)
        self.assertIn("GGML_TYPE_F16", self.cpp)
        self.assertIn('inference_kv_cache_quantization', self.main)

    def test_gpu_offload_report_uses_runtime_log_evidence(self):
        self.assertIn("record_gpu_offload_evidence", self.cpp)
        self.assertIn("observed_gpu_layers", self.cpp)
        self.assertIn('sectionLabel("GPU / Vulkan 卸载层数")', self.main)

    def test_inference_metrics_are_logged_without_prompt_or_answer_body(self):
        self.assertIn("nativeLastInferenceMetrics", self.engine)
        self.assertIn('"inference_metrics"', self.main)
        self.assertIn("first_visible_token_ms=", self.cpp)


if __name__ == "__main__":
    unittest.main()
