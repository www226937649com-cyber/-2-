package com.aiguanjia.app

/**
 * Separates the model's soft thinking target from the generation safety caps.
 * The pinned llama.cpp v0.6.0 API used by this app does not expose the newer
 * reasoning-budget sampler, so we guide the first pass and gracefully switch
 * to an answer-only continuation if that pass reaches its limit.
 */
internal data class InferenceGenerationBudget(
    val modeIndex: Int,
    val modeName: String,
    val softThinkingTokens: Int,
    val firstPassTokens: Int,
    val hardOutputTokens: Int
)

internal object InferenceBudgetPolicy {
    private const val MAX_HARD_OUTPUT_TOKENS = 4096

    fun forMode(modeIndex: Int, contextSize: Int): InferenceGenerationBudget {
        val mode = modeIndex.coerceIn(0, 2)
        // Leave at least half the context available for system/user/history input.
        // This avoids the previous bug where increasing output tokens silently
        // truncated the input prompt to only a few dozen tokens.
        val safeContext = contextSize.coerceIn(512, 32768)
        val hard = minOf(MAX_HARD_OUTPUT_TOKENS, (safeContext / 2).coerceAtLeast(256))
        val soft = when (mode) {
            0 -> 64       // quick mode: answer concisely; /no_think is the primary switch
            1 -> 384      // balanced: modest reasoning target
            else -> 1024  // deep: allow more analysis, but prompt the model to converge
        }
        val answerRunway = when (mode) {
            0 -> 224
            1 -> 384
            else -> 768
        }
        val firstPass = minOf(hard, soft + answerRunway).coerceAtLeast(1)
        val name = when (mode) {
            0 -> "快速"
            1 -> "均衡"
            else -> "深度"
        }
        return InferenceGenerationBudget(mode, name, soft, firstPass, hard)
    }

    /** Detect hard-cap exhaustion plus malformed/unfinished reasoning-only output. */
    fun continuationReason(output: String, metrics: String, requestedTokens: Int): String? {
        if (reachedTokenLimit(metrics, requestedTokens)) return "token_cap"
        if (output.isBlank()) return "empty_output"
        val normalized = output.lowercase()
        val openThink = normalized.lastIndexOf("<think>")
        val closeThink = normalized.lastIndexOf("</think>")
        if (openThink > closeThink) return "unfinished_think_block"
        if (openThink >= 0) {
            val answerAfterThink = if (closeThink >= 0) {
                output.substring(closeThink + "</think>".length).trim()
            } else ""
            if (answerAfterThink.isBlank()) return "missing_final_answer"
        }
        return null
    }

    /** True only when native metrics show that generation exhausted its requested token cap. */
    fun reachedTokenLimit(metrics: String, requestedTokens: Int): Boolean {
        if (requestedTokens <= 0) return false
        val generated = Regex("(?:^|[;\\s])generatedTokens=(\\d+)(?:[;\\s]|$)")
            .find(metrics)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: return false
        return generated >= requestedTokens
    }
}
