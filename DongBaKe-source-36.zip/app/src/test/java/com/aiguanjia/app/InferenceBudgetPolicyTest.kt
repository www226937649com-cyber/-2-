package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InferenceBudgetPolicyTest {
    @Test fun modeSoftTargetsIncreaseFromQuickToDeep() {
        val quick = InferenceBudgetPolicy.forMode(0, 4096)
        val balanced = InferenceBudgetPolicy.forMode(1, 4096)
        val deep = InferenceBudgetPolicy.forMode(2, 4096)

        assertTrue(quick.softThinkingTokens < balanced.softThinkingTokens)
        assertTrue(balanced.softThinkingTokens < deep.softThinkingTokens)
        assertEquals("快速", quick.modeName)
        assertEquals("均衡", balanced.modeName)
        assertEquals("深度", deep.modeName)
    }

    @Test fun hardCapLeavesAtLeastHalfContextForInputAndIsBounded() {
        val small = InferenceBudgetPolicy.forMode(2, 2048)
        val large = InferenceBudgetPolicy.forMode(2, 32768)

        assertEquals(1024, small.hardOutputTokens)
        assertEquals(4096, large.hardOutputTokens)
        assertTrue(small.firstPassTokens <= small.hardOutputTokens)
        assertTrue(large.firstPassTokens <= large.hardOutputTokens)
    }

    @Test fun softBudgetIsNotSameAsHardOutputCap() {
        val budget = InferenceBudgetPolicy.forMode(1, 4096)
        assertEquals(384, budget.softThinkingTokens)
        assertEquals(768, budget.firstPassTokens)
        assertEquals(2048, budget.hardOutputTokens)
    }

    @Test fun explicitUserCancellationNeverTriggersAutomaticContinuation() {
        assertEquals(null, InferenceBudgetPolicy.continuationReason(
            "A deliberately stopped partial answer",
            "promptTokens=600; generatedTokens=768; cancelled=true", 768
        ))
    }

    @Test fun detectsOnlyAnActuallyExhaustedTokenLimit() {
        assertTrue(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; generatedTokens=768; cancelled=false", 768))
        assertTrue(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; generatedTokens=800; decodeMs=2", 768))
        assertFalse(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; generatedTokens=767; cancelled=false", 768))
        assertFalse(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; cancelled=false", 768))
        assertFalse(InferenceBudgetPolicy.reachedTokenLimit("generatedTokens=100", 0))
    }

    @Test fun detectsUnfinishedThinkingEvenBeforeTheHardTokenCap() {
        assertEquals("unfinished_think_block", InferenceBudgetPolicy.continuationReason(
            "<think>Let me consider this carefully", "promptTokens=600; generatedTokens=80; cancelled=false", 768
        ))
        assertEquals("missing_final_answer", InferenceBudgetPolicy.continuationReason(
            "<think>Reasoning is complete</think>", "promptTokens=600; generatedTokens=80; cancelled=false", 768
        ))
        assertEquals("token_cap", InferenceBudgetPolicy.continuationReason(
            "A short but capped answer", "promptTokens=600; generatedTokens=768; cancelled=false", 768
        ))
        assertEquals(null, InferenceBudgetPolicy.continuationReason(
            "<think>Reason</think>The answer is 42.", "promptTokens=600; generatedTokens=80; cancelled=false", 768
        ))
    }
}
