package com.aiguanjia.app

/**
 * Separates the model's soft thinking target from the generation safety caps.
 * The pinned llama.cpp v0.6.0 API used by this app does not expose the newer
 * reasoning-budget sampler, so we guide the first pass and gracefully switch
 * to an answer-only continuation if that pass reaches its limit.
 */
internal data class InferenceGenerationBudget(
    val modeIndex: Int,
    val modeName: String,
    val softThinkingTokens: Int,
    val firstPassTokens: Int,
    val hardOutputTokens: Int
)

internal object InferenceBudgetPolicy {
    private const val MAX_HARD_OUTPUT_TOKENS = 4096

    /** Context preference follows the selected mode. It is a soft app policy, not a live resize of llama_context. */
    fun recommendedContextSize(modeIndex: Int): Int = when (modeIndex.coerceIn(0, 2)) {
        0 -> 1024
        1 -> 2048
        else -> 4096
    }

    /** Context space exposed to a turn cannot exceed the context size used when the loaded native model was created. */
    fun effectiveContextSize(preferredContextSize: Int, loadedContextSize: Int?): Int {
        val preferred = preferredContextSize.coerceIn(512, 32768)
        return loadedContextSize?.takeIf { it >= 512 }?.let { minOf(preferred, it) } ?: preferred
    }

    /** Conservative character guard for prompt assembly; chars are not claimed to equal model tokens. */
    fun softPromptCharLimit(modeIndex: Int, contextSize: Int): Int {
        val context = contextSize.coerceIn(512, 32768)
        val modeLimit = when (modeIndex.coerceIn(0, 2)) {
            0 -> 1200
            1 -> 3600
            else -> 6000
        }
        return minOf(modeLimit, context * 2).coerceAtLeast(700)
    }

    /** Preserve the end of the prompt, where the user's latest question and assistant prefix normally live. */
    fun trimPromptToSoftCharLimit(prompt: String, modeIndex: Int, contextSize: Int): String {
        val limit = softPromptCharLimit(modeIndex, contextSize)
        return if (prompt.length <= limit) prompt else "[较早上下文已按当前模式软性压缩。]\n" + prompt.takeLast(limit - 24)
    }

    fun forMode(modeIndex: Int, contextSize: Int): InferenceGenerationBudget {
        val mode = modeIndex.coerceIn(0, 2)
        // Leave at least half the context available for system/user/history input.
        // This avoids the previous bug where increasing output tokens silently
        // truncated the input prompt to only a few dozen tokens.
        val safeContext = contextSize.coerceIn(512, 32768)
        val hard = minOf(MAX_HARD_OUTPUT_TOKENS, (safeContext / 2).coerceAtLeast(256))
        val soft = when (mode) {
            0 -> 64       // quick mode: answer concisely; /no_think is the primary switch
            1 -> 384      // balanced: modest reasoning target
            else -> 1024  // deep: allow more analysis, but prompt the model to converge
        }
        val answerRunway = when (mode) {
            0 -> 224
            1 -> 384
            else -> 768
        }
        val firstPass = minOf(hard, soft + answerRunway).coerceAtLeast(1)
        val name = when (mode) {
            0 -> "快速"
            1 -> "均衡"
            else -> "深度"
        }
        return InferenceGenerationBudget(mode, name, soft, firstPass, hard)
    }

    /** Detect hard-cap exhaustion plus malformed/unfinished reasoning-only output. */
    fun continuationReason(output: String, metrics: String, requestedTokens: Int): String? {
        // Respect an explicit user stop; never restart generation automatically after cancellation.
        if (Regex("(?:^|[;\\s])cancelled=true(?:[;\\s]|$)").containsMatchIn(metrics)) return null
        if (reachedTokenLimit(metrics, requestedTokens)) return "soft_budget"
        if (output.isBlank()) return "empty_output"
        val normalized = output.lowercase()
        val openThink = normalized.lastIndexOf("<think>")
        val closeThink = normalized.lastIndexOf("</think>")
        if (openThink > closeThink) return "unfinished_think_block"
        if (openThink >= 0) {
            val answerAfterThink = if (closeThink >= 0) {
                output.substring(closeThink + "</think>".length).trim()
            } else ""
            if (answerAfterThink.isBlank()) return "missing_final_answer"
        }
        return null
    }
    /** Classifies the final native generation outcome using explicit evidence only. */
    fun finalTerminationReason(
        output: String,
        metrics: String,
        requestedTokens: Int,
        continuationStillCapped: Boolean,
        nativeLogTail: String,
        timedOut: Boolean = false
    ): String {
        if (timedOut) return "timeout"
        if (Regex("(?:^|[;\\s])cancelled=true(?:[;\\s]|$)").containsMatchIn(metrics)) return "user_stop"
        val native = nativeLogTail.lowercase()
        val contextLimitEvidence = listOf(
            "n_past + n_tokens > n_ctx",
            "context limit reached",
            "context is full",
            "context overflow",
            "input exceeds context",
            "prompt exceeds context"
        ).any { it in native }
        if (contextLimitEvidence) return "context_limit"
        val engineError = output.isBlank() ||
            output.startsWith("无法创建本地推理上下文") ||
            output.startsWith("无法初始化 Token 采样器") ||
            output.startsWith("模型预填充失败") ||
            output.startsWith("无法分配 Token 采样器") ||
            native.contains("native inference exception") ||
            native.contains("prompt_prefill_batch_failed") ||
            Regex("decode stopped with result=-?\\d+").containsMatchIn(native)
        if (engineError) return "engine_error"
        if (continuationStillCapped || reachedTokenLimit(metrics, requestedTokens)) return "hard_limit"
        return "natural_stop"
    }

    /** True only when native metrics show that generation exhausted its requested token cap. */
    fun reachedTokenLimit(metrics: String, requestedTokens: Int): Boolean {
        if (requestedTokens <= 0) return false
        val generated = Regex("(?:^|[;\\s])generatedTokens=(\\d+)(?:[;\\s]|$)")
            .find(metrics)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: return false
        return generated >= requestedTokens
    }
}
