package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InferenceBudgetPolicyTest {
    @Test fun modeSoftTargetsIncreaseFromQuickToDeep() {
        val quick = InferenceBudgetPolicy.forMode(0, 4096)
        val balanced = InferenceBudgetPolicy.forMode(1, 4096)
        val deep = InferenceBudgetPolicy.forMode(2, 4096)

        assertTrue(quick.softThinkingTokens < balanced.softThinkingTokens)
        assertTrue(balanced.softThinkingTokens < deep.softThinkingTokens)
        assertEquals("快速", quick.modeName)
        assertEquals("均衡", balanced.modeName)
        assertEquals("深度", deep.modeName)
    }

    @Test fun hardCapLeavesAtLeastHalfContextForInputAndIsBounded() {
        val small = InferenceBudgetPolicy.forMode(2, 2048)
        val large = InferenceBudgetPolicy.forMode(2, 32768)

        assertEquals(1024, small.hardOutputTokens)
        assertEquals(4096, large.hardOutputTokens)
        assertTrue(small.firstPassTokens <= small.hardOutputTokens)
        assertTrue(large.firstPassTokens <= large.hardOutputTokens)
    }

    @Test fun softBudgetIsNotSameAsHardOutputCap() {
        val budget = InferenceBudgetPolicy.forMode(1, 4096)
        assertEquals(384, budget.softThinkingTokens)
        assertEquals(768, budget.firstPassTokens)
        assertEquals(2048, budget.hardOutputTokens)
    }

    @Test fun explicitUserCancellationNeverTriggersAutomaticContinuation() {
        assertEquals(null, InferenceBudgetPolicy.continuationReason(
            "A deliberately stopped partial answer",
            "promptTokens=600; generatedTokens=768; cancelled=true", 768
        ))
    }

    @Test fun detectsOnlyAnActuallyExhaustedTokenLimit() {
        assertTrue(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; generatedTokens=768; cancelled=false", 768))
        assertTrue(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; generatedTokens=800; decodeMs=2", 768))
        assertFalse(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; generatedTokens=767; cancelled=false", 768))
        assertFalse(InferenceBudgetPolicy.reachedTokenLimit("promptTokens=600; cancelled=false", 768))
        assertFalse(InferenceBudgetPolicy.reachedTokenLimit("generatedTokens=100", 0))
    }

    @Test fun detectsUnfinishedThinkingEvenBeforeTheHardTokenCap() {
        assertEquals("unfinished_think_block", InferenceBudgetPolicy.continuationReason(
            "<think>Let me consider this carefully", "promptTokens=600; generatedTokens=80; cancelled=false", 768
        ))
        assertEquals("missing_final_answer", InferenceBudgetPolicy.continuationReason(
            "<think>Reasoning is complete</think>", "promptTokens=600; generatedTokens=80; cancelled=false", 768
        ))
        assertEquals("soft_budget", InferenceBudgetPolicy.continuationReason(
            "A short but capped answer", "promptTokens=600; generatedTokens=768; cancelled=false", 768
        ))
        assertEquals(null, InferenceBudgetPolicy.continuationReason(
            "<think>Reason</think>The answer is 42.", "promptTokens=600; generatedTokens=80; cancelled=false", 768
        ))
    }
    @Test fun contextPreferenceChangesDynamicallyByMode() {
        assertEquals(1024, InferenceBudgetPolicy.recommendedContextSize(0))
        assertEquals(2048, InferenceBudgetPolicy.recommendedContextSize(1))
        assertEquals(4096, InferenceBudgetPolicy.recommendedContextSize(2))
    }

    @Test fun preferredContextCannotExceedCurrentlyLoadedNativeContext() {
        assertEquals(2048, InferenceBudgetPolicy.effectiveContextSize(4096, 2048))
        assertEquals(1024, InferenceBudgetPolicy.effectiveContextSize(1024, 4096))
        assertEquals(4096, InferenceBudgetPolicy.effectiveContextSize(4096, null))
    }

    @Test fun softPromptTrimKeepsRecentQuestionAtTheEnd() {
        val large = "old-context-".repeat(400) + "CURRENT QUESTION: why is the sky blue?"
        val trimmed = InferenceBudgetPolicy.trimPromptToSoftCharLimit(large, 0, 2048)
        assertTrue(trimmed.length <= InferenceBudgetPolicy.softPromptCharLimit(0, 2048))
        assertTrue(trimmed.endsWith("CURRENT QUESTION: why is the sky blue?"))
        assertTrue(trimmed.contains("软性压缩"))
    }

    @Test fun finalTerminationReasonsAreExplicitAndEvidenceBased() {
        assertEquals("natural_stop", InferenceBudgetPolicy.finalTerminationReason(
            "42", "promptTokens=8; generatedTokens=12; cancelled=false", 64, false, "sampler_emitted_end_of_generation"
        ))
        assertEquals("user_stop", InferenceBudgetPolicy.finalTerminationReason(
            "partial", "generatedTokens=3; cancelled=true", 64, false, ""
        ))
        assertEquals("hard_limit", InferenceBudgetPolicy.finalTerminationReason(
            "partial", "generatedTokens=64; cancelled=false", 64, true, ""
        ))
        assertEquals("timeout", InferenceBudgetPolicy.finalTerminationReason("", "", 64, false, "", timedOut = true))
        assertEquals("context_limit", InferenceBudgetPolicy.finalTerminationReason(
            "partial", "generatedTokens=2; cancelled=false", 64, false, "context limit reached"
        ))
        assertEquals("engine_error", InferenceBudgetPolicy.finalTerminationReason(
            "", "generatedTokens=0; cancelled=false", 64, false, "prompt_prefill_batch_failed result=-1"
        ))
    }
}
