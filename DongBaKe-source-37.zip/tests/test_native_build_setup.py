"""Regression checks for the source-29 native engine build contract."""
from pathlib import Path
import os
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "tools/build_llama_cpp_android_vulkan.sh"
BUILD = ROOT / "app/build.gradle.kts"
CMAKE = ROOT / "app/src/main/cpp/CMakeLists.txt"
CPP = ROOT / "app/src/main/cpp/dongbake_llama_jni.cpp"


class NativeVulkanBuildSetupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.script = SCRIPT.read_text(encoding="utf-8")
        cls.build = BUILD.read_text(encoding="utf-8")
        cls.cmake = CMAKE.read_text(encoding="utf-8")
        cls.cpp = CPP.read_text(encoding="utf-8")

    def test_shell_script_parses(self):
        result = subprocess.run(["bash", "-n", str(SCRIPT)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_missing_ndk_fails_before_network_operations(self):
        env = os.environ.copy()
        env["ANDROID_NDK"] = "/definitely/missing/android-ndk"
        env.pop("ANDROID_HOME", None)
        result = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("Android NDK not found", result.stderr)

    def test_upstream_engine_is_pinned_and_builds_cpu_plus_vulkan(self):
        self.assertIn('LLAMA_CPP_TAG="v0.6.0"', self.script)
        self.assertIn('-DANDROID_ABI="$abi"', self.script)
        self.assertIn('ANDROID_ABIS="${ANDROID_ABIS:-arm64-v8a x86_64}"', self.script)
        for flag in ("-DGGML_NATIVE=OFF", "-DGGML_VULKAN=ON", "-DGGML_CPU=ON", "-DGGML_BACKEND_DL=ON", "-DBUILD_SHARED_LIBS=ON"):
            self.assertIn(flag, self.script)
        self.assertIn('describe --tags --exact-match HEAD', self.script)
        self.assertIn('-DGGML_CPU_KLEIDIAI=ON', self.script)
        self.assertIn('if [[ "$abi" == "arm64-v8a" ]]', self.script)

    def test_build_supports_two_abis_with_separate_install_trees(self):
        self.assertIn("for abi in $ANDROID_ABIS", self.script)
        self.assertIn("x86_64", self.script)
        self.assertIn("${LLAMA_CPP_INSTALL_DIR}/${abi}", self.script)
        self.assertIn('abiFilters += listOf("arm64-v8a", "x86_64")', self.build)
        self.assertIn('${LLAMA_CPP_ABI_INSTALL_DIR}/include', self.cmake)
        self.assertIn('jniLibs/${ANDROID_ABI}', self.cmake)

    def test_backend_files_are_required_not_assumed(self):
        for text in ("libllama.so not found", "libggml.so not found", "libggml-vulkan.so missing", "libggml-cpu.so missing"):
            self.assertIn(text, self.script)
        self.assertIn("does not prove Vulkan execution", self.script)

    def test_application_version_increments_without_package_change(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', self.build)
        self.assertRegex(self.build, r'versionCode\s*=\s*37\b')
        self.assertIn('versionName = "0.12.3-context-logging"', self.build)
        self.assertIn('abiFilters += listOf("arm64-v8a", "x86_64")', self.build)

    def test_native_abort_and_kv_cache_configuration_are_present(self):
        self.assertIn("ctx_params.abort_callback = should_abort_native_compute", self.cpp)
        self.assertIn("ctx_params.type_k = cache_type", self.cpp)
        self.assertIn("ctx_params.type_v = cache_type", self.cpp)
        self.assertIn("record_gpu_offload_evidence", self.cpp)


if __name__ == "__main__":
    unittest.main()
