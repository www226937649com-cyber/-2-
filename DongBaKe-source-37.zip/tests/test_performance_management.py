from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt").read_text(encoding="utf-8")
DIAGNOSTICS = (ROOT / "app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt").read_text(encoding="utf-8")
SERVICE = (ROOT / "app/src/main/java/com/aiguanjia/app/InferenceKeepAliveService.kt").read_text(encoding="utf-8")
MANIFEST = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")


class PerformanceManagementSourceTests(unittest.TestCase):
    def test_management_page_is_reachable_from_more_features(self):
        self.assertIn('"⚡ 性能与运行管理"', MAIN)
        self.assertIn('showPerformanceManagementScreen()', MAIN)
        self.assertIn('"① Prefill：首字前的输入处理"', MAIN)

    def test_cross_turn_kv_reuse_is_not_falsely_reported(self):
        self.assertIn('跨多轮聊天的 KV Cache 复用目前并未实现', MAIN)
        self.assertIn('KV Cache 精度（F16 / Q8_0）', MAIN)

    def test_gpu_toggle_requires_plugin_offload_and_physical_device(self):
        self.assertIn('Vulkan 后端插件注册：已注册', MAIN)
        self.assertIn('llama.cpp GPU offload 能力：后端报告支持', MAIN)
        self.assertIn('检测到\\\\s+[1-9][0-9]* 个 Vulkan 物理设备', MAIN)
        self.assertIn('requestedGpuLayers=4', MAIN)
        self.assertIn('actualOffload=unverified_until_reload', MAIN)

    def test_auto_thread_default_is_conservative_but_keeps_user_override(self):
        self.assertIn('return if (requested in 2..6) requested else', MAIN)
        self.assertIn('minOf(Runtime.getRuntime().availableProcessors().coerceAtLeast(2), 4)', MAIN)

    def test_log_toggle_keeps_warning_and_crash_levels(self):
        self.assertIn('getBoolean("runtime_logging_enabled", true)', DIAGNOSTICS)
        self.assertIn('normalizedLevel !in setOf("WARN", "WARNING", "ERROR", "FATAL", "CRITICAL")', DIAGNOSTICS)

    def test_live_preview_can_be_disabled_without_disabling_final_answer(self):
        self.assertIn('getBoolean("runtime_live_stats_enabled", true)', MAIN)
        self.assertIn('putBoolean("runtime_live_stats_enabled", checked)', MAIN)
        self.assertIn('NativeLlamaEngine.generate(\n                                                loadedHandle, actualPrompt, systemPrompt, tokenLimit', MAIN)
        self.assertIn('InferenceBudgetPolicy.forMode(responseModeIndex, effectiveContextSize)', MAIN)
        self.assertIn('inference_soft_budget_continuation', MAIN)
        self.assertIn('inference_continuation_complete', MAIN)
        self.assertIn('delay(if (liveStatsEnabled) 180 else 1000)', MAIN)
        self.assertIn('最终回答仍正常生成', MAIN)

    def test_foreground_service_is_user_triggered_and_not_sticky(self):
        self.assertIn('startForeground(NOTIFICATION_ID, notification)', SERVICE)
        self.assertIn('return START_NOT_STICKY', SERVICE)
        self.assertIn('android.permission.FOREGROUND_SERVICE_SPECIAL_USE', MANIFEST)
        self.assertIn('android:foregroundServiceType="specialUse"', MANIFEST)
        self.assertIn('InferenceKeepAliveService.stop(this@MainActivity)', MAIN)

    def test_version_increments_without_changing_package_id(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', BUILD)
        self.assertRegex(BUILD, r'versionCode\s*=\s*37\b')
        self.assertIn('versionName = "0.12.3-context-logging"', BUILD)


if __name__ == "__main__":
    unittest.main()
