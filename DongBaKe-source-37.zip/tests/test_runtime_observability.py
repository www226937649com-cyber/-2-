from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class RuntimeObservabilityContractTests(unittest.TestCase):
    def text(self, relative):
        return (ROOT / relative).read_text(encoding="utf-8")

    def test_diagnostics_schema_is_versioned_and_append_only(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt")
        self.assertIn("const val SCHEMA_VERSION = 2", source)
        self.assertIn('"diagnostics_schema"', source)
        self.assertIn("logFileSnapshot", source)
        self.assertIn("OLD_LOG", source)
        self.assertIn("runtime_logging_enabled", source)

    def test_runtime_log_screen_has_shared_logging_switch_and_export_schema(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        log_screen = source[source.index("private fun showDiagnosticLogsScreen"):source.index("private fun showMoreFeaturesScreen")]
        self.assertIn('text = "记录普通运行日志（排查问题时建议开启）"', log_screen)
        self.assertIn('putBoolean("runtime_logging_enabled", checked)', log_screen)
        report = source[source.index("private fun buildFullDiagnosticsReport"):source.index("private fun runLocalInferenceBenchmark")]
        self.assertIn("AppDiagnostics.SCHEMA_VERSION", report)
        self.assertIn("loadedModelContextSize", report)
        self.assertIn("logFileSnapshot", report)

    def test_inference_metrics_include_context_mode_and_stage_timings_without_content(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertIn('"inference_prompt_policy"', source)
        self.assertIn('"inference_metrics"', source)
        for key in ["systemPromptChars=", "effectiveSoftContext=", "firstPassElapsedMs=", "continuationElapsedMs=", "continuationReason=", "firstPassThinkTagsObserved=", "firstPassVisibleThinkChars=", "finalOutputThinkTagsObserved=", "firstPassNativeMetrics=", "continuationNativeMetrics="]:
            self.assertIn(key, source)
        metrics = source[source.index('"inference_metrics"'):source.index('"inference_metrics"') + 1600]
        self.assertNotIn('append(raw)', metrics)
        self.assertNotIn('append(actualPrompt)', metrics)

    def test_mode_context_policy_and_short_prompts_are_used_in_generation(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertIn('putInt("inference_context_size", targetContext)', source)
        self.assertIn("InferencePromptPolicy.systemPrompt(", source)
        self.assertIn("check(systemPrompt.length <= 100)", source)
        policy = self.text("app/src/main/java/com/aiguanjia/app/InferencePromptPolicy.kt")
        self.assertIn("if (!supportsReasoning) """, policy)
        self.assertIn("InferenceBudgetPolicy.effectiveContextSize", source)

    def test_search_synthesis_no_longer_uses_fixed_four_source_prompt(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertIn("SearchSynthesisPolicy.forMode", source)
        self.assertIn("results.take(synthesisBudget.maxSources)", source)
        self.assertIn('"search_synthesis_prompt_budget"', source)

    def test_observability_contract_is_part_of_the_source_regression_suite(self):
        # The build workflow lives in the repository, not inside the source ZIP.
        # Keep this contract test portable so it also runs from clean source archives.
        suite = self.text("tests/test_runtime_observability.py")
        self.assertIn("test_inference_metrics_include_context_mode_and_stage_timings_without_content", suite)
        self.assertIn("test_runtime_log_screen_has_shared_logging_switch_and_export_schema", suite)
        self.assertTrue((ROOT / "tests/test_runtime_observability.py").is_file())

if __name__ == "__main__":
    unittest.main()
