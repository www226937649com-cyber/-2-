package com.aiguanjia.app

/**
 * JNI bridge for the pinned upstream llama.cpp engine.
 * CPU-only diagnostic APKs deliberately omit Vulkan; the standard profile packages CPU+Vulkan.
 */
object NativeLlamaEngine {
    private const val GPU_RETRY_MARKER = "__DONGBAKE_GPU_RETRY_CPU__"

    interface TokenListener {
        fun onToken(token: String)
    }

    private val libraryLoadError: String?
    @Volatile private var backendInitialized = false
    val isAvailable: Boolean

    init {
        var error: String? = null
        var available = false
        try {
            System.loadLibrary("dongbake_llama")
            available = true
        } catch (t: Throwable) {
            error = "加载原生引擎失败：${t.javaClass.simpleName}: ${t.message.orEmpty()}"
        }
        isAvailable = available
        libraryLoadError = error
    }

    @Synchronized fun initializeBackend(nativeLibraryDir: String) {
        if (!isAvailable || backendInitialized) return
        nativeInitializeBackend(nativeLibraryDir)
        backendInitialized = true
    }

    fun statusReport(): String = if (!isAvailable) {
        "原生 llama.cpp 引擎：不可用\n${libraryLoadError.orEmpty()}\n请使用配套云端工作流构建原生库和 APK。"
    } else runCatching { nativeEngineInfo() }
        .getOrElse { "原生 llama.cpp 已载入，但读取后端信息失败：${it.message.orEmpty()}" }

    fun lastNativeLogTail(): String = if (!isAvailable) {
        libraryLoadError.orEmpty()
    } else runCatching { nativeLastLogTail() }.getOrDefault("")

    fun clearNativeLogTail() {
        if (isAvailable) runCatching { nativeClearLogTail() }
    }

    fun loadModel(
        path: String,
        contextSize: Int,
        threads: Int,
        gpuLayers: Int = 0,
        kvCacheQuantization: Int = 0,
        gpuFlashAttention: Boolean = true
    ): Long {
        check(isAvailable) { libraryLoadError ?: "原生引擎不可用" }
        val handle = nativeLoadModel(
            path,
            contextSize.coerceIn(512, 32768),
            threads.coerceIn(1, 16),
            gpuLayers.coerceIn(0, 64),
            kvCacheQuantization.coerceIn(0, 1),
            gpuFlashAttention
        )
        if (handle == 0L) {
            val nativeTail = lastNativeLogTail().takeLast(8000)
            val detail = if (nativeTail.isBlank()) "" else "\n最近 llama.cpp 原生日志：\n$nativeTail"
            throw IllegalStateException("llama.cpp 无法加载此 GGUF 模型；请检查模型兼容性、后端加载与可用内存。$detail")
        }
        return handle
    }

    fun generate(
        handle: Long,
        prompt: String,
        systemPrompt: String,
        maxTokens: Int,
        onToken: (String) -> Unit,
        draftHandle: Long = 0L
    ): String {
        nativeResetCancel(handle)
        if (draftHandle != 0L) nativeResetCancel(draftHandle)
        val listener = object : TokenListener {
            override fun onToken(token: String) = onToken.invoke(token)
        }
        val result = nativeGenerate(handle, prompt, systemPrompt, maxTokens.coerceIn(1, 8192), listener, draftHandle)
        if (result == GPU_RETRY_MARKER) {
            if (nativeRetryCpuOnly(handle)) {
                return nativeGenerate(handle, prompt, systemPrompt, maxTokens.coerceIn(1, 8192), listener, draftHandle)
            }
            return "GPU 预填充失败，且无法重新载入 CPU 模型；请降低上下文或选择更小模型。"
        }
        return result
    }

    fun cancel(handle: Long) {
        if (isAvailable && handle != 0L) runCatching { nativeCancel(handle) }
    }

    fun release(handle: Long) {
        if (isAvailable && handle != 0L) runCatching { nativeReleaseModel(handle) }
    }

    fun loadedModelReport(handle: Long): String = if (!isAvailable || handle == 0L) {
        "当前没有加载 llama.cpp 原生模型。"
    } else runCatching { nativeLoadedModelInfo(handle) }
        .getOrElse { "已请求查询当前模型状态，但原生信息读取失败：${it.message.orEmpty()}" }

    fun lastInferenceMetrics(handle: Long): String = if (!isAvailable || handle == 0L) {
        "原生推理指标不可用：当前没有加载模型。"
    } else runCatching { nativeLastInferenceMetrics(handle) }
        .getOrElse { "原生推理指标读取失败：${it.message.orEmpty()}" }

    private external fun nativeInitializeBackend(nativeLibraryDir: String)
    private external fun nativeEngineInfo(): String
    private external fun nativeLastLogTail(): String
    private external fun nativeClearLogTail()
    private external fun nativeLoadModel(
        path: String, contextSize: Int, threads: Int, gpuLayers: Int,
        kvCacheQuantization: Int, gpuFlashAttention: Boolean
    ): Long
    private external fun nativeGenerate(handle: Long, prompt: String, systemPrompt: String, maxTokens: Int, listener: TokenListener, draftHandle: Long): String
    private external fun nativeLastInferenceMetrics(handle: Long): String
    private external fun nativeRetryCpuOnly(handle: Long): Boolean
    private external fun nativeResetCancel(handle: Long)
    private external fun nativeCancel(handle: Long)
    private external fun nativeReleaseModel(handle: Long)
    private external fun nativeLoadedModelInfo(handle: Long): String
}
