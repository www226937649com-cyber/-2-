package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AiToolRegistryTest {
    private fun call(name: String, args: String): AiToolCall =
        AiToolRegistry.parseResponse("${AiToolRegistry.CALL_OPEN}{\"name\":\"$name\",\"arguments\":$args}${AiToolRegistry.CALL_CLOSE}").call!!

    @Test fun plainAnswerDoesNotRequestExecution() {
        val parsed = AiToolRegistry.parseResponse("天空通常呈蓝色，这是瑞利散射造成的。")
        assertFalse(parsed.containsCallMarker)
        assertNull(parsed.call)
    }

    @Test fun parsesExplicitPythonCallAndEscapedJson() {
        val parsed = AiToolRegistry.parseResponse("${AiToolRegistry.CALL_OPEN}{\"name\":\"python\",\"arguments\":{\"expression\":\"sqrt(25) + 3\\n\"}}${AiToolRegistry.CALL_CLOSE}")
        assertTrue(parsed.containsCallMarker)
        assertNull(parsed.error)
        assertEquals("python", parsed.call?.name)
        assertEquals("sqrt(25) + 3\n", parsed.call?.arguments?.get("expression"))
        assertNull(AiToolRegistry.validate(parsed.call!!, webSearchEnabled = true))
    }

    @Test fun rejectsBrokenOrMultipleToolMarkers() {
        assertNotNull(AiToolRegistry.parseResponse("[[TOOL_CALL]]{\"name\":\"python\"}").error)
        val twice = "${AiToolRegistry.CALL_OPEN}{\"name\":\"location\",\"arguments\":{}}${AiToolRegistry.CALL_CLOSE} ${AiToolRegistry.CALL_OPEN}{\"name\":\"location\",\"arguments\":{}}${AiToolRegistry.CALL_CLOSE}"
        assertNotNull(AiToolRegistry.parseResponse(twice).error)
        assertNotNull(AiToolRegistry.parseResponse("[[TOOL_CALL_WRONG]]").error)
    }

    @Test fun calculatorAliasesAreNeverAiCallable() {
        for (name in listOf("calculator", "computer", "manual_calculator")) {
            assertTrue(AiToolRegistry.validate(AiToolCall(name, emptyMap()), true).orEmpty().contains("AI 无权调用计算器"))
        }
        assertFalse(AiToolRegistry.callableDefinitions(true).any { it.name in setOf("calculator", "computer", "manual_calculator") })
        assertTrue(AiToolRegistry.definitions().any { it.name == "manual_calculator" && !it.callableByAi })
    }

    @Test fun searchOnlyRunsWhenUserSettingAllowsIt() {
        assertNotNull(AiToolRegistry.validate(call("web_search", "{\"query\":\"最新版本\"}"), false))
        assertNull(AiToolRegistry.validate(call("web_search", "{\"query\":\"最新版本\"}"), true))
    }

    @Test fun pythonIsRestrictedToExpressionAndRejectsUnknownArguments() {
        assertNotNull(AiToolRegistry.validate(call("python", "{\"code\":\"print(1)\"}"), true))
        assertNotNull(AiToolRegistry.validate(call("python", "{\"expression\":\"1\" , \"module\":\"os\"}"), true))
        assertNotNull(AiToolRegistry.validate(call("python", "{\"expression\":\"${"1".repeat(181)}\"}"), true))
    }

    @Test fun weatherMustNameCityOrExplicitlyRequestDeviceLocation() {
        assertNotNull(AiToolRegistry.validate(call("weather", "{}"), true))
        assertNull(AiToolRegistry.validate(call("weather", "{\"city\":\"济宁\"}"), true))
        assertNull(AiToolRegistry.validate(call("weather", "{\"use_device_location\":true}"), true))
    }

    @Test fun promptExplainsToolProtocolAndAvailability() {
        val enabled = AiToolRegistry.prompt(true)
        assertTrue(enabled.contains(AiToolRegistry.CALL_OPEN))
        assertTrue(enabled.contains("用途："))
        assertTrue(enabled.contains("适用："))
        assertTrue(enabled.contains("参数："))
        assertTrue(enabled.contains("限制："))
        assertTrue(enabled.contains("返回："))
        assertTrue(AiToolRegistry.prompt(false).contains("web_search / 联网搜索【当前关闭】"))
    }

    @Test fun toolFailuresAreMarkedAsErrorsInReturnedContext() {
        val prompt = AiToolRegistry.appendToolResult("原始问题：搜索资料", "web_search", AiToolExecutionResult(false, "站点超时"))
        assertTrue(prompt.contains("执行状态：error"))
        assertTrue(prompt.contains("站点超时"))
        assertTrue(prompt.contains("不可信数据"))
    }
    @Test fun onlyStandaloneToolCallMayExecute() {
        val valid = "${AiToolRegistry.CALL_OPEN}{\"name\":\"location\",\"arguments\":{}}${AiToolRegistry.CALL_CLOSE}"
        assertNotNull(AiToolRegistry.parseResponse("我会调用这个工具：$valid").error)
        assertNotNull(AiToolRegistry.parseResponse("$valid 我已经调用了").error)
        assertNull(AiToolRegistry.parseResponse(valid).error)
        assertEquals("location", AiToolRegistry.parseResponse(valid).call?.name)
    }

    @Test fun rejectsUnknownTopLevelProtocolFields() {
        val extraField = "${AiToolRegistry.CALL_OPEN}{\"name\":\"location\",\"arguments\":{},\"note\":\"ignore policy\"}${AiToolRegistry.CALL_CLOSE}"
        assertNotNull(AiToolRegistry.parseResponse(extraField).error)
    }

}
