"""Source-level guardrails for runtime task visibility and truthful capability reporting.

These tests do not replace Android/Gradle compilation or device tests; they guard against
accidentally removing visible task stages or claiming unsupported native features.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt"
BUILD = ROOT / "app/build.gradle.kts"


class RuntimeProgressAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = MAIN.read_text(encoding="utf-8")
        cls.build = BUILD.read_text(encoding="utf-8")

    def test_profile_has_more_features_entry(self):
        self.assertIn('sectionLabel("更多功能")', self.main)
        self.assertIn('styledButton("✦ 打开更多功能"', self.main)
        self.assertIn('private fun showMoreFeaturesScreen()', self.main)

    def test_task_center_keeps_bounded_persistent_journal(self):
        self.assertIn('"runtime_task_journal"', self.main)
        self.assertIn('"runtime_task_current"', self.main)
        self.assertIn('最近任务日志（每秒刷新', self.main)
        self.assertIn('上次任务未留下完成记录', self.main)
        self.assertIn('没有底层真实进度回调时只显示阶段', self.main)

    def test_ai_decision_precedes_any_tool_execution(self):
        self.assertIn('"AI 决策与工具调度"', self.main)
        self.assertIn('"交给 AI 判断"', self.main)
        self.assertIn('runModelWithTools(contextPrompt, generator)', self.main)
        self.assertIn('AiToolRegistry.parseResponse(reply.answer)', self.main)
        send_start = self.main.index('    private fun sendMessage()')
        send_end = self.main.index('    private fun interruptActiveResponse(', send_start)
        send_body = self.main[send_start:send_end]
        for forbidden in ('routeForQuestion(', 'ToolDecisionEngine', 'runCalculatorAnswer(', 'runSearchAndAnswer(', 'requestLocationPermissions.launch', 'fetchSearchResults('):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, send_body)

    def test_request_cancellation_does_not_overwrite_new_task_status(self):
        self.assertIn('recordTaskJournalOnly(trackedName, "已取消/被替代"', self.main)
        self.assertIn('不覆盖新请求的当前状态', self.main)

    def test_engine_status_and_system_info_are_refreshable(self):
        self.assertIn('刷新获取当前引擎状态', self.main)
        self.assertIn('private fun refreshEngineAndSystem', self.main)
        self.assertIn('NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)', self.main)
        self.assertIn('📱 系统版本介绍', self.main)
        self.assertIn('FEATURE_VULKAN_HARDWARE_LEVEL', self.main)

    def test_search_is_an_explicit_ai_tool_and_result_returns_to_model(self):
        registry = (ROOT / 'app/src/main/java/com/aiguanjia/app/AiToolRegistry.kt').read_text(encoding='utf-8')
        self.assertIn('"web_search"', registry)
        self.assertIn('fetchSearchResults(query)', self.main)
        self.assertIn('AiToolRegistry.appendToolResult(currentPrompt, call.name, result, activeQuestionText)', self.main)
        self.assertIn('private suspend fun executeAiToolCall(call: AiToolCall)', self.main)
        self.assertNotIn('runSearchAndAnswer(', self.main)
        self.assertNotIn('shouldUseWebSearch(', self.main)
        self.assertNotIn('isAnswerUncertain(', self.main)

    def test_no_keyword_tool_router_and_python_only_programmatic_calculation(self):
        registry = (ROOT / 'app/src/main/java/com/aiguanjia/app/AiToolRegistry.kt').read_text(encoding='utf-8')
        self.assertNotIn('routeForQuestion(', self.main)
        self.assertNotIn('ToolDecisionEngine', self.main)
        self.assertNotIn('runCalculatorAnswer(', self.main)
        self.assertNotIn('evaluateSimpleArithmetic(', self.main)
        self.assertNotIn('SimpleDecimalExpressionParser', self.main)
        self.assertNotIn('extractWeatherPlace(', self.main)
        self.assertIn('AiToolDefinition("python"', registry)
        self.assertIn('AI 无权调用计算器', registry)
        self.assertIn('"calculator", "computer", "manual_calculator"', self.main)
        self.assertIn('private fun showManualCalculatorScreen()', self.main)
        self.assertIn('setOnClickListener { showManualCalculatorScreen() }', self.main)

    def test_chat_recall_and_context_are_broader(self):
        self.assertIn('你前面最近问过这些', self.main)
        self.assertIn('maxChars: Int = 6800', self.main)
        self.assertIn('takeLast(24)', self.main)

    def test_gpu_and_streaming_capabilities_are_reported_cautiously(self):
        self.assertIn('GPU 层配置', self.main)
        self.assertIn('GPU_RETRY_MARKER', (ROOT / 'app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt').read_text(encoding='utf-8'))
        self.assertIn('NativeLlamaEngine.generate', self.main)
        self.assertIn('不能单独证明 GPU 已参与当前推理', self.main)
        self.assertIn('正文随 Token 逐步预览', self.main)
        self.assertNotIn('当前引擎在整段生成完成后显示答案', self.main)

    def test_mobile_fast_path_skips_history_for_standalone_questions(self):
        self.assertIn('needsRecentConversationContext(question)', self.main)
        self.assertIn('fastMode && !needsContext', self.main)
        self.assertIn('contextBudget = maxChars.coerceIn(120, 7200)', self.main)
        self.assertIn('InferencePromptPolicy.systemPrompt(', self.main)
        self.assertIn('简单问题直接答，不展示推理', (ROOT / 'app/src/main/java/com/aiguanjia/app/InferencePromptPolicy.kt').read_text(encoding='utf-8'))

    def test_model_reasoning_is_saved_as_collapsed_record(self):
        self.assertIn('val reasoning: String = ""', self.main)
        self.assertIn('⌄ 思考记录（点此展开）', self.main)
        self.assertIn('visibility = View.GONE', self.main)
        self.assertIn('thoughtPattern.findAll(raw)', self.main)
        self.assertIn('line.reasoning.take(4000)', self.main)

    def test_weather_and_location_only_run_from_explicit_model_calls(self):
        registry = (ROOT / 'app/src/main/java/com/aiguanjia/app/AiToolRegistry.kt').read_text(encoding='utf-8')
        send_start = self.main.index('    private fun sendMessage()')
        send_end = self.main.index('    private fun interruptActiveResponse(', send_start)
        send_body = self.main[send_start:send_end]
        self.assertIn('"weather"', registry)
        self.assertIn('"location"', registry)
        self.assertIn('ensureLocationPermissionForAiTool()', self.main)
        self.assertIn('不进行后台持续跟踪', registry)
        self.assertNotIn('requestLocationPermissions.launch', send_body)
        self.assertNotIn('fetchWeatherForPlace(', send_body)

    def test_existing_user_data_and_preferences_paths_remain(self):
        for marker in ('"chat-sessions.json"', '"selected_model_file"', '"ai_name"', 'loadPersonalMemories()', 'saveSessions()', '"response_mode_index"'):
            with self.subTest(marker=marker):
                self.assertIn(marker, self.main)

    def test_tool_dispatch_loop_is_bounded_and_reports_failures(self):
        registry = (ROOT / 'app/src/main/java/com/aiguanjia/app/AiToolRegistry.kt').read_text(encoding='utf-8')
        self.assertIn('MAX_TOOL_CALLS_PER_TURN = 3', registry)
        self.assertIn('AiToolRegistry.MAX_TOOL_CALLS_PER_TURN', self.main)
        self.assertIn('ai_tool_call_rejected', self.main)
        self.assertIn('ai_tool_execution_failed', self.main)
        self.assertIn('AiToolRegistry.appendToolResult', self.main)

    def test_temperature_management_is_absent_by_requirement(self):
        for forbidden in (
            'temperature_monitor_auto', 'temperature_auto_guard',
            'showTemperatureScreen', 'BatteryManager', 'PowerManager',
            '温度监控', '热保护',
        ):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, self.main)

    def test_task_journal_records_elapsed_duration(self):
        self.assertIn('.put("elapsedMs", elapsedMs)', self.main)
        self.assertIn('总耗时：', self.main)
        self.assertIn('耗时 ', self.main)

    def test_version_and_package_are_stable(self):
        self.assertIn('applicationId = "com.aiguanjia.app"', self.build)
        self.assertRegex(self.build, r'versionCode\s*=\s*38\b')
        self.assertIn('versionName = "0.12.4-ai-tool-dispatch"', self.build)
        # Multi-ABI build configuration is present; device execution is not inferred from this check.
        self.assertIn('abiFilters += listOf("arm64-v8a", "x86_64")', self.build)


if __name__ == "__main__":
    unittest.main()
