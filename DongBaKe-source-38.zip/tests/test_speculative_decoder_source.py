"""Source-level guards for optional speculative decoding and truthful NPU/APU status."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt"
BRIDGE = ROOT / "app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt"
NATIVE = ROOT / "app/src/main/cpp/dongbake_llama_jni.cpp"
BUILD = ROOT / "app/build.gradle.kts"
DOC = ROOT / "docs/source-30-feature-audit.md"

class SpeculativeDecodeAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = MAIN.read_text(encoding="utf-8")
        cls.bridge = BRIDGE.read_text(encoding="utf-8")
        cls.native = NATIVE.read_text(encoding="utf-8")
        cls.build = BUILD.read_text(encoding="utf-8")
        cls.doc = DOC.read_text(encoding="utf-8")

    def test_speculation_is_explicit_opt_in_and_off_by_default(self):
        self.assertIn('putString("inference_draft_model_filename", draftName)', self.main)
        self.assertIn('listOf("") + draftFiles.map { it.name }', self.main)
        self.assertIn('draftHandle: Long = 0L', self.bridge)
        self.assertIn('if (draft_handle != 0)', self.native)

    def test_vocab_is_checked_and_mismatch_is_not_silently_accepted(self):
        self.assertIn('compatible_speculative_vocab', self.native)
        self.assertIn('llama_vocab_get_text', self.native)
        self.assertIn('推测解码未启动', self.native)

    def test_verification_rolls_back_unaccepted_cache_suffix(self):
        self.assertIn('decode_speculative_batch', self.native)
        self.assertIn('llama_memory_seq_rm', self.native)
        self.assertIn('mismatch_index', self.native)

    def test_draft_is_cpu_f16_and_normal_path_remains_optional(self):
        self.assertIn('gpuLayers = 0, kvCacheQuantization = 0, gpuFlashAttention = false', self.main)
        self.assertIn('nativeGenerate(handle, prompt, systemPrompt, maxTokens.coerceIn(1, 8192), listener, draftHandle)', self.bridge)

    def test_npu_apu_is_not_falsely_claimed(self):
        self.assertIn('尚不能通用接入', self.main)
        self.assertIn('厂商 SDK', self.doc)

    def test_version_increments(self):
        self.assertIn('versionCode = 38', self.build)
        self.assertIn('versionName = "0.12.4-ai-tool-dispatch"', self.build)

if __name__ == "__main__":
    unittest.main()
