package com.aiguanjia.app

/** Compact, model-agnostic control prompts. Persona memories and retrieved material belong in the user prompt. */
internal object InferencePromptPolicy {
    fun systemPrompt(modeIndex: Int, simpleQuestion: Boolean, webResearch: Boolean, supportsReasoning: Boolean, assistantName: String = "中文伙伴", softThinkingTokens: Int = 384): String {
        val safeAssistantName = assistantName.filterNot { it.isISOControl() }.trim().take(16).ifBlank { "中文伙伴" }
        val mode = modeIndex.coerceIn(0, 2)
        val base = when {
            mode == 0 || simpleQuestion ->
                "你是$safeAssistantName。用简体中文准确简洁地回答；简单问题直接答，不展示推理；不确定就说明，不编造。"
            mode == 1 ->
                "你是$safeAssistantName。简体中文先结论后理由；思考约${softThinkingTokens} tokens内，有结论立即回答，不反复验证；不确定就说明。"
            else ->
                "你是$safeAssistantName。简体中文分析复杂问题，思考约${softThinkingTokens} tokens内；有结论立即回答，不反复验证，不编造。"
        }
        // Do not inject model-specific control tokens into templates that do not advertise support.
        val control = if (!supportsReasoning) "" else when {
            mode == 0 || simpleQuestion -> "\n/no_think"
            else -> "\n/think"
        }
        val researchPrefix = if (webResearch) "先直接回答原问题，再给必要来源；" else ""
        // Keep this prompt short on purpose; old personality/preferences remain in the existing profile store.
        return researchPrefix + base + control
    }
}
