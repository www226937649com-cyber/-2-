package com.aiguanjia.app

import android.content.Context
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.Locale
import kotlin.math.sqrt

internal data class ToolRouteDecision(
    val toolNames: Set<String>,
    val fallback: Boolean,
    val elapsedMs: Long,
    val reason: String,
    val scores: String
)

/**
 * Optional, fully local BGE-small-zh-v1.5 router. The model is user-imported to app-private
 * storage; missing/invalid assets always fail open to the full authorized tool list.
 * It only picks descriptions shown to the model. It never executes a tool.
 */
internal object LocalEmbeddingRouter {
    private const val MODEL_FILE = "model.onnx"
    private const val VOCAB_FILE = "vocab.txt"
    private const val QUERY_PREFIX = "为这个句子生成表示以用于检索相关文章："
    private const val MAX_TOKENS = 64

    private var loadedModelPath: String? = null
    private var loadedVocabModified: Long = -1L
    private var session: OrtSession? = null
    private var environment: OrtEnvironment? = null
    private var vocabulary: Map<String, Int> = emptyMap()
    private val toolVectorCache = mutableMapOf<String, FloatArray>()

    fun modelDirectory(context: Context): File = File(context.filesDir, "models/embedding")
    fun modelFile(context: Context): File = File(modelDirectory(context), MODEL_FILE)
    fun vocabFile(context: Context): File = File(modelDirectory(context), VOCAB_FILE)
    fun isReady(context: Context): Boolean = modelFile(context).isFile && modelFile(context).length() > 1024 && vocabFile(context).isFile && vocabFile(context).length() > 1024

    @Synchronized
    fun reset() {
        runCatching { session?.close() }
        session = null
        environment = null
        vocabulary = emptyMap()
        toolVectorCache.clear()
        loadedModelPath = null
        loadedVocabModified = -1L
    }

    @Synchronized
    private fun ensureLoaded(context: Context) {
        val model = modelFile(context)
        val vocab = vocabFile(context)
        require(model.isFile && model.length() > 1024) { "缺少本地 Embedding ONNX 模型文件 model.onnx" }
        require(vocab.isFile && vocab.length() > 1024) { "缺少本地 Embedding 词表 vocab.txt" }
        if (session != null && loadedModelPath == model.absolutePath && loadedVocabModified == vocab.lastModified()) return
        reset()
        val tokens = vocab.readLines(Charsets.UTF_8)
        require(tokens.size > 1000) { "Embedding 词表文件不完整：${tokens.size} 行" }
        vocabulary = tokens.withIndex().associate { it.value to it.index }
        val options = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(2)
            setInterOpNumThreads(1)
        }
        try {
            environment = OrtEnvironment.getEnvironment()
            session = environment!!.createSession(model.absolutePath, options)
        } finally {
            options.close()
        }
        loadedModelPath = model.absolutePath
        loadedVocabModified = vocab.lastModified()
    }

    fun route(context: Context, question: String, definitions: List<AiToolDefinition>): ToolRouteDecision {
        val started = System.nanoTime()
        fun fallback(reason: String, scores: String = "unavailable") = ToolRouteDecision(
            definitions.filter { it.callableByAi }.map { it.name }.toSet(), true,
            (System.nanoTime() - started) / 1_000_000L, reason, scores
        )
        if (question.isBlank()) return fallback("blank_question")
        if (!isReady(context)) return fallback("embedding_assets_missing")
        return try {
            val engine: OrtSession
            val env: OrtEnvironment
            val vocab: Map<String, Int>
            synchronized(this) {
                ensureLoaded(context)
                engine = session!!
                env = environment!!
                vocab = vocabulary
            }
            val queryVector = synchronized(this) { embed(env, engine, vocab, QUERY_PREFIX + question.take(600)) }
            val scored = definitions.filter { it.callableByAi }.map { def ->
                val description = "${def.displayName}。${def.purpose}适用场景：${def.whenToUse}。参数：${def.arguments}。".take(600)
                val cacheKey = "${def.name}:$description"
                val toolVector = synchronized(this) {
                    toolVectorCache[cacheKey] ?: embed(env, engine, vocab, description).also { vector ->
                        toolVectorCache[cacheKey] = vector
                    }
                }
                def.name to cosine(queryVector, toolVector)
            }.sortedByDescending { it.second }
            val scoreText = scored.joinToString(",") { "${it.first}=${"%.3f".format(Locale.US, it.second)}" }
            val best = scored.firstOrNull()?.second ?: return fallback("no_callable_tools")
            // Thresholds are intentionally conservative until measured against a labeled on-device set.
            // Ambiguous/low-confidence results expose all authorized tools instead of hiding one.
            if (best < 0.30f) return fallback("low_confidence", scoreText)
            val selected = scored.filter { it.second >= maxOf(0.28f, best - 0.09f) }.take(4).map { it.first }.toSet()
            if (selected.isEmpty()) fallback("empty_candidate_set", scoreText)
            else ToolRouteDecision(selected, false, (System.nanoTime() - started) / 1_000_000L, "embedding_candidates", scoreText)
        } catch (e: Throwable) {
            fallback("embedding_error_${e.javaClass.simpleName}")
        }
    }

    private fun embed(env: OrtEnvironment, session: OrtSession, vocab: Map<String, Int>, text: String): FloatArray {
        val ids = tokenize(text, vocab).take(MAX_TOKENS - 2).toMutableList()
        ids.add(0, vocab["[CLS]"] ?: 101)
        ids.add(vocab["[SEP]"] ?: 102)
        val size = ids.size
        val inputIds = ids.map { it.toLong() }.toLongArray()
        val masks = LongArray(size) { 1L }
        val inputs = linkedMapOf<String, OnnxTensor>()
        try {
            inputs["input_ids"] = OnnxTensor.createTensor(env, LongBuffer.wrap(inputIds), longArrayOf(1L, size.toLong()))
            inputs["attention_mask"] = OnnxTensor.createTensor(env, LongBuffer.wrap(masks), longArrayOf(1L, size.toLong()))
            if (session.inputNames.contains("token_type_ids")) {
                inputs["token_type_ids"] = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(size)), longArrayOf(1L, size.toLong()))
            }
            session.run(inputs).use { result ->
                val raw = result[0].value
                // Support common exported formats: token embeddings [1, sequence, dim] and
                // sentence embeddings [1, dim]. Any other output shape fails open at the router.
                val outer = raw as? Array<*> ?: error("ONNX 输出必须具有 batch 维度")
                val first = outer.firstOrNull() ?: error("ONNX 输出为空")
                val vector = when (first) {
                    // Sentence-embedding exports sometimes already return [batch, dimension].
                    is FloatArray -> first
                    // Token-embedding exports return [batch, sequence, dimension]. Pool valid
                    // content tokens and exclude [CLS]/[SEP] rather than assuming CLS pooling.
                    is Array<*> -> {
                        val tokenVectors = first.map { it as? FloatArray
                            ?: error("ONNX 序列输出包含不受支持的向量类型") }
                        meanPoolAndNormalize(tokenVectors, masks, excludeSpecialTokens = true)
                    }
                    else -> error("ONNX 输出向量格式不受支持")
                }
                if (first is FloatArray) return normalize(vector)
                return vector
            }
        } finally {
            inputs.values.forEach { runCatching { it.close() } }
        }
    }

    internal fun meanPoolAndNormalize(
        tokenEmbeddings: List<FloatArray>,
        attentionMask: LongArray,
        excludeSpecialTokens: Boolean
    ): FloatArray {
        require(tokenEmbeddings.isNotEmpty()) { "Embedding token 序列为空" }
        require(tokenEmbeddings.size == attentionMask.size) { "Embedding 序列与 attention mask 长度不一致" }
        val dimension = tokenEmbeddings.first().size
        require(dimension > 0 && tokenEmbeddings.all { it.size == dimension }) { "Embedding 向量维度不一致" }
        val from = if (excludeSpecialTokens && tokenEmbeddings.size > 2) 1 else 0
        val until = if (excludeSpecialTokens && tokenEmbeddings.size > 2) tokenEmbeddings.size - 1 else tokenEmbeddings.size
        val valid = (from until until).filter { attentionMask[it] != 0L }
        require(valid.isNotEmpty()) { "Embedding 没有有效内容 token" }
        val pooled = FloatArray(dimension)
        for (idx in valid) {
            val row = tokenEmbeddings[idx]
            for (d in 0 until dimension) pooled[d] += row[d]
        }
        for (d in pooled.indices) pooled[d] /= valid.size.toFloat()
        return normalize(pooled)
    }

    private fun normalize(vector: FloatArray): FloatArray {
        val norm = sqrt(vector.sumOf { it.toDouble() * it.toDouble() }).toFloat()
        require(norm > 1e-12f && norm.isFinite()) { "Embedding 向量范数无效" }
        return FloatArray(vector.size) { vector[it] / norm }
    }

    private fun tokenize(text: String, vocab: Map<String, Int>): List<Int> {
        val normalized = Normalizer.normalize(text.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .filterNot { Character.getType(it) == Character.NON_SPACING_MARK.toInt() }
        val basic = mutableListOf<String>()
        val word = StringBuilder()
        fun flush() { if (word.isNotEmpty()) { basic += word.toString(); word.setLength(0) } }
        normalized.codePoints().forEach { cp ->
            val ch = String(Character.toChars(cp))
            val type = Character.getType(cp)
            when {
                Character.isWhitespace(cp) -> flush()
                isCjk(cp) || type in setOf(Character.CONNECTOR_PUNCTUATION.toInt(), Character.DASH_PUNCTUATION.toInt(), Character.START_PUNCTUATION.toInt(), Character.END_PUNCTUATION.toInt(), Character.OTHER_PUNCTUATION.toInt(), Character.MATH_SYMBOL.toInt(), Character.CURRENCY_SYMBOL.toInt()) -> {
                    flush(); basic += ch
                }
                else -> word.append(ch)
            }
        }
        flush()
        val out = mutableListOf<Int>()
        for (token in basic) {
            if (vocab.containsKey(token)) { out += vocab[token]!!; continue }
            if (token.codePointCount(0, token.length) > 100) { out += (vocab["[UNK]"] ?: 100); continue }
            var start = 0
            val pieces = mutableListOf<Int>()
            var failed = false
            while (start < token.length) {
                var end = token.length
                var found: Int? = null
                while (end > start) {
                    val piece = (if (start == 0) "" else "##") + token.substring(start, end)
                    val id = vocab[piece]
                    if (id != null) { found = id; break }
                    end--
                }
                if (found == null) { failed = true; break }
                pieces += found
                start = end
            }
            if (failed) out += (vocab["[UNK]"] ?: 100) else out += pieces
            if (out.size >= MAX_TOKENS - 2) break
        }
        return out
    }

    private fun isCjk(cp: Int): Boolean = cp in 0x4E00..0x9FFF || cp in 0x3400..0x4DBF || cp in 0x20000..0x2A6DF

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return -1f
        return a.indices.sumOf { a[it].toDouble() * b[it].toDouble() }.toFloat()
    }
}
