package com.aiguanjia.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.app.AlertDialog
import android.content.Intent
import android.provider.Settings
import android.provider.OpenableColumns
import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.app.ActivityManager
import android.os.Debug
import android.os.CancellationSignal
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.text.Editable
import android.text.TextWatcher
import android.text.method.LinkMovementMethod
import android.text.util.Linkify
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.SeekBar
import android.widget.ProgressBar
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.jsoup.Connection
import org.jsoup.Jsoup
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import java.net.HttpURLConnection
import java.net.URL
import java.util.function.Consumer
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

private data class ModelReply(val answer: String, val reasoning: String = "")
private enum class ResponseEffort { INSTANT, SIMPLE, NORMAL, COMPLEX, VERY_COMPLEX }
private data class WebResult(val title: String, val url: String, val snippet: String)
private data class ChatLine(val who: String, val message: String, val isUser: Boolean = false, val reasoning: String = "")
private data class ChatSession(val id: String, var title: String, val createdAt: Long, val messages: MutableList<ChatLine> = mutableListOf())

/** 拖动、缩放的正方形头像裁剪预览；输出仅包含裁剪后的方形区域。 */
private class AvatarCropView(context: android.content.Context, private val bitmap: Bitmap) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private var zoom = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    fun setZoom(value: Float) {
        zoom = value.coerceIn(1f, 3f)
        clampOffsets()
        invalidate()
    }

    fun resetCrop() {
        zoom = 1f
        offsetX = 0f
        offsetY = 0f
        invalidate()
    }

    private fun cropSquare(): RectF {
        val size = minOf(width.toFloat(), height.toFloat()).coerceAtLeast(1f)
        val left = (width - size) / 2f
        val top = (height - size) / 2f
        return RectF(left, top, left + size, top + size)
    }

    private fun currentScale(square: RectF): Float = maxOf(square.width() / bitmap.width, square.height() / bitmap.height) * zoom

    private fun clampOffsets() {
        val size = minOf(width.toFloat(), height.toFloat()).coerceAtLeast(1f)
        val scale = maxOf(size / bitmap.width, size / bitmap.height) * zoom
        offsetX = offsetX.coerceIn(-maxOf(0f, (bitmap.width * scale - size) / 2f), maxOf(0f, (bitmap.width * scale - size) / 2f))
        offsetY = offsetY.coerceIn(-maxOf(0f, (bitmap.height * scale - size) / 2f), maxOf(0f, (bitmap.height * scale - size) / 2f))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(17, 24, 39))
        val square = cropSquare()
        val scale = currentScale(square)
        val centerX = square.centerX() + offsetX
        val centerY = square.centerY() + offsetY
        val destination = RectF(centerX - bitmap.width * scale / 2f, centerY - bitmap.height * scale / 2f,
            centerX + bitmap.width * scale / 2f, centerY + bitmap.height * scale / 2f)
        val save = canvas.save()
        canvas.clipRect(square)
        canvas.drawBitmap(bitmap, null, destination, paint)
        canvas.restoreToCount(save)
        canvas.drawRect(square, framePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                offsetX += event.x - lastX
                offsetY += event.y - lastY
                lastX = event.x
                lastY = event.y
                clampOffsets()
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun makeCroppedBitmap(outputSize: Int): Bitmap {
        val square = cropSquare()
        val scale = currentScale(square)
        val sourceSide = (square.width() / scale).coerceAtMost(minOf(bitmap.width, bitmap.height).toFloat())
        var left = bitmap.width / 2f - offsetX / scale - sourceSide / 2f
        var top = bitmap.height / 2f - offsetY / scale - sourceSide / 2f
        left = left.coerceIn(0f, bitmap.width - sourceSide)
        top = top.coerceIn(0f, bitmap.height - sourceSide)
        val l = left.toInt().coerceIn(0, bitmap.width - 1)
        val t = top.toInt().coerceIn(0, bitmap.height - 1)
        val side = sourceSide.toInt().coerceAtLeast(1).coerceAtMost(minOf(bitmap.width - l, bitmap.height - t))
        val cropped = Bitmap.createBitmap(bitmap, l, t, side, side)
        return if (cropped.width == outputSize && cropped.height == outputSize) cropped
        else Bitmap.createScaledBitmap(cropped, outputSize, outputSize, true).also { if (it !== cropped) cropped.recycle() }
    }
}


class MainActivity : ComponentActivity() {
    private lateinit var statusText: TextView
    private lateinit var thinkingText: TextView
    private lateinit var promptInput: EditText
    private lateinit var sendButton: Button
    private lateinit var searchButton: Button
    private lateinit var toolsButton: Button
    private lateinit var loadButton: Button
    private lateinit var ejectButton: Button
    private lateinit var refreshButton: Button
    private lateinit var modeButton: Button
    private lateinit var voiceButton: Button
    private lateinit var voiceSettingsButton: Button
    private lateinit var chatScroll: ScrollView
    private lateinit var chatMessages: LinearLayout

    private val preferences by lazy { getSharedPreferences("ai_guan_jia_settings", MODE_PRIVATE) }
    private val userAvatarFile: File by lazy { File(filesDir, "user-avatar.jpg") }
    private val aiAvatarFile: File by lazy { File(filesDir, "ai-avatar.jpg") }
    private val sessionsFile: File by lazy { File(filesDir, "chat-sessions.json") }
    private val modelDirectory: File by lazy { getExternalFilesDir("models") ?: filesDir }
    private val modelFile: File
        get() {
            val storedName = preferences.getString("selected_model_file", "assistant-model.gguf").orEmpty()
            val safeName = File(storedName).name.ifBlank { "assistant-model.gguf" }
            return File(modelDirectory, safeName)
        }
    private var loadedModelFileName: String? = null
    @Volatile private var nativeModelHandle: Long = 0L
    @Volatile private var nativeDraftModelHandle: Long = 0L
    @Volatile private var loadedModelContextSize: Int? = null

    private var fastMode = true
    private var responseModeIndex = 0
    private var loadedModelProfile: ModelProfile? = null
    private var activeQuestionText: String = ""
    private var voiceEnabled = false
    private var webSearchEnabled = false
    private var speechReady = false
    private var speechVolume = 1.0f
    private var speechEngine: TextToSpeech? = null
    private var offlineChineseVoices: List<Voice> = emptyList()
    private var activeSpeechId: String? = null
    private var activeSpeechButton: Button? = null
    private var processingMessage: String? = null
    private var processingRow: View? = null
    private var processingBodyView: TextView? = null
    private var processingHeaderView: TextView? = null
    private var processingProgressBar: ProgressBar? = null
    private var processingProgressPercent: Int? = null
    private var modelLoadTicker: Job? = null
    private var processingExpanded = true
    private var historySelectMode = false
    private val selectedSessionIds = mutableSetOf<String>()
    private var isBusy = false
    private var isModelTransferOrLoading = false
    private var activeQuestionJob: Job? = null
    private var activeRequestId: Long = 0L
    private var pendingToolLocationPermission: CompletableDeferred<Boolean>? = null
    private val modelInferenceMutex = Mutex()
    @Volatile private var modelInferenceActive = false
    private var isProfileScreen = false
    private var isPersonalizationScreen = false
    private var isMoreFeaturesScreen = false
    private val taskJournalLock = Any()
    private var taskCenterTicker: Job? = null
    @Volatile private var taskCenterStatusView: TextView? = null
    @Volatile private var taskCenterProgressBar: ProgressBar? = null
    @Volatile private var taskCenterJournalView: TextView? = null
    private var generateReply: (suspend (String, Boolean) -> ModelReply)? = null
    private var releaseModel: (suspend () -> Unit)? = null
    private val history = mutableListOf<Pair<String, String>>()
    private var transcript = mutableListOf<ChatLine>()
    private val sessions = mutableListOf<ChatSession>()
    private var currentSessionId: String = ""
    private var userAvatarBitmapCache: Bitmap? = null
    private var aiAvatarBitmapCache: Bitmap? = null

    private val chooseModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importModel(uri)
    }

    private val chooseEmbeddingOnnx = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importEmbeddingAsset(uri, "model.onnx")
    }
    private val chooseEmbeddingVocab = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importEmbeddingAsset(uri, "vocab.txt")
    }

    private fun importEmbeddingAsset(uri: Uri, filename: String) {
        lifecycleScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                runCatching {
                    val maxBytes = if (filename.endsWith(".onnx")) 300L * 1024L * 1024L else 2L * 1024L * 1024L
                    val targetDir = LocalEmbeddingRouter.modelDirectory(this@MainActivity)
                    targetDir.mkdirs()
                    val target = File(targetDir, filename)
                    val temporary = File(targetDir, "$filename.importing")
                    temporary.delete()
                    try {
                        val input = contentResolver.openInputStream(uri) ?: error("无法读取所选文件")
                        input.use { source ->
                            temporary.outputStream().use { sink ->
                                val buffer = ByteArray(64 * 1024)
                                var total = 0L
                                while (true) {
                                    val count = source.read(buffer)
                                    if (count < 0) break
                                    total += count
                                    require(total <= maxBytes) { "文件超过允许大小上限" }
                                    sink.write(buffer, 0, count)
                                }
                            }
                        }
                        require(temporary.length() > 1024L) { "文件太小，可能不是有效的模型文件" }
                        LocalEmbeddingRouter.reset()
                        // Same-directory rename replaces the previous asset atomically on Android;
                        // if it fails, the prior file remains available instead of being deleted first.
                        android.system.Os.rename(temporary.absolutePath, target.absolutePath)
                        target.length()
                    } finally {
                        temporary.delete()
                    }
                }
            }
            if (outcome.isSuccess) {
                val bytes = outcome.getOrThrow()
                AppDiagnostics.log(this@MainActivity, "INFO", "embedding_asset_imported", "asset=$filename; bytes=$bytes; route_ready=${LocalEmbeddingRouter.isReady(this@MainActivity)}")
                Toast.makeText(this@MainActivity, if (LocalEmbeddingRouter.isReady(this@MainActivity)) "Embedding 路由模型与词表已就绪" else "文件已导入；还需要导入另一个文件", Toast.LENGTH_LONG).show()
            } else {
                AppDiagnostics.logThrowable(this@MainActivity, "WARN", "embedding_asset_import_failed", "asset=$filename", outcome.exceptionOrNull() ?: RuntimeException("unknown"))
                Toast.makeText(this@MainActivity, "Embedding 文件导入失败：${outcome.exceptionOrNull()?.message ?: "未知错误"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val exportDiagnosticsLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        if (uri != null) {
            val result = runCatching {
                val output = contentResolver.openOutputStream(uri) ?: error("无法打开导出目标")
                output.bufferedWriter(Charsets.UTF_8).use { it.write(buildFullDiagnosticsReport()) }
            }
            if (result.isSuccess) {
                AppDiagnostics.log(this, "INFO", "logs_exported", "User exported diagnostics.")
                Toast.makeText(this, "日志已导出。", Toast.LENGTH_LONG).show()
            } else {
                AppDiagnostics.logThrowable(this, "ERROR", "logs_export_failed", "Export failed.", result.exceptionOrNull() ?: RuntimeException("unknown export error"))
                Toast.makeText(this, "导出失败：${result.exceptionOrNull()?.message ?: "未知错误"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // 用户可在系统照片选择器与原有系统文件选择器之间自行选择。
    private val chooseUserAvatar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) showAvatarCrop(uri, forAi = false)
    }
    private val chooseAiAvatar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) showAvatarCrop(uri, forAi = true)
    }
    private val chooseUserAvatarFromGallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) showAvatarCrop(uri, forAi = false)
    }
    private val chooseAiAvatarFromGallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) showAvatarCrop(uri, forAi = true)
    }

    private val requestLocationPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        // A location permission prompt can only be opened after the model explicitly requested a tool.
        val toolPermission = pendingToolLocationPermission
        if (toolPermission != null) {
            pendingToolLocationPermission = null
            toolPermission.complete(grants.values.any { it })
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            LocalEmbeddingRouter.reset()
            val handle = nativeModelHandle
            if (handle != 0L) {
                AppDiagnostics.log(this, "WARN", "prefix_cache_memory_pressure", "level=$level; action=release_persistent_context_and_embedding_session_keep_model_weights")
                lifecycleScope.launch(Dispatchers.IO) { NativeLlamaEngine.releaseInferenceContext(handle) }
            } else {
                AppDiagnostics.log(this, "WARN", "prefix_cache_memory_pressure", "level=$level; action=release_embedding_session")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppDiagnostics.initialize(this)
        NativeLlamaEngine.setVerboseLogging(preferences.getBoolean("runtime_logging_enabled", true))
        AppDiagnostics.log(this, "INFO", "activity_onCreate", "MainActivity created; ${AppDiagnostics.memorySnapshot(this)}")
        responseModeIndex = preferences.getInt("response_mode_index", if (preferences.getBoolean("fast_mode", true)) 0 else 2).coerceIn(0, 2)
        fastMode = responseModeIndex == 0
        voiceEnabled = preferences.getBoolean("voice_enabled", false)
        speechVolume = preferences.getFloat("speech_volume", 1.0f).coerceIn(0f, 1f)
        // Smart search is enabled on first run; the user can still explicitly turn it off.
        webSearchEnabled = preferences.getBoolean("web_search_enabled", true)
        recoverInterruptedTask()
        ensureModelSelection()
        loadSavedSessions()
        val previousConversation = sessions.lastOrNull { session -> session.messages.any { it.isUser } }
        if (previousConversation != null) {
            AppDiagnostics.log(this, "INFO", "conversation_restore_begin", "sessionId=${previousConversation.id}; messages=${previousConversation.messages.size}")
            openConversation(previousConversation.id)
            AppDiagnostics.log(this, "INFO", "conversation_restore_complete", "sessionId=${previousConversation.id}; transcriptMessages=${transcript.size}; historyPairs=${history.size}")
        } else {
            createNewConversation(showWelcome = false)
            AppDiagnostics.log(this, "INFO", "conversation_restore_empty", "no_saved_user_conversation=true; createdFreshConversation=true")
        }
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        buildInterface()
        initialiseSpeech()
        if (modelFile.exists() && modelFile.length() > 0L) {
            if (preferences.getBoolean("model_auto_load", false)) {
                val restoreName = modelFile.name
                statusText.text = "已找到上次使用的模型「${modelDisplayName(modelFile)}」（${formatBytes(modelFile.length())}），正在准备自动恢复。"
                AppDiagnostics.log(this, "INFO", "model_restore_scheduled", "file=$restoreName; delayMs=1200; lowMemoryGate=true")
                window.decorView.postDelayed({
                    if (isFinishing || isDestroyed) return@postDelayed
                    val selectedFile = modelFile
                    if (!selectedFile.isFile || selectedFile.length() <= 0L || selectedFile.name != restoreName) {
                        statusText.text = "自动恢复已取消：所选模型已变化或文件不可用，请手动检查模型。"
                        AppDiagnostics.log(this, "WARN", "model_restore_cancelled", "reason=selected_model_changed_or_missing; startupFile=$restoreName")
                        return@postDelayed
                    }
                    val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
                    val memoryInfo = ActivityManager.MemoryInfo()
                    runCatching { manager?.getMemoryInfo(memoryInfo) }
                    if (memoryInfo.lowMemory) {
                        statusText.text = "已保存上次模型，但系统当前提示低内存；为避免启动闪退，暂不自动恢复。释放内存后可以手动点击“加载模型”。"
                        AppDiagnostics.log(this, "WARN", "model_restore_deferred_low_memory", "file=$restoreName; availableBytes=${memoryInfo.availMem}; totalBytes=${memoryInfo.totalMem}")
                        return@postDelayed
                    }
                    AppDiagnostics.log(this, "INFO", "model_restore_auto_begin", "file=$restoreName; bytes=${selectedFile.length()}; availableBytes=${memoryInfo.availMem}; lowMemory=false")
                    loadLocalModel(autoTriggered = true)
                }, 1200L)
            } else {
                statusText.text = "发现本地模型「${modelDisplayName(modelFile)}」（${formatBytes(modelFile.length())}），这是首次加载或尚未启用自动恢复，请点击“加载模型”。"
                AppDiagnostics.log(this, "INFO", "model_restore_manual_first_load", "file=${modelFile.name}; autoLoadPreference=false")
            }
        } else {
            statusText.text = "尚未加载模型：请先选择并加载一个 GGUF 文件，再发送消息。"
            AppDiagnostics.log(this, "INFO", "startup_no_model", "No selected model file.")
        }
    }

    private fun buildInterface() {
        isProfileScreen = false
        isPersonalizationScreen = false
        isMoreFeaturesScreen = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(C_BG)
        }
        setContentView(root)
        processingRow = null
        processingBodyView = null
        processingHeaderView = null
        processingProgressBar = null
        processingProgressPercent = null

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(10), dp(10))
            background = roundedGradient(C_PANEL, C_PANEL_2, 22, C_STROKE)
        }
        val avatar = createAvatarView(aiAvatar = true, sizeDp = 48)
        avatar.setOnClickListener { showProfileScreen() }
        header.addView(avatar, LinearLayout.LayoutParams(dp(48), dp(48)))
        val headingBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
        }
        headingBox.addView(TextView(this).apply {
            text = preferences.getString("ai_name", "pls").orEmpty().ifBlank { "pls" }
            textSize = 20f
            setTextColor(C_TEXT)
            setTypeface(null, Typeface.BOLD)
        })
        headingBox.addView(TextView(this).apply {
            text = "你的专属智能伙伴 · 随时为你服务"
            textSize = 11f
            setTextColor(C_MUTED)
            setPadding(0, dp(3), 0, 0)
        })
        header.addView(headingBox, LinearLayout.LayoutParams(0, -2, 1f))
        toolsButton = styledButton("🧰 总调度", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
            contentDescription = "打开总调度工具目录"
            setOnClickListener { showToolHubScreen() }
        }
        header.addView(toolsButton, LinearLayout.LayoutParams(dp(88), dp(42)).apply { marginStart = dp(4) })
        root.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        val sessionActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sessionActions.addView(styledButton("＋ 新话题", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
            setOnClickListener { createNewConversation() }
        }, LinearLayout.LayoutParams(0, dp(36), 1f))
        sessionActions.addView(styledButton("▤ 历史话题", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { showConversationList() }
        }, LinearLayout.LayoutParams(0, dp(36), 1.15f).apply { marginStart = dp(6) })
        sessionActions.addView(styledButton("☺ 个人", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { showProfileScreen() }
        }, LinearLayout.LayoutParams(0, dp(36), 0.82f).apply { marginStart = dp(6) })
        root.addView(sessionActions, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })

        statusText = TextView(this).apply {
            textSize = 12f
            setTextColor(C_MUTED)
            background = rounded(C_PANEL, 13, C_STROKE_SOFT)
            setPadding(dp(11), dp(8), dp(11), dp(8))
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })

        val modelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val pickButton = styledButton("📁 选择模型", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener { chooseModel.launch(arrayOf("*/*")) }
        }
        modelRow.addView(pickButton, LinearLayout.LayoutParams(0, dp(40), 1f))
        loadButton = styledButton("✨ 加载模型", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
            setOnClickListener { loadLocalModel() }
        }
        modelRow.addView(loadButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(7) })
        ejectButton = styledButton("⏏ 退出模型", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { unloadLocalModel() }
        }
        modelRow.addView(ejectButton, LinearLayout.LayoutParams(0, dp(40), 0.95f).apply { marginStart = dp(7) })
        root.addView(modelRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })

        val chatCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(8), dp(9), dp(7))
            background = rounded(C_PANEL, 22, C_STROKE_SOFT)
        }
        root.addView(chatCard, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = dp(8) })

        val chatTitleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(2), dp(3), dp(7))
        }
        chatTitleRow.addView(TextView(this).apply {
            text = "💬  聊天室"
            textSize = 14.5f
            setTextColor(C_TEXT)
            setTypeface(null, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        chatTitleRow.addView(TextView(this).apply {
            text = "● 在线"
            textSize = 11f
            setTextColor(C_MINT)
        })
        refreshButton = styledButton("↻ 刷新", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { refreshChatAndRepair() }
        }
        chatTitleRow.addView(refreshButton, LinearLayout.LayoutParams(dp(78), dp(32)).apply { marginStart = dp(5) })
        chatCard.addView(chatTitleRow)

        thinkingText = TextView(this).apply {
            textSize = 12f
            setTextColor(C_MINT)
            background = rounded(C_PANEL_2, 13, C_STROKE)
            setPadding(dp(11), dp(8), dp(11), dp(8))
            visibility = View.GONE
        }
        // Processing feedback is rendered as a collapsible assistant bubble inside the conversation.
        thinkingText.visibility = View.GONE

        chatScroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(1), dp(1), dp(1), dp(3))
        }
        chatMessages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(1), dp(1), dp(1), dp(4))
        }
        chatScroll.addView(chatMessages, FrameLayout.LayoutParams(-1, -2))
        chatCard.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (transcript.isEmpty()) {
            appendTranscript(aiDisplayName(), "你好呀！我是 ${aiDisplayName()}～ 可以离线聊天，也可以按需联网检索；简单问题我会直接回答。", false)
        } else {
            transcript.forEach { renderTranscript(it) }
        }
        processingMessage?.let { showThinking(it) }

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(7), dp(8), dp(8))
            background = roundedGradient(C_PANEL_2, C_PANEL, 22, C_STROKE)
        }
        val toolsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        searchButton = styledButton("🌐 联网搜索：${if (webSearchEnabled) "开" else "关"}", if (webSearchEnabled) C_BLUE_DARK else C_PANEL, if (webSearchEnabled) Color.WHITE else C_MUTED, if (webSearchEnabled) C_BLUE else C_STROKE_SOFT).apply {
            setOnClickListener {
                webSearchEnabled = !webSearchEnabled
                preferences.edit().putBoolean("web_search_enabled", webSearchEnabled).apply()
                updateSearchButton()
                statusText.text = if (webSearchEnabled) "联网搜索已开放给 AI：每轮先由模型决定是否调用，不会提前搜索。" else "联网搜索已关闭：AI 本轮不能调用联网搜索，其他工具仍按需开放。"
            }
        }
        toolsRow.addView(searchButton, LinearLayout.LayoutParams(0, dp(35), 1.15f))
        modeButton = styledButton("", C_PANEL, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener {
                val labels = currentModelModeLabels()
                responseModeIndex = (responseModeIndex + 1) % labels.size
                fastMode = responseModeIndex == 0
                val previousContext = configuredContextSize()
                val targetContext = InferenceBudgetPolicy.recommendedContextSize(responseModeIndex)
                preferences.edit()
                    .putInt("response_mode_index", responseModeIndex)
                    .putBoolean("fast_mode", fastMode)
                    .putInt("inference_context_size", targetContext)
                    .apply()
                updateModeButton()
                val selected = currentModelModeLabels()[responseModeIndex]
                val activeContext = loadedModelContextSize
                AppDiagnostics.log(this@MainActivity, "INFO", "mode_context_policy_applied",
                    "mode=$selected; previousPreferenceContext=$previousContext; preferredContext=$targetContext; loadedNativeContext=${activeContext ?: "none"}; activeSoftContext=${InferenceBudgetPolicy.effectiveContextSize(targetContext, activeContext)}; requiresReloadForNativeResize=${activeContext != null && activeContext != targetContext}")
                val needsNativeReload = activeContext != null && activeContext != targetContext
                val baseStatus = when (selected) {
                    "快速" -> "快速模式已启用：减少不必要思考，软上下文目标为 1024 tokens。"
                    "均衡" -> "均衡模式已启用：平衡响应速度与多步分析，软上下文目标为 2048 tokens。"
                    "深度" -> "深度模式已启用：为复杂问题保留更多分析空间，软上下文目标为 4096 tokens。"
                    else -> "回答模式已切换；实际效果取决于当前模型。"
                }
                statusText.text = "$baseStatus 设置上下文：$previousContext → $targetContext；当前原生上下文：${activeContext ?: "未加载"}；本轮有效上下文：${InferenceBudgetPolicy.effectiveContextSize(targetContext, activeContext)}；需要重新加载模型以改变原生容量：$needsNativeReload。" +
                    if (needsNativeReload) " 当前回答先按已加载的原生容量运行。" else ""
            }
        }
        toolsRow.addView(modeButton, LinearLayout.LayoutParams(0, dp(35), 1f).apply { marginStart = dp(5) })
        composer.addView(toolsRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })

        val voiceOptionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        voiceButton = styledButton("", C_PANEL, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener {
                voiceEnabled = !voiceEnabled
                preferences.edit().putBoolean("voice_enabled", voiceEnabled).apply()
                if (!voiceEnabled) stopSpeechPlayback()
                updateVoiceButton()
                statusText.text = when {
                    !voiceEnabled -> "自动朗读已关闭；仍可点击任意 AI 回复下方的朗读按钮。"
                    speechReady -> "自动朗读已开启；新回复会使用本地离线中文音色朗读。"
                    else -> "尚未找到离线中文音色，请点「语音设置」安装或选择本地语音。"
                }
                if (voiceEnabled && !speechReady) showVoiceSetupDialog()
            }
        }
        voiceSettingsButton = styledButton("⚙ 语音设置", C_PANEL, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { showVoiceSettingsDialog() }
        }
        voiceOptionsRow.addView(voiceButton, LinearLayout.LayoutParams(dp(104), dp(33)).apply { marginEnd = dp(6) })
        voiceOptionsRow.addView(voiceSettingsButton, LinearLayout.LayoutParams(dp(112), dp(33)))
        composer.addView(voiceOptionsRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        promptInput = EditText(this).apply {
            hint = "输入你的问题…"
            textSize = 14.5f
            minLines = 1
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
            setTextColor(C_TEXT)
            setHintTextColor(C_MUTED)
            background = null
            setPadding(dp(7), dp(6), dp(5), dp(6))
            setSingleLine(false)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        promptInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateSendButtonState() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        inputRow.addView(promptInput, LinearLayout.LayoutParams(0, -2, 1f))
        sendButton = styledButton("➤", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            textSize = 20f
            setPadding(0, 0, 0, 0)
            contentDescription = "发送消息"
            setOnClickListener { sendMessage() }
        }
        inputRow.addView(sendButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(5) })
        updateSendButtonState()
        composer.addView(inputRow, LinearLayout.LayoutParams(-1, -2))
        root.addView(composer)

        updateModeButton()
        updateVoiceButton()
        updateSearchButton()
    }

    private fun showProfileScreen() {
        isProfileScreen = true
        isPersonalizationScreen = false
        isMoreFeaturesScreen = false
        val scroller = ScrollView(this).apply { setBackgroundColor(C_BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(20))
        }
        scroller.addView(root)
        setContentView(scroller)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(styledButton("‹ 返回聊天", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener { buildInterface() }
        }, LinearLayout.LayoutParams(dp(115), dp(42)))
        top.addView(TextView(this).apply {
            text = "个人中心"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(C_TEXT)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply { text = "✦"; textSize = 22f; setTextColor(C_BLUE_BRIGHT); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(35), dp(42)))
        root.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(20), dp(16), dp(20))
            background = roundedGradient(C_PANEL_2, C_PANEL, 24, C_STROKE)
        }
        hero.addView(createAvatarView(false, 112), LinearLayout.LayoutParams(dp(112), dp(112)))
        hero.addView(TextView(this).apply {
            text = "个人资料 · ${preferences.getString("profile_name", "我").orEmpty().ifBlank { "我" }}"
            textSize = 21f
            setTextColor(C_TEXT)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(9), 0, dp(4))
        })
        hero.addView(TextView(this).apply {
            text = "你的个人资料、头像和聊天偏好都保存在本机 ✨"
            textSize = 12f
            setTextColor(C_MUTED)
            gravity = Gravity.CENTER
        })
        root.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(sectionLabel("我的资料"))
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(C_PANEL, 20, C_STROKE_SOFT)
        }
        val userAvatarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        userAvatarRow.addView(createAvatarView(false, 64), LinearLayout.LayoutParams(dp(64), dp(64)))
        userAvatarRow.addView(TextView(this).apply {
            text = "你的头像会同步显示在每条右侧消息旁边。"
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(dp(10), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        userAvatarRow.addView(styledButton("更换头像", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
            setOnClickListener { showAvatarSourceChooser(forAi = false) }
        }, LinearLayout.LayoutParams(dp(98), dp(42)))
        form.addView(userAvatarRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        form.addView(fieldLabel("昵称"))
        val nameField = profileEditText(preferences.getString("profile_name", "我").orEmpty(), "给自己起个昵称")
        form.addView(nameField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        form.addView(fieldLabel("个性签名"))
        val signatureField = profileEditText(preferences.getString("profile_signature", "正在和东巴壳一起探索世界 ✨").orEmpty(), "写一句你的个性签名")
        form.addView(signatureField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        form.addView(fieldLabel("个人介绍"))
        val introField = profileEditText(preferences.getString("profile_intro", "你好！我喜欢探索新鲜事物，也在慢慢学习。欢迎来聊聊天～").orEmpty(), "介绍一下你自己", multiline = true)
        form.addView(introField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        form.addView(TextView(this).apply {
            text = "兴趣爱好、身高体重、日常偏好和重要记忆已集中放在「个性化」里管理。"
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(0, dp(3), 0, dp(8))
        })
        form.addView(styledButton("保存个人资料", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener {
                preferences.edit()
                    .putString("profile_name", nameField.text.toString().trim().ifBlank { "我" })
                    .putString("profile_signature", signatureField.text.toString().trim())
                    .putString("profile_intro", introField.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "个人资料保存好啦 ✨", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(form, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(sectionLabel("AI 伙伴设置"))
        val aiForm = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(C_PANEL, 20, C_STROKE_SOFT)
        }
        val aiAvatarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        aiAvatarRow.addView(createAvatarView(true, 68), LinearLayout.LayoutParams(dp(68), dp(68)))
        aiAvatarRow.addView(TextView(this).apply {
            text = "AI 头像会同步显示在左侧每条消息旁。默认名称是 pls。"
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(dp(10), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        aiAvatarRow.addView(styledButton("更换头像", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
            setOnClickListener { showAvatarSourceChooser(forAi = true) }
        }, LinearLayout.LayoutParams(dp(92), dp(42)))
        aiForm.addView(aiAvatarRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        aiForm.addView(fieldLabel("AI 昵称"))
        val aiNameField = profileEditText(preferences.getString("ai_name", "pls").orEmpty(), "例如：pls")
        aiForm.addView(aiNameField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        aiForm.addView(styledButton("保存 AI 设置", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener {
                preferences.edit().putString("ai_name", aiNameField.text.toString().trim().ifBlank { "pls" }).apply()
                Toast.makeText(this@MainActivity, "AI 名称已保存", Toast.LENGTH_SHORT).show()
                showProfileScreen()
            }
        }, LinearLayout.LayoutParams(-1, dp(46)))
        root.addView(aiForm, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(sectionLabel("当前加载模型与模型管理"))
        root.addView(buildModelManagerCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(sectionLabel("更多功能"))
        val moreFeatures = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = roundedGradient(C_PANEL_2, C_PANEL, 20, C_STROKE)
        }
        moreFeatures.addView(TextView(this).apply {
            text = "性能诊断、模型解析与后台任务日志集中放在这里。只显示能够确认的状态；尚未接入的底层能力会明确标记，不会假报完成。"
            textSize = 12.5f
            setTextColor(C_MUTED)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, 0, 0, dp(10))
        })
        moreFeatures.addView(styledButton("✦ 打开更多功能", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener { showMoreFeaturesScreen() }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(moreFeatures, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(sectionLabel("个性化管理"))
        val personalizationEntry = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = roundedGradient(C_PANEL_2, C_PANEL, 20, C_STROKE)
        }
        personalizationEntry.addView(TextView(this).apply {
            text = "把你的日常喜好、身高体重、聊天要求、重要记忆和位置资料集中管理。资料仅保存在本机，并会在换模型后继续由应用提供给新模型。"
            textSize = 12.5f
            setTextColor(C_MUTED)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, 0, 0, dp(10))
        })
        personalizationEntry.addView(styledButton("✦ 打开个性化与记忆管理", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener { showPersonalizationScreen() }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(personalizationEntry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(sectionLabel("东巴壳介绍"))
        val about = TextView(this).apply {
            text = "我是 ${aiDisplayName()}，由东巴壳为你提供本地 AI 助手体验。\n\n✨ 本地聊天：使用你导入的 GGUF 模型，支持离线回答。\n🧰 AI 自主工具：模型每轮先判断是否需要 Python 受限计算、联网搜索或天气/位置工具；只有输出明确的工具调用后，程序才校验并执行，再把真实结果交回模型。\n🧮 手动计算器：在“总调度工具”里由你自行操作；AI 没有调用权限。\n🔊 离线朗读：每条 AI 回复可单独播放，也能自动朗读；仅使用系统已安装的离线中文音色。\n📍 天气与位置：只有模型主动请求相应工具后才会执行；设备定位需要你授权，不会后台持续跟踪。\n💾 多话题记录：聊天和个性化资料保存在本机。\n\n小提示：联网搜索依赖网络和搜索站点；搜索结果通常是标题与摘要，重要信息请打开来源核对。工具调用失败时会把真实错误交回模型，不会编造成功。"
            textSize = 14f
            setTextColor(C_TEXT)
            setLineSpacing(dp(4).toFloat(), 1f)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(C_PANEL, 20, C_STROKE_SOFT)
        }
        root.addView(about, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addScreenHeader(root: LinearLayout, title: String, backAction: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(styledButton("‹ 返回", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { backAction() } }, LinearLayout.LayoutParams(dp(88), dp(42)))
        row.addView(TextView(this).apply {
            text = title; textSize = 19f; setTextColor(C_TEXT); setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = "✦"; textSize = 21f; setTextColor(C_BLUE_BRIGHT); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(30), dp(42)))
        root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
    }

    private fun makeFeatureScreen(title: String, backAction: () -> Unit): LinearLayout {
        taskCenterTicker?.cancel()
        taskCenterTicker = null
        taskCenterStatusView = null
        taskCenterProgressBar = null
        taskCenterJournalView = null
        isProfileScreen = true
        isPersonalizationScreen = false
        isMoreFeaturesScreen = true
        val scroller = ScrollView(this).apply { setBackgroundColor(C_BG) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(24)) }
        scroller.addView(root)
        setContentView(scroller)
        addScreenHeader(root, title, backAction)
        return root
    }

    private fun featureCard(title: String, description: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rounded(C_PANEL, 18, C_STROKE_SOFT)
        addView(TextView(this@MainActivity).apply { text = title; textSize = 15f; setTextColor(C_TEXT); setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        addView(TextView(this@MainActivity).apply { text = description; textSize = 12f; setTextColor(C_MUTED); setLineSpacing(dp(2).toFloat(), 1f) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun getAppVersionText(): String = buildString {
        val info = runCatching { packageManager.getPackageInfo(packageName, 0) }.getOrNull()
        val label = runCatching { applicationInfo.loadLabel(packageManager).toString() }.getOrDefault("东巴壳")
        append("应用名称：").append(label).append('\n')
        append("应用版本：").append(info?.versionName ?: "未知").append('\n')
        append("版本代码：").append(info?.longVersionCode ?: -1L).append('\n')
        append("应用包名：").append(packageName).append('\n')
        append("最低支持系统：Android 10（API 29）及以上").append('\n')
        append("本地引擎：llama.cpp v0.6.0").append('\n')
        append("设备支持的 ABI（不代表 APK 实际打包架构）：").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\n')
        append("设备代号：").append(Build.DEVICE).append('\n')
        append("硬件平台：").append(Build.HARDWARE).append('\n')
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) append("SoC：").append(Build.SOC_MANUFACTURER).append(' ').append(Build.SOC_MODEL).append('\n')
        append("物理内存总量：").append(formatBytes(AppDiagnostics.memoryTotalBytes(this@MainActivity))).append('\n')
        append("当前设备：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
    }

    private fun showDiagnosticLogsScreen() {
        val root = makeFeatureScreen("运行与崩溃日志", ::showMoreFeaturesScreen)
        root.addView(TextView(this).apply {
            text = "日志仅保存在本机应用私有目录，不会上传，也不会记录聊天正文。关闭普通日志后仍保留警告、错误、崩溃记录和异常中断标记。导出报告包含环境、配置、原生指标与保留日志，不包含聊天正文。"
            textSize = 12f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(6))
        })
        val logToggle = CheckBox(this).apply {
            text = "记录普通运行日志（排查问题时建议开启）"
            textSize = 13f; setTextColor(C_TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
            isChecked = preferences.getBoolean("runtime_logging_enabled", true)
        }
        logToggle.setOnCheckedChangeListener { _, checked ->
            preferences.edit().putBoolean("runtime_logging_enabled", checked).apply()
            NativeLlamaEngine.setVerboseLogging(checked)
            AppDiagnostics.log(this@MainActivity, if (checked) "INFO" else "WARN", "runtime_logging_preference",
                if (checked) "Ordinary runtime logging enabled from the log screen." else "Ordinary log writing disabled from the log screen; WARN/ERROR/FATAL retained.")
            Toast.makeText(this@MainActivity, if (checked) "已开启普通运行日志" else "已关闭普通日志；警告、错误与崩溃记录仍保留", Toast.LENGTH_LONG).show()
        }
        root.addView(logToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        root.addView(TextView(this).apply {
            text = "保留日志上限为当前文件 512 KiB + 轮转文件 512 KiB。实时生成预览是独立开关，不会与日志记录混为一谈。"
            textSize = 11f; setTextColor(C_MUTED); setPadding(dp(4), 0, dp(4), dp(8))
        })
        val logView = TextView(this).apply {
            textSize = 11f; setTextColor(C_TEXT); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true); setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(C_PANEL, 14, C_STROKE_SOFT)
        }
        fun refreshLogView() {
            val all = AppDiagnostics.readAll(this)
            logView.text = if (all.length > 90000) "（页面仅显示日志末尾 90,000 个字符；导出文件包含完整保留日志。）\n\n" + all.takeLast(90000) else all
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(styledButton("刷新", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { refreshLogView() } }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(styledButton("导出日志", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener { exportDiagnosticsLauncher.launch("DongBaKe-diagnostics-${System.currentTimeMillis()}.txt") }
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(6) })
        actions.addView(styledButton("清空", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("清空运行日志？")
                    .setMessage("只删除日志，不会删除模型、聊天记录或个人记忆。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("清空") { _, _ -> AppDiagnostics.clear(this@MainActivity); refreshLogView() }
                    .show()
            }
        }, LinearLayout.LayoutParams(0, dp(42), 0.72f).apply { marginStart = dp(6) })
        root.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(340)))
        refreshLogView()
    }

    private fun showToolHubScreen() {
        val root = makeFeatureScreen("总调度工具", ::buildInterface)
        root.addView(TextView(this).apply {
            text = "这里是工具目录，不等于 AI 的执行权限。AI 工具必须先由本地模型明确发起调用，再经过代码层权限与参数检查。仅用户使用的功能不会注册到 AI 调度器。"
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(12))
        })
        AiToolRegistry.definitions().forEach { definition ->
            val isAvailable = definition.callableByAi && (definition.name != "web_search" || webSearchEnabled)
            val access = when {
                !definition.callableByAi -> "仅用户手动使用"
                !isAvailable -> "AI 工具 · 当前关闭"
                else -> "AI 可调用 · 由模型决定"
            }
            root.addView(featureCard("${definition.displayName}  ·  $access", "用途：${definition.purpose}\n适用：${definition.whenToUse}\n参数：${definition.arguments}\n限制：${definition.limits}\n返回：${definition.resultFormat}"),
                LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            if (definition.name == "manual_calculator") {
                root.addView(styledButton("打开手动计算器", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
                    setOnClickListener { showManualCalculatorScreen() }
                }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(10) })
            }
        }
        root.addView(TextView(this).apply {
            text = "调用顺序：AI 判断 → 输出显式工具调用 → 程序校验 → 执行工具 → 真实结果返回 AI → AI 生成最终回答。每轮工具调用有上限；失败不会伪装成成功。"
            textSize = 12f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, dp(3), 0, dp(12))
        })
    }

    private fun showManualCalculatorScreen() {
        val root = makeFeatureScreen("手动计算器", ::showToolHubScreen)
        root.addView(TextView(this).apply {
            text = "仅供你在本页面手动输入并点击计算。它不接收聊天消息，也不属于 AI 工具注册表。为安全起见，仅支持受限数学表达式，不运行任意 Python 代码。"
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(12))
        })
        val expression = EditText(this).apply {
            hint = "例如：sqrt(25) + 12 * 8"
            setSingleLine(true)
            textSize = 16f
            setTextColor(C_TEXT)
            setHintTextColor(C_MUTED)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(C_PANEL, 14, C_STROKE)
        }
        root.addView(expression, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        val resultView = TextView(this).apply {
            text = "结果会显示在这里。"
            textSize = 15f; setTextColor(C_TEXT); setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(C_PANEL, 14, C_STROKE_SOFT)
            setTextIsSelectable(true)
        }
        val calculateButton = styledButton("计算", C_BLUE_DARK, Color.WHITE, C_BLUE)
        calculateButton.setOnClickListener {
            val raw = expression.text.toString().trim()
            if (raw.isBlank()) { resultView.text = "请先输入表达式。"; return@setOnClickListener }
            if (raw.length > 180) { resultView.text = "表达式最多 180 字符。"; return@setOnClickListener }
            calculateButton.isEnabled = false
            lifecycleScope.launch {
                resultView.text = "正在使用受限 Python 数学模块计算…"
                try {
                    val outcome = executeSafePythonExpression(raw)
                    resultView.text = if (outcome.startsWith("ERROR:")) "计算失败：${outcome.removePrefix("ERROR:").trim()}" else outcome
                } catch (e: Exception) {
                    resultView.text = "计算失败：${e.message ?: e.javaClass.simpleName}"
                } finally { calculateButton.isEnabled = true }
            }
        }
        root.addView(calculateButton, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(10) })
        root.addView(resultView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        root.addView(styledButton("‹ 返回总调度工具", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { showToolHubScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun showMoreFeaturesScreen() {
        val root = makeFeatureScreen("更多功能", ::showProfileScreen)
        root.addView(TextView(this).apply {
            text = "这些入口会调用实际的本地诊断或记录真实运行状态。运行任务切换页面后仍可在任务中心查看；应用进程被系统结束后，未完成任务会被标记为中断。"
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(12))
        })
        root.addView(featureCard("⚡ 性能与运行管理", "集中查看首字延迟、上下文、GGUF 量化、CPU 线程与后端状态；可按需检查 Vulkan 支持、控制普通日志记录，并查看推测解码的真实限制。不会改写你的模型文件。 ").apply {
            addView(styledButton("打开性能与运行管理", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply { setOnClickListener { showPerformanceManagementScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("🧾 运行与崩溃日志", "记录启动、模型导入/加载阶段、内存风险和异常堆栈；如果进程在原生加载时突然退出，下次启动会记录最后未完成操作。日志仅保存在本机，可查看并导出分析。").apply {
            addView(styledButton("查看运行日志", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply { setOnClickListener { showDiagnosticLogsScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("📋 后台任务与进度", "查看当前/最近任务、阶段、耗时、结果和错误日志。没有底层真实进度回调时只显示阶段，不伪造百分比。").apply {
            addView(styledButton("打开任务中心", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply { setOnClickListener { showTaskCenterScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("🔎 GGUF 模型分析", "读取选中模型的文件头和元数据线索，不会加载 5 GB 权重，也不会改写或量化原始模型。").apply {
            addView(styledButton("分析当前选中模型", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { analyzeSelectedModelFromHub() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("⚡ 本地推理基准", "运行一次短测试并记录总耗时与返回文本长度。当前原生引擎通过 Token 回调输出；短基准记录端到端耗时，是否 GPU 加速应对照引擎日志与多次测试。").apply {
            addView(styledButton("运行一次短基准", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { runLocalInferenceBenchmark() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("🧭 本地 Embedding 工具路由", "使用本机 BGE-small-zh-v1.5 ONNX 模型计算问题与工具说明的语义相关度，仅筛选候选工具，不代替主模型决定是否调用。模型未安装、加载失败或置信度不足时自动回退为展示全部已授权工具。不会自动联网下载模型。请分别导入兼容的 model.onnx 与同模型的 vocab.txt；导入后保存在应用私有目录。") .apply {
            addView(styledButton("导入 Embedding ONNX 模型", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
                setOnClickListener { chooseEmbeddingOnnx.launch(arrayOf("application/octet-stream", "application/onnx", "*/*")) }
            }, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(6) })
            addView(styledButton("导入匹配的 vocab.txt", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
                setOnClickListener { chooseEmbeddingVocab.launch(arrayOf("text/plain", "*/*")) }
            }, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(6) })
            addView(TextView(this@MainActivity).apply {
                text = "当前状态：${if (LocalEmbeddingRouter.isReady(this@MainActivity)) "模型与词表文件已存在（首次推理仍需验证加载及输出）" else "未安装；将安全回退到完整工具清单"}"
                textSize = 11.5f; setTextColor(C_MUTED); setPadding(0, dp(4), 0, 0)
            })
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("🧪 推理诊断实验室", "做最小化真实推理测试；报告 APK 的实际编译后端、模型加载配置、n_ctx/n_batch/n_ubatch 日志、崩溃线索和内存快照。诊断记录不包含聊天正文。CPU-only 对照必须使用不含 Vulkan 后端的专用构建，不能仅把 GPU 层数设为 0。 ").apply {
            addView(styledButton("运行最小推理自测（只回答数字 2）", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
                setOnClickListener { runDiagnosticSelfTest() }
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(7) })
            addView(styledButton("导出完整诊断报告", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
                setOnClickListener { exportDiagnosticsLauncher.launch("DongBaKe-diagnostics-${System.currentTimeMillis()}.txt") }
            }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("🗃 模型元数据缓存与预处理", "查看缓存是否与当前文件大小/修改时间匹配；可清除可重建的 GGUF 解析档案，不会删除模型权重、聊天记录或个人记忆。GPU 管线缓存是否存在由引擎实际能力决定。 ").apply {
            addView(styledButton("查看模型缓存状态", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { showModelCacheScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("⚙️ 推理参数", "配置下次模型加载时使用的 CPU 线程与上下文长度。不会在内存告警时自动修改，也不会暗中降低你选择的参数。批处理/KV Cache 选项只有当前引擎公开接口支持时才提供。 ").apply {
            addView(styledButton("调整线程与上下文", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { showInferenceSettingsScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(featureCard("🧠 内存状态", "查看系统可用内存、应用进程 PSS 与模型文件大小；无法公开读取的 GPU 显存不会猜测。此页只报告风险，不自动降线程、降上下文或切换模型。 ").apply {
            addView(styledButton("查看内存状态", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { showMemoryStatusScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val engineStatusView = TextView(this).apply {
            text = "尚未执行本次引擎检测。点击下方刷新按钮后，应用会读取原生 JNI、动态 CPU/Vulkan 后端和系统设备状态。"
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        root.addView(featureCard("🧩 推理引擎 / GPU 状态", "按需读取当前 APK 中实际加载的原生引擎、CPU/Vulkan 后端、设备枚举结果和已加载模型的卸载配置。系统识别到 Vulkan 设备不等于模型正在使用 GPU。").apply {
            addView(engineStatusView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            addView(styledButton("↻ 刷新获取当前引擎状态", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
                setOnClickListener { refreshEngineAndSystem(engineStatusView, systemStatusView = null, fromButton = this) }
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(7) })
            addView(styledButton("查看引擎诊断说明", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { showEngineCapabilityReport() } }, LinearLayout.LayoutParams(-1, dp(42)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val appStatusView = TextView(this).apply {
            text = getAppVersionText()
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        root.addView(featureCard("📦 应用版本介绍", "显示东巴壳已安装版本、版本代码、包名及构建架构信息。").apply {
            addView(appStatusView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            addView(styledButton("↻ 刷新应用版本信息", C_PANEL_2, C_TEXT, C_STROKE).apply {
                setOnClickListener { appStatusView.text = getAppVersionText() }
            }, LinearLayout.LayoutParams(-1, dp(42)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val systemStatusView = TextView(this).apply {
            text = getSystemVersionText()
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        val systemDetails = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(systemStatusView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            addView(styledButton("↻ 刷新系统信息", C_PANEL_2, C_TEXT, C_STROKE).apply {
                setOnClickListener { refreshEngineAndSystem(engineStatusView, systemStatusView, this) }
            }, LinearLayout.LayoutParams(-1, dp(42)))
        }
        val systemToggle = styledButton("展开系统版本详情", C_PANEL_2, C_TEXT, C_STROKE)
        systemToggle.setOnClickListener {
            val expanded = systemDetails.visibility != View.VISIBLE
            systemDetails.visibility = if (expanded) View.VISIBLE else View.GONE
            systemToggle.text = if (expanded) "收起系统版本详情" else "展开系统版本详情"
        }
        root.addView(featureCard("📱 系统版本介绍", "系统信息默认折叠，点击按钮查看 Android 版本、API 级别和 Vulkan 系统功能标志。").apply {
            addView(systemToggle, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(8) })
            addView(systemDetails, LinearLayout.LayoutParams(-1, -2))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(styledButton("‹ 返回个人中心", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { showProfileScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun formatJournalTime(timeMillis: Long): String =
        SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA).format(Date(timeMillis))

    private fun appendTaskJournalEvent(event: JSONObject) {
        synchronized(taskJournalLock) {
            val old = runCatching { JSONArray(preferences.getString("runtime_task_journal", "[]")) }.getOrDefault(JSONArray())
            val next = JSONArray()
            for (i in maxOf(0, old.length() - 58) until old.length()) next.put(old.optJSONObject(i) ?: JSONObject())
            next.put(event)
            preferences.edit().putString("runtime_task_journal", next.toString()).apply()
        }
    }

    /** Find the latest start time for a task even when nested tasks temporarily own the current slot. */
    private fun findTaskStartTimeLocked(name: String): Long? {
        val current = runCatching { JSONObject(preferences.getString("runtime_task_current", "{}")) }.getOrDefault(JSONObject())
        if (current.optString("name") == name && current.optLong("startedAt") > 0L) return current.optLong("startedAt")
        val journal = runCatching { JSONArray(preferences.getString("runtime_task_journal", "[]")) }.getOrDefault(JSONArray())
        for (i in journal.length() - 1 downTo 0) {
            val item = journal.optJSONObject(i) ?: continue
            if (item.optString("name") == name && item.optString("state") == "RUNNING") {
                val value = item.optLong("startedAt", 0L)
                if (value > 0L) return value
            }
        }
        return null
    }

    /** Add a history event without replacing the visible current task (used for superseded requests). */
    private fun recordTaskJournalOnly(name: String, stage: String, detail: String, state: String) {
        synchronized(taskJournalLock) {
            val now = System.currentTimeMillis()
            val startedAt = findTaskStartTimeLocked(name) ?: now
            val elapsedMs = (now - startedAt).coerceAtLeast(0L)
            appendTaskJournalEvent(JSONObject()
                .put("time", now).put("name", name).put("stage", stage)
                .put("detail", detail.take(800)).put("state", state).put("startedAt", startedAt)
                .put("elapsedMs", elapsedMs).put("percent", JSONObject.NULL))
        }
    }

    private fun recordTaskProgress(name: String, stage: String, detail: String, percent: Int? = null, state: String = "RUNNING", startedAtOverride: Long? = null, elapsedMsOverride: Long? = null) {
        synchronized(taskJournalLock) {
            val now = System.currentTimeMillis()
            val startedAt = startedAtOverride ?: findTaskStartTimeLocked(name) ?: now
            // A task recovered after process death must retain its last measured active elapsed time;
            // wall-clock time spent while the app was not running is not processing time.
            val elapsedMs = elapsedMsOverride ?: (now - startedAt).coerceAtLeast(0L)
            val current = JSONObject()
                .put("name", name).put("stage", stage).put("detail", detail.take(1600))
                .put("state", state).put("startedAt", startedAt).put("updatedAt", now).put("elapsedMs", elapsedMs)
            if (percent != null) current.put("percent", percent.coerceIn(0, 100)) else current.put("percent", JSONObject.NULL)
            preferences.edit().putString("runtime_task_current", current.toString()).apply()
            appendTaskJournalEvent(JSONObject()
                .put("time", now).put("name", name).put("stage", stage).put("detail", detail.take(800))
                .put("state", state).put("startedAt", startedAt).put("elapsedMs", elapsedMs)
                .put("percent", percent ?: JSONObject.NULL))
        }
        if (taskCenterStatusView != null) runOnUiThread {
            taskCenterStatusView?.text = currentTaskSummaryText()
        }
    }

    private fun currentTaskSummaryText(): String {
        val current = runCatching { JSONObject(preferences.getString("runtime_task_current", "{}")) }.getOrDefault(JSONObject())
        val state = current.optString("state", "IDLE")
        val startedAt = current.optLong("startedAt", 0L)
        val elapsed = if (state == "RUNNING" && startedAt > 0L) {
            ((System.currentTimeMillis() - startedAt) / 1000L).coerceAtLeast(0L)
        } else {
            (current.optLong("elapsedMs", 0L) / 1000L).coerceAtLeast(0L)
        }
        return buildString {
            append("任务：").append(current.optString("name", "暂无任务")).append('\n')
            append("状态：").append(when (state) { "RUNNING" -> "运行中"; "SUCCESS" -> "已完成"; "FAILED" -> "失败"; "INTERRUPTED" -> "已中断"; else -> "暂无记录" }).append('\n')
            append("阶段：").append(current.optString("stage", "—")).append('\n')
            if (startedAt > 0L) append("开始：").append(formatJournalTime(startedAt)).append('\n')
            if (state == "RUNNING") append("已耗时：").append(elapsed).append(" 秒\n")
            else if (startedAt > 0L) append("总耗时：").append(elapsed).append(" 秒\n")
            val pct = current.opt("percent")
            if (pct is Number) append("应用流程阶段进度：").append(pct.toInt()).append("%\n")
            append(current.optString("detail", "暂无详细状态。"))
        }
    }

    private fun beginTrackedTask(name: String, detail: String) = recordTaskProgress(name, "开始", detail, null, "RUNNING", System.currentTimeMillis())
    private fun updateTrackedTask(name: String, stage: String, detail: String, percent: Int? = null) = recordTaskProgress(name, stage, detail, percent, "RUNNING")
    private fun finishTrackedTask(name: String, success: Boolean, detail: String) = recordTaskProgress(name, if (success) "完成" else "失败/中断", detail, if (success) 100 else null, if (success) "SUCCESS" else "FAILED")

    private fun recoverInterruptedTask() {
        val current = runCatching { JSONObject(preferences.getString("runtime_task_current", "{}")) }.getOrDefault(JSONObject())
        if (current.optString("state") == "RUNNING") {
            recordTaskProgress(
                current.optString("name", "未知任务"),
                "进程恢复",
                "上次任务未留下完成记录，可能因应用进程退出或系统回收而中断。原始阶段：${current.optString("stage")}。应用不在运行期间的时间不计入任务处理耗时。",
                null,
                "INTERRUPTED",
                current.optLong("startedAt", System.currentTimeMillis()),
                current.optLong("elapsedMs", 0L)
            )
        }
    }

    private fun showTaskCenterScreen() {
        val root = makeFeatureScreen("后台任务与进度", ::showMoreFeaturesScreen)
        val taskCard = featureCard("当前运行任务", "以下状态由实际任务阶段写入；长耗时步骤仅在底层提供真实进度时显示百分比。")
        val taskStatus = TextView(this).apply {
            text = currentTaskSummaryText(); textSize = 12.5f; setTextColor(C_TEXT)
            setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, dp(6), 0, dp(4))
        }
        taskCenterStatusView = taskStatus
        taskCard.addView(taskStatus)
        val taskProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = runCatching { JSONObject(preferences.getString("runtime_task_current", "{}")).optString("state") == "RUNNING" }.getOrDefault(false)
            visibility = if (isIndeterminate) View.VISIBLE else View.GONE
            minimumHeight = dp(3)
        }
        taskCenterProgressBar = taskProgress
        taskCard.addView(taskProgress, LinearLayout.LayoutParams(-1, dp(3)).apply { topMargin = dp(4) })
        root.addView(taskCard)
        root.addView(styledButton("刷新任务状态", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { showTaskCenterScreen() } }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        root.addView(styledButton("清除历史日志（不影响聊天/模型/记忆）", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener { preferences.edit().putString("runtime_task_journal", "[]").apply(); showTaskCenterScreen() }
        }, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(14) })
        root.addView(sectionLabel("最近任务日志（每秒刷新，显示最近 25 条）"))
        val journalView = TextView(this).apply {
            textSize = 11.5f; setTextColor(C_TEXT); setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(10), dp(9), dp(10), dp(9)); background = rounded(C_PANEL, 16, C_STROKE_SOFT)
        }
        taskCenterJournalView = journalView
        root.addView(journalView, LinearLayout.LayoutParams(-1, -2))
        refreshTaskJournalView()
        taskCenterTicker = lifecycleScope.launch {
            while (isMoreFeaturesScreen && taskCenterStatusView != null) {
                taskCenterStatusView?.text = currentTaskSummaryText()
                val taskRunning = runCatching { JSONObject(preferences.getString("runtime_task_current", "{}")).optString("state") == "RUNNING" }.getOrDefault(false)
                taskCenterProgressBar?.apply {
                    isIndeterminate = taskRunning
                    visibility = if (taskRunning) View.VISIBLE else View.GONE
                }
                refreshTaskJournalView()
                delay(1000L)
            }
        }
    }

    private fun refreshTaskJournalView() {
        val view = taskCenterJournalView ?: return
        val journal = runCatching { JSONArray(preferences.getString("runtime_task_journal", "[]")) }.getOrDefault(JSONArray())
        if (journal.length() == 0) {
            view.text = "还没有日志。执行模型分析、加载或基准测试后，这里会记录真实阶段和结果。"
            return
        }
        view.text = buildString {
            // Bounded single TextView prevents rebuilding dozens of View objects every second.
            for (i in journal.length() - 1 downTo maxOf(0, journal.length() - 25)) {
                val event = journal.optJSONObject(i) ?: continue
                val t = event.optLong("time", 0L)
                append(if (t > 0) formatJournalTime(t) else "时间未知")
                append(" · ").append(event.optString("name", "任务"))
                append("\n").append(event.optString("state", "未知状态"))
                append(" / ").append(event.optString("stage", "阶段未知"))
                val elapsedMs = event.optLong("elapsedMs", -1L)
                if (elapsedMs >= 0L) append(" · 耗时 ").append(String.format(Locale.CHINA, "%.1f", elapsedMs / 1000.0)).append(" 秒")
                append("\n").append(event.optString("detail", ""))
                val pct = event.opt("percent")
                if (pct is Number) append("\n任务结束状态：").append(pct.toInt()).append("%")
                append("\n\n")
            }
        }
    }

    private fun showModelCacheScreen() {
        val root = makeFeatureScreen("模型缓存与预处理", ::showMoreFeaturesScreen)
        val currentFile = modelFile
        val panel = featureCard("本机模型档案缓存", "此页只管理应用内保存的 GGUF 元数据解析结果，不清理模型权重，也不声称当前引擎保存了 GPU 管线缓存。")
        val status = TextView(this).apply {
            textSize = 12.5f; setTextColor(C_TEXT); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, dp(6), 0, dp(8))
        }
        fun renderStatus() {
            val models = modelFiles()
            val cached = models.count { readCachedModelProfile(it) != null }
            val selected = readCachedModelProfile(currentFile)
            status.text = buildString {
                append("模型文件数量：${models.size}\n")
                append("有匹配元数据缓存：$cached / ${models.size}\n")
                append("当前选择：${currentFile.name.ifBlank { "未选择" }}\n")
                append("文件存在：${currentFile.isFile}\n")
                if (currentFile.isFile) {
                    append("文件大小：${formatBytes(currentFile.length())}\n")
                    append("最后修改：${formatJournalTime(currentFile.lastModified())}\n")
                    append("解析缓存：${if (selected != null) "命中（文件大小/修改时间匹配）" else "未命中或已失效"}\n")
                    selected?.let { append("档案：${it.architecture} · ${it.quantizationHint}\n") }
                }
                append("引擎权重驻留：${if (loadedModelFileName == currentFile.name) "当前模型已加载于本进程" else "当前所选模型未确认加载"}\n")
                append("GPU 管线缓存：当前引擎未向本应用暴露可确认的持久化管线缓存接口。\n")
                append("缓存失效策略：模型文件大小或修改时间变化时重新解析；缓存仅保存元数据，不保存模型权重。")
            }
        }
        panel.addView(status)
        root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(styledButton("重新分析当前选中模型", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener { analyzeSelectedModelFromHub() }
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        root.addView(styledButton("清除 GGUF 元数据档案缓存", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener {
                val keys = preferences.all.keys.filter { it.startsWith("model_profile_") }
                val editor = preferences.edit()
                for (key in keys) editor.remove(key)
                editor.apply()
                recordTaskProgress("模型缓存维护", "完成", "已清除 ${keys.size} 个 GGUF 元数据档案缓存键。模型文件、聊天记录和记忆未改动。", null, "SUCCESS")
                renderStatus()
                Toast.makeText(this@MainActivity, "已清除 ${keys.size} 个元数据档案缓存", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        root.addView(styledButton("记录当前缓存状态", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener {
                renderStatus()
                recordTaskProgress("模型缓存维护", "状态检查", status.text.toString(), null, "SUCCESS")
                showTaskCenterScreen()
            }
        }, LinearLayout.LayoutParams(-1, dp(44)))
        renderStatus()
    }

    private fun analyzeSelectedModelFromHub() {
        val file = modelFile
        if (!file.isFile || file.length() == 0L) {
            AlertDialog.Builder(this).setTitle("还没有选中可分析的模型")
                .setMessage("请先在个人中心的模型管理中选择一个本机 GGUF 文件。此分析不会读取完整权重或上传模型。")
                .setPositiveButton("知道了", null).show()
            return
        }
        if (isModelTransferOrLoading || modelInferenceActive) {
            Toast.makeText(this, "模型正在加载或推理，等任务结束后再分析。", Toast.LENGTH_LONG).show()
            return
        }
        val name = "GGUF 模型分析"
        beginTrackedTask(name, "目标文件：${file.name} · ${formatBytes(file.length())}")
        showTaskCenterScreen()
        lifecycleScope.launch {
            try {
                updateTrackedTask(name, "检查文件", "文件存在且可读；读取 GGUF 头部与元数据线索。", null)
                val profile = withContext(Dispatchers.IO) { ModelProfileAnalyzer.analyze(file) }
                updateTrackedTask(name, "解析元数据", "已取得架构、名称、量化类型线索及模板判断；未扫描权重，不代表运行性能验证。", null)
                saveModelProfile(file, profile)
                finishTrackedTask(name, true, "分析成功：${profile.architecture}；${profile.quantizationHint}；${formatBytes(profile.modelBytes)}。未运行推理基准。")
                AlertDialog.Builder(this@MainActivity).setTitle("模型分析结果")
                    .setMessage("名称：${profile.displayName}\nGGUF 版本：${profile.ggufVersion}\n架构：${profile.architecture}\n量化标签：${profile.quantizationHint}\n张量数量：${profile.tensorCount}\n元数据条目：${profile.metadataCount}\n张量数据类型统计：${profile.tensorQuantizationSummary.ifBlank { "未读取到" }}\n参数量元数据：${profile.parameterCount ?: "未提供"}\n分词器：${profile.tokenizerModel.ifBlank { "未识别" }}\n聊天模板字段：${if (profile.hasChatTemplate) "存在" else "未确认"}\n文件大小：${formatBytes(profile.modelBytes)}\n\n${profile.notes}\n\n证据范围：GGUF 头部/元数据/张量目录；没有读取权重数据，也未验证模型是否能在当前引擎推理。")
                    .setPositiveButton("查看任务日志") { _, _ -> showTaskCenterScreen() }
                    .setNegativeButton("关闭", null).show()
            } catch (e: Exception) {
                finishTrackedTask(name, false, "分析失败：${e.message ?: e.javaClass.simpleName}")
                AlertDialog.Builder(this@MainActivity).setTitle("模型分析失败").setMessage(e.message ?: "未知错误")
                    .setPositiveButton("查看日志") { _, _ -> showTaskCenterScreen() }.show()
            }
        }
    }

    /**
     * Runs a deterministic, short native inference outside chat history. If the native
     * process segfaults, the persisted AppDiagnostics operation marker identifies this test.
     */
    private fun runDiagnosticSelfTest() {
        if (!NativeLlamaEngine.isAvailable) {
            AlertDialog.Builder(this).setTitle("原生引擎不可用")
                .setMessage(NativeLlamaEngine.statusReport()).setPositiveButton("关闭", null).show()
            return
        }
        val handle = nativeModelHandle
        if (handle == 0L || loadedModelFileName.isNullOrBlank()) {
            AlertDialog.Builder(this).setTitle("请先加载模型")
                .setMessage("最小推理自测需要一个当前已加载的本地 GGUF 模型。请先正常加载模型，再回到「更多功能 → 推理诊断实验室」。")
                .setPositiveButton("知道了", null).show()
            return
        }
        if (isBusy || modelInferenceActive || isModelTransferOrLoading) {
            Toast.makeText(this, "当前已有模型任务，请等它结束后再运行诊断。", Toast.LENGTH_LONG).show()
            return
        }

        val modelName = loadedModelFileName ?: "unknown"
        val start = android.os.SystemClock.elapsedRealtime()
        val prompt = "只回答数字 2，不要解释。"
        val systemPrompt = "你正在执行本地推理稳定性自测。请严格只回答数字 2。"
        val operationDetails = "model=$modelName; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; " +
            "requestedGpuLayers=${configuredGpuLayers()}; kvCache=${if (configuredKvCacheQuantization() == 1) "Q8_0" else "F16"}; " +
            "promptChars=${prompt.length}; outputLimit=24; purpose=diagnostic_self_test"

        isBusy = true
        setActionButtonsEnabled(false)
        AppDiagnostics.beginOperation(this, "diagnostic_self_test", operationDetails)
        beginTrackedTask("推理诊断自测", "使用当前已加载模型和固定短提示词进行一次真实原生推理；不会写入正式聊天历史。")
        showThinking("正在运行最小推理自测；如果原生进程异常退出，下次启动时日志会保留本次未完成操作。")
        lifecycleScope.launch {
            var answer = ""
            try {
                answer = withContext(Dispatchers.IO) {
                    NativeLlamaEngine.generate(handle, prompt, "$systemPrompt\n/no_think", 24, onToken = { /* fixed diagnostic output; never enters chat transcript */ })
                }
                val elapsedMs = android.os.SystemClock.elapsedRealtime() - start
                val metrics = NativeLlamaEngine.lastInferenceMetrics(handle)
                val nativeTail = NativeLlamaEngine.lastNativeLogTail().takeLast(10000)
                val errorMarkers = listOf(
                    "无法创建本地推理上下文", "无法初始化 Token 采样器", "模型预填充失败",
                    "GPU 预填充失败", "无法加载此 GGUF 模型", "推理停止：", "推测解码异常"
                )
                val inferenceCompleted = answer.isNotBlank() && errorMarkers.none { answer.startsWith(it) }
                val normalizedAnswer = parseModelReply(answer).answer.trim().trim('`', ' ', '\n', '\r', '\t', '.', '。')
                val answerCorrect = normalizedAnswer == "2"
                val success = inferenceCompleted && answerCorrect
                val resultLabel = when {
                    success -> "passed"
                    inferenceCompleted -> "answer_mismatch"
                    else -> "reported_error"
                }
                val details = "model=$modelName; elapsedMs=$elapsedMs; outputChars=${answer.length}; result=$resultLabel; inferenceCompleted=$inferenceCompleted; answerCorrect=$answerCorrect; normalizedAnswer=${normalizedAnswer.take(40)}; $metrics"
                AppDiagnostics.log(this@MainActivity, if (success) "INFO" else "ERROR", "diagnostic_self_test_result", details)
                if (nativeTail.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "diagnostic_self_test_native_tail", nativeTail)
                AppDiagnostics.finishOperation(this@MainActivity, "diagnostic_self_test", if (success) "success" else "failed", details)
                finishTrackedTask("推理诊断自测", success, "$details\n\n原生指标：$metrics")
                val report = buildString {
                    append("结果：").append(when {
                        success -> "自测通过（推理完成，且最终答案正确）"
                        inferenceCompleted -> "推理已完成，但答案不符合预期；本测试要求最终只回答数字 2"
                        else -> "引擎返回错误或空结果"
                    }).append('\n')
                    append("模型：").append(modelName).append('\n')
                    append("端到端耗时：").append(elapsedMs).append(" ms\n")
                    append("返回文本长度：").append(answer.length).append(" 个字符\n")
                    append("返回摘要：").append(answer.take(160).ifBlank { "（空）" }).append("\n\n")
                    append("原生指标：\n").append(metrics).append("\n\n")
                    append("当前模型配置：\n").append(NativeLlamaEngine.loadedModelReport(handle)).append("\n\n")
                    append("判断 GPU 是否真正参与推理，请查看原生卸载日志中的 offloaded X/Y layers to GPU；设备枚举与 gpuLayers 请求值都不能单独证明 GPU 实际运行。")
                }
                AlertDialog.Builder(this@MainActivity).setTitle(if (success) "最小推理自测完成" else "最小推理自测未通过")
                    .setMessage(report)
                    .setPositiveButton("查看运行日志") { _, _ -> showDiagnosticLogsScreen() }
                    .setNegativeButton("关闭", null).show()
            } catch (e: Exception) {
                AppDiagnostics.logThrowable(this@MainActivity, "ERROR", "diagnostic_self_test_exception", operationDetails, e)
                AppDiagnostics.finishOperation(this@MainActivity, "diagnostic_self_test", "failed", "${e.javaClass.simpleName}: ${e.message.orEmpty()}")
                finishTrackedTask("推理诊断自测", false, "测试失败：${e.message ?: e.javaClass.simpleName}")
                AlertDialog.Builder(this@MainActivity).setTitle("最小推理自测失败")
                    .setMessage("${e.javaClass.simpleName}: ${e.message.orEmpty()}\n\n请导出完整诊断报告供排查。")
                    .setPositiveButton("导出诊断报告") { _, _ -> exportDiagnosticsLauncher.launch("DongBaKe-diagnostics-${System.currentTimeMillis()}.txt") }
                    .setNegativeButton("查看日志") { _, _ -> showDiagnosticLogsScreen() }.show()
            } finally {
                showThinking(null)
                isBusy = false
                setActionButtonsEnabled(true)
                updateSendButtonState()
            }
        }
    }

    /** Export evidence useful for bug reports while deliberately excluding chat text/history. */
    private fun buildFullDiagnosticsReport(): String = buildString {
        append("东巴壳完整本机诊断报告\n")
        append("诊断 Schema 版本：").append(AppDiagnostics.SCHEMA_VERSION).append('\n')
        append("生成时间：").append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(java.util.Date())).append('\n')
        append("隐私说明：此报告不主动导出聊天历史或聊天正文；仅包含环境、模型文件元数据、参数、运行日志与原生引擎日志。\n\n")
        append("========== 应用/系统环境 ==========\n")
        append(getAppVersionText()).append('\n')
        append(AppDiagnostics.deviceSnapshot(this@MainActivity)).append('\n')
        append(AppDiagnostics.memorySnapshot(this@MainActivity)).append('\n')
        append(AppDiagnostics.processSnapshot()).append("\n\n")
        append("========== 当前参数 ==========\n")
        append("回答模式：").append(currentModelModeLabels().getOrElse(responseModeIndex) { "未知" }).append("\n")
        append("模式建议上下文（软性）：").append(InferenceBudgetPolicy.recommendedContextSize(responseModeIndex)).append(" tokens\n")
        append("设置的上下文长度：").append(configuredContextSize()).append(" tokens\n")
        append("当前已加载模型的原生上下文：").append(loadedModelContextSize?.toString() ?: "未加载/未知").append(" tokens\n")
        append("本轮有效软性上下文：").append(InferenceBudgetPolicy.effectiveContextSize(configuredContextSize(), loadedModelContextSize)).append(" tokens\n")
        append("普通运行日志：").append(preferences.getBoolean("runtime_logging_enabled", true)).append('\n')
        append("实时生成预览：").append(preferences.getBoolean("runtime_live_stats_enabled", true)).append('\n')
        append("CPU 线程：").append(configuredCpuThreads()).append('\n')
        append("请求 GPU 卸载层数：").append(configuredGpuLayers()).append('\n')
        append("KV Cache：").append(if (configuredKvCacheQuantization() == 1) "Q8_0（实验性）" else "F16（默认）").append('\n')
        append("推理批次实际记录请查找 context_init_begin 中的 n_ctx/n_batch/n_ubatch 字段。\n\n")
        append("========== 当前选中模型 ==========\n")
        val selected = modelFile
        append("文件名：").append(selected.name).append('\n')
        append("文件存在：").append(selected.isFile).append('\n')
        if (selected.isFile) {
            append("文件大小：").append(selected.length()).append(" bytes\n")
            append("修改时间：").append(selected.lastModified()).append('\n')
        }
        append("当前加载实例：").append(loadedModelFileName ?: "无").append('\n')
        append("模型架构：").append(loadedModelProfile?.architecture ?: "未加载/未知").append('\n')
        append(NativeLlamaEngine.loadedModelReport(nativeModelHandle)).append("\n\n")
        append("========== 原生引擎与后端 ==========\n")
        append(NativeLlamaEngine.statusReport()).append("\n\n")
        append("========== 最近原生推理指标 ==========\n")
        append(NativeLlamaEngine.lastInferenceMetrics(nativeModelHandle)).append("\n\n")
        append("========== 最近 llama.cpp 原生日志 ==========\n")
        append(NativeLlamaEngine.lastNativeLogTail().takeLast(12000)).append("\n\n")
        append("========== 日志文件保留情况 ==========\n")
        append(AppDiagnostics.logFileSnapshot(this@MainActivity)).append("\n\n")
        append("========== 应用运行与崩溃日志 ==========\n")
        append(AppDiagnostics.readAll(this@MainActivity))
    }

    private fun runLocalInferenceBenchmark() {
        val generator = generateReply
        if (generator == null) {
            AlertDialog.Builder(this).setTitle("需要先加载本地模型").setMessage("基准测试会运行一次短的真实本地推理，不会把测试内容加入聊天记录。请先加载 GGUF 模型。")
                .setPositiveButton("知道了", null).show()
            return
        }
        if (isBusy || modelInferenceActive || isModelTransferOrLoading) {
            Toast.makeText(this, "当前有其他模型任务，请完成或停止后再测试。", Toast.LENGTH_LONG).show()
            return
        }
        val name = "本地推理短基准"
        val previousQuestion = activeQuestionText
        val start = android.os.SystemClock.elapsedRealtime()
        isBusy = true
        setActionButtonsEnabled(false)
        beginTrackedTask(name, "使用当前已加载模型执行一条短测试；不会写入正式聊天历史。")
        showTaskCenterScreen()
        showThinking("正在运行真实本地推理基准；原生引擎支持 Token 回调，并会在任务结束后读取 TTFT、Prefill 和 Decode 指标。")
        lifecycleScope.launch {
            var answer = ""
            try {
                activeQuestionText = "基准测试：请只回答数字2。"
                updateTrackedTask(name, "准备输入", "将调用当前模型和当前回答模式；测试输出不会追加到聊天。", null)
                answer = withContext(Dispatchers.IO) { generator("请只回答数字 2，不要解释。", false).answer }
                val elapsed = (android.os.SystemClock.elapsedRealtime() - start) / 1000.0
                val nativeMetrics = NativeLlamaEngine.lastInferenceMetrics(nativeModelHandle)
                AppDiagnostics.log(this@MainActivity, "INFO", "local_inference_benchmark_metrics", nativeMetrics)
                finishTrackedTask(name, true, String.format(Locale.CHINA, "总耗时 %.2f 秒；返回文本 %d 个 UTF-16 字符。原生指标：%s", elapsed, answer.length, nativeMetrics))
                AlertDialog.Builder(this@MainActivity).setTitle("短基准完成")
                    .setMessage(String.format(Locale.CHINA, "真实总耗时：%.2f 秒\n返回文本长度：%d 个字符\n测试输出：%s\n\n原生指标：%s\n\n注意：首 Token 按首次可显示文本计时；Decode tokens/s 使用原生采样 token 计数。", elapsed, answer.length, answer.take(180), nativeMetrics))
                    .setPositiveButton("查看详细日志") { _, _ -> showTaskCenterScreen() }.setNegativeButton("关闭", null).show()
            } catch (e: Exception) {
                finishTrackedTask(name, false, "基准失败：${e.message ?: e.javaClass.simpleName}")
                AlertDialog.Builder(this@MainActivity).setTitle("基准测试失败").setMessage(e.message ?: "未知错误")
                    .setPositiveButton("查看日志") { _, _ -> showTaskCenterScreen() }.show()
            } finally {
                activeQuestionText = previousQuestion
                showThinking(null)
                isBusy = false
                setActionButtonsEnabled(true)
                updateSendButtonState()
            }
        }
    }

    private fun configuredCpuThreads(): Int {
        val requested = preferences.getInt("inference_cpu_threads", 0)
        // Safe default for mixed big.LITTLE mobile CPUs: begin with at most four workers.
        // Keep the user's explicit 2–6 thread choice untouched; measure on-device before raising it.
        return if (requested in 2..6) requested else minOf(Runtime.getRuntime().availableProcessors().coerceAtLeast(2), 4)
    }

    private fun configuredContextSize(): Int {
        val requested = preferences.getInt("inference_context_size", 2048)
        return if (requested in setOf(1024, 2048, 3072, 4096)) requested else 2048
    }

    private fun configuredGpuLayers(): Int {
        val allowed = setOf(0, 4, 8, 12, 16, 20, 24, 28, 32, 64)
        return preferences.getInt("inference_gpu_layers", 0).takeIf { it in allowed } ?: 0
    }

    private fun hasVerifiedVulkanGpuBackend(report: String): Boolean {
        val pluginRegistered = report.contains("Vulkan 后端插件注册：已注册")
        val offloadSupported = report.contains("llama.cpp GPU offload 能力：后端报告支持")
        val physicalDeviceFound = Regex("检测到\\s+[1-9][0-9]* 个 Vulkan 物理设备").containsMatchIn(report)
        return pluginRegistered && offloadSupported && physicalDeviceFound
    }

    private suspend fun readVulkanGpuBackendReport(): String = withContext(Dispatchers.IO) {
        runCatching {
            NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
            NativeLlamaEngine.statusReport()
        }.getOrElse { "后端检测失败：${it.javaClass.simpleName}: ${it.message.orEmpty()}" }
    }

    private fun configuredKvCacheQuantization(): Int =
        if (preferences.getInt("inference_kv_cache_quantization", 0) == 1) 1 else 0

    private fun configuredGpuFlashAttention(): Boolean =
        preferences.getBoolean("inference_gpu_flash_attention", true)

    private fun showPerformanceManagementScreen() {
        val root = makeFeatureScreen("性能与运行管理", ::showMoreFeaturesScreen)
        root.addView(TextView(this).apply {
            text = "这里显示应用当前真实配置与可确认的运行能力。标注“未验证”的性能提升不会被当作已实现；本页不重新量化、不覆盖、不删除本地模型、聊天记录或个人记忆。改动推理配置后，通常需要退出并重新加载模型。"
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(12))
        })

        fun addExpandableCard(title: String, summary: String, details: String) {
            val card = featureCard(title, summary)
            val detailsView = TextView(this).apply {
                text = details
                textSize = 12f; setTextColor(C_TEXT); setLineSpacing(dp(3).toFloat(), 1f)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rounded(C_PANEL_2, 12, C_STROKE_SOFT)
                visibility = View.GONE
                setTextIsSelectable(true)
            }
            val toggle = styledButton("展开详情", C_PANEL_2, C_TEXT, C_STROKE).apply {
                setOnClickListener {
                    val expanded = detailsView.visibility != View.VISIBLE
                    detailsView.visibility = if (expanded) View.VISIBLE else View.GONE
                    text = if (expanded) "收起详情" else "展开详情"
                }
            }
            card.addView(toggle, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(7) })
            card.addView(detailsView, LinearLayout.LayoutParams(-1, -2))
            root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }

        val selectedName = selectedModelName().let { File(it).name }
        val selectedFile = File(modelDirectory, selectedName)
        val profile = selectedModelProfile()
        val metrics = NativeLlamaEngine.lastInferenceMetrics(nativeModelHandle)
        addExpandableCard(
            "① Prefill：首字前的输入处理",
            "当前配置：上下文 ${configuredContextSize()} tokens；线程 ${configuredCpuThreads()}；最近一次可读取的原生指标已附在详情中。",
            buildString {
                append("Prefill 会处理系统提示词、当前问题以及本轮实际保留的对话上下文。独立问题/简答路径会压缩提示词并尽量跳过无关历史，但这不等于零上下文。\\n\\n")
                append("最近一次原生推理指标：\\n").append(metrics).append("\\n\\n")
                append("排查顺序：比较 promptTokens 与 prefillMs；若 promptTokens 很少但 prefill 仍很慢，需要进一步看线程、后端、热降频和构建配置。更改上下文长度需要重新加载模型。")
            }.replace("\\n", "\n")
        )
        addExpandableCard(
            "② KV Cache：缓存状态与复用边界",
            "跨轮 KV 前缀复用已在原生层实现，并保留于当前进程内；是否命中取决于两轮提示词的真实 Token 前缀是否足够相同。",
            "原生层会保留同一模型句柄的 llama_context，并用 Token ID 逐个比较新旧提示词的共同前缀；仅当共同前缀至少连续一致 16 个 Token，且 llama.cpp 能安全裁剪后缀时，才会跳过这部分 Prefill。真实命中以 prefix_cache_hit、prefix_cache_reused_tokens、prefill_processed_tokens 和 prefix_cache_reason 原生指标为准。缓存只驻留当前进程内存；内存压力、模型/上下文重载、推理错误或进程结束会释放或重建缓存，不会写入聊天历史文件。F16/Q8_0 是缓存精度选项，不等同于跨轮缓存是否命中。"
        )
        addExpandableCard(
            "KV Cache 精度（F16 / Q8_0）",
            "当前保存值：${if (configuredKvCacheQuantization() == 1) "Q8_0（实验性）" else "F16（兼容优先）"}；这是缓存精度，不代表跨轮缓存复用。",
            "KV Cache 保存模型在本轮上下文中的键/值状态。F16 是兼容优先的默认值；Q8_0 可能降低缓存内存占用，但属于兼容性/质量与性能都需要实测的设置，不能保证加快预填充或逐 Token 生成。当前值来自既有“推理参数”设置，需重新加载模型后生效。本页只显示信息，不另造重复开关。"
        )
        val quantizationDetails = buildString {
            append("当前选中模型：").append(if (selectedName.isBlank()) "尚未选择" else selectedName).append('\n')
            append("文件存在：").append(if (selectedFile.isFile) "是" else "否/未能访问").append('\n')
            if (selectedFile.isFile) append("文件大小：").append(formatBytes(selectedFile.length())).append('\n')
            append("模型量化线索：").append(profile?.quantizationHint ?: "尚无当前文件的已缓存分析结果").append('\n')
            if (!profile?.tensorQuantizationSummary.isNullOrBlank()) append("张量类型统计：\n").append(profile?.tensorQuantizationSummary).append('\n')
            append("模型架构：").append(profile?.architecture ?: "未缓存/未知").append("\n\n")
            append("量化是模型文件本身的属性，不是每次回答时临时执行的动作。Q4_K_M GGUF 已经是量化模型；本应用不在推理过程中把 16 位权重即时压成 4 位，也不会自动改写原始文件。如没有档案，请先使用“更多功能 → GGUF 模型分析”读取元数据。")
        }
        addExpandableCard(
            "③ 量化：只读查看，不改动模型",
            "仅展示当前模型文件的分析线索；不会在手机后台重新量化或二次压缩。",
            quantizationDetails
        )
        addExpandableCard(
            "④ Decode：逐 Token 生成",
            "当前模型由本地 llama.cpp 执行；简答/均衡/深度模式仍使用现有模式开关。",
            "Decode 速度受模型大小与量化、内存带宽、CPU 算子、线程调度、温度/降频、上下文长度以及生成 Token 数共同影响。限制输出长度只能减少总等待时间，不能保证每秒生成速度提升。当前页面不会自动缩短你请求的答案，也不更改本地 GGUF。最近生成速度请对照“本地推理基准”和原生 metrics，而不是靠主观感觉判断。"
        )
        addExpandableCard(
            "⑤ 上下文长度与历史输入",
            "当前上下文配置：${configuredContextSize()} tokens（这是容量设置，不是本轮实际输入 Token 数）。",
            "本应用当前支持的上下文设置为 1024、2048、3072、4096 tokens，配置在模型重新加载后生效。容量设得更大通常会增加 KV 缓存占用，长输入也会增加预填充和注意力计算负担；并不是把数值调满就会更聪明或更快。独立问题路径尽量省略无关历史，明确追问才保留必要上下文。实际 promptTokens 应看原生 metrics。"
        )
        addExpandableCard(
            "⑥ 推测解码（Speculative Decoding）",
            "现有引擎已有可选的草稿模型路径，但“快 2–3 倍”不是保证，也没有本设备实测依据。",
            "实现机制：草稿模型先提出少量候选 Token，再由目标模型验证接受；当前代码的提议窗口最多为 4。通常需要两个词表/tokenizer 完全兼容的 GGUF 模型。草稿模型会额外占用 RAM，并有单独加载与预填充成本；如果草稿模型不够快或候选被频繁拒绝，整体甚至可能更慢。当前功能仍由既有“推理参数”页的草稿模型选项控制，默认关闭。本管理页只展示限制，不新增一个容易误启的开关，也不宣称实现了 2–3 倍加速。"
        )
        addExpandableCard(
            "⑦ CPU 线程与温度",
            "自动线程默认采用保守值（最多 4）；手动 2–6 线程选项保持兼容。",
            "多核不是越多越快。对手机 big.LITTLE CPU，更多线程可能提高吞吐，也可能加剧小核争抢、功耗与温升。旧配置的手动线程数会保留，不会被静默覆盖；自动模式改为最多 4 线程作更保守的起点。可在“推理参数”页手动对比 3/4/5/6 线程，并在相同模型、上下文、问题下重复测试，观察 prefillMs 和 decodeTokensPerSecond。"
        )

        root.addView(sectionLabel("Vulkan / GPU 后端（能力检测后才可请求启用）"))
        val gpuStatus = TextView(this).apply {
            text = "正在检查当前 APK 的后端编译与设备状态……"
            textSize = 12f; setTextColor(C_TEXT); setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(C_PANEL, 14, C_STROKE_SOFT); setTextIsSelectable(true)
        }
        root.addView(gpuStatus, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val gpuToggle = CheckBox(this).apply {
            text = "请求使用 Vulkan GPU 卸载（下次重新加载模型生效）"
            textSize = 13f; setTextColor(C_TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
            isChecked = configuredGpuLayers() > 0
        }
        root.addView(gpuToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        var syncingGpuToggle = false
        fun renderBackendReport(report: String, applied: Boolean? = null) {
            gpuStatus.text = buildString {
                append("保存的 GPU 层请求：").append(configuredGpuLayers()).append(" 层\\n")
                append("当前已加载模型状态：\\n").append(NativeLlamaEngine.loadedModelReport(nativeModelHandle)).append("\\n\\n")
                append("后端探测结果：\\n").append(report.take(7000)).append("\\n\\n")
                when (applied) {
                    true -> append("检测通过：已保存 4 层 GPU 的保守起始请求。请退出并重新加载模型；之后仍需确认模型报告/原生日志显示真实卸载层数，探测到设备并不代表本次推理已用 GPU。若加载失败，先回到 CPU 路径，不要反复强行提高卸载层数。")
                    false -> append("检测未通过：GPU 请求已关闭并恢复 CPU 路径。不会把“已开启加速”当作状态。")
                    null -> append("注意：当前显示的是能力检测，不等于 GPU 正在参与当前模型推理。")
                }
            }.replace("\\n", "\n")
        }
        fun refreshBackendStatus() {
            gpuStatus.text = "正在读取 JNI / Vulkan 插件 / 物理设备状态……"
            lifecycleScope.launch {
                val report = readVulkanGpuBackendReport()
                renderBackendReport(report)
                if (configuredGpuLayers() > 0 && !hasVerifiedVulkanGpuBackend(report)) {
                    preferences.edit().putInt("inference_gpu_layers", 0).apply()
                    syncingGpuToggle = true; gpuToggle.isChecked = false; syncingGpuToggle = false
                    renderBackendReport(report, false)
                    AppDiagnostics.log(this@MainActivity, "WARN", "gpu_backend_unavailable", "GPU preference reset to CPU because current APK/device capability check failed.")
                }
            }
        }
        gpuToggle.setOnCheckedChangeListener { _, checked ->
            if (syncingGpuToggle) return@setOnCheckedChangeListener
            gpuToggle.isEnabled = false
            if (!checked) {
                preferences.edit().putInt("inference_gpu_layers", 0).apply()
                gpuStatus.text = "已保存 CPU 路径（GPU 请求为 0 层）。如果模型当前已经加载，配置在退出并重新加载模型后生效。"
                AppDiagnostics.log(this, "INFO", "gpu_backend_preference", "requestedGpuLayers=0")
                gpuToggle.isEnabled = true
            } else {
                gpuStatus.text = "先检测当前 APK 是否包含并能加载 Vulkan 后端，以及系统是否枚举出真实设备……"
                lifecycleScope.launch {
                    val report = readVulkanGpuBackendReport()
                    val supported = hasVerifiedVulkanGpuBackend(report)
                    if (supported) {
                        preferences.edit().putInt("inference_gpu_layers", 4).apply()
                        renderBackendReport(report, true)
                        AppDiagnostics.log(this@MainActivity, "INFO", "gpu_backend_preference", "capabilityCheck=passed; requestedGpuLayers=4; actualOffload=unverified_until_reload")
                    } else {
                        preferences.edit().putInt("inference_gpu_layers", 0).apply()
                        syncingGpuToggle = true; gpuToggle.isChecked = false; syncingGpuToggle = false
                        renderBackendReport(report, false)
                        AppDiagnostics.log(this@MainActivity, "WARN", "gpu_backend_enable_rejected", report.take(3000))
                        Toast.makeText(this@MainActivity, "当前 APK/设备未通过 Vulkan 能力检查，已保持 CPU 模式。", Toast.LENGTH_LONG).show()
                    }
                    gpuToggle.isEnabled = true
                }
            }
        }
        root.addView(styledButton("刷新后端检测", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply { setOnClickListener { refreshBackendStatus() } }, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(12) })
        refreshBackendStatus()

        root.addView(sectionLabel("普通运行日志"))
        val logToggle = CheckBox(this).apply {
            text = "记录普通运行日志（建议排查问题时开启）"
            textSize = 13f; setTextColor(C_TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
            isChecked = preferences.getBoolean("runtime_logging_enabled", true)
        }
        root.addView(logToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        root.addView(TextView(this).apply {
            text = "关闭后会停止写入普通 INFO/NATIVE/DEBUG 运行条目，减少一部分文件 I/O；警告、错误、崩溃记录和用于识别异常中断的操作标记仍保留。原生推理内部仍可能维护短日志缓存，因此这不是 Token 生成的主要提速开关。日志保存在本机，不记录聊天正文。"
            textSize = 11.5f; setTextColor(C_MUTED); setLineSpacing(dp(2).toFloat(), 1f); setPadding(dp(4), 0, dp(4), dp(10))
        })
        logToggle.setOnCheckedChangeListener { _, checked ->
            preferences.edit().putBoolean("runtime_logging_enabled", checked).apply()
            NativeLlamaEngine.setVerboseLogging(checked)
            AppDiagnostics.log(this, if (checked) "INFO" else "WARN", "runtime_logging_preference", if (checked) "Ordinary runtime logging enabled." else "Ordinary runtime logging disabled; WARN/ERROR/FATAL remain enabled.")
            Toast.makeText(this, if (checked) "已开启普通运行日志" else "已关闭普通运行日志；错误与崩溃记录仍保留", Toast.LENGTH_LONG).show()
        }
        root.addView(styledButton("打开日志查看页", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { showDiagnosticLogsScreen() } }, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(12) })

        val liveStatsToggle = CheckBox(this).apply {
            text = "实时显示生成预览与高频监控"
            textSize = 13f; setTextColor(C_TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
            isChecked = preferences.getBoolean("runtime_live_stats_enabled", true)
        }
        root.addView(liveStatsToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        root.addView(TextView(this).apply {
            text = "关闭后，生成中的逐 Token 预览不再反复复制文本和刷新界面；原生日志尾部巡检会降低频率（最多约每秒一次），但最终回答、最终诊断指标和错误记录仍保留。它主要减少界面与监控开销，不会改变模型算法，也不保证提高 tokens/s。默认保持开启以兼容原有体验。"
            textSize = 11.5f; setTextColor(C_MUTED); setLineSpacing(dp(2).toFloat(), 1f); setPadding(dp(4), 0, dp(4), dp(10))
        })
        liveStatsToggle.setOnCheckedChangeListener { _, checked ->
            preferences.edit().putBoolean("runtime_live_stats_enabled", checked).apply()
            AppDiagnostics.log(this, if (checked) "INFO" else "WARN", "runtime_live_stats_preference", if (checked) "Live generation preview and high-frequency diagnostics enabled." else "Live generation preview disabled; final answer and final metrics remain available.")
            Toast.makeText(this, if (checked) "已开启实时生成预览" else "已关闭实时生成预览；最终回答仍正常生成", Toast.LENGTH_LONG).show()
        }

        addExpandableCard(
            "⑧ 后台运行与进程保护",
            "只在用户主动加载模型/等待回答时显示前台任务通知；不会常驻后台持续占用资源。",
            "长时间的本地模型加载和回答会在任务执行期间启动 Android 前台服务通知，降低切到其他应用时进程被系统回收的风险。它不能防止用户强制停止应用、系统极端内存压力或厂商电池策略终止，也不等于模型推理已经迁移到独立进程。任务结束会停止通知服务。首次启用时可能看到“东巴壳正在执行本地 AI 任务”的持续通知，这是系统的前台服务要求。"
        )
        root.addView(styledButton("查看现有推理参数（线程/上下文/推测解码）", C_BLUE_DARK, Color.WHITE, C_BLUE).apply { setOnClickListener { showInferenceSettingsScreen() } }, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun inferenceSettingAdapter(labels: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
        private fun styledRow(position: Int, dropdown: Boolean): TextView = TextView(this@MainActivity).apply {
            text = labels.getOrElse(position) { "" }
            textSize = if (dropdown) 13f else 13.5f
            setTextColor(C_TEXT)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(if (dropdown) 14 else 12), dp(8), dp(12), dp(8))
            minHeight = dp(if (dropdown) 46 else 48)
            maxLines = 2
            background = rounded(if (dropdown) C_PANEL_2 else C_PANEL, 12, if (dropdown) C_STROKE_SOFT else C_STROKE)
        }
        override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = styledRow(position, false)
        override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = styledRow(position, true)
    }

    private fun showInferenceSettingsScreen() {
        val root = makeFeatureScreen("推理参数", ::showMoreFeaturesScreen)
        root.addView(TextView(this).apply {
            text = "模式切换会自动把上下文偏好设为快速 1024、均衡 2048、深度 4096 tokens；这是软性目标，不会假装改变已加载的原生上下文。提高原生容量需退出并重新加载模型。其他参数保存后也在下次加载时生效。自动线程保守设置，不保证更多线程更快。"
            textSize = 12.5f; setTextColor(C_MUTED); setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(12))
        })
        root.addView(sectionLabel("CPU 推理线程"))
        val threadLabels = listOf("自动（保守建议，最多 4 线程）", "2 线程", "3 线程", "4 线程", "5 线程（可能更热/变慢）", "6 线程（可能更热/变慢）")
        val threadValues = listOf(0, 2, 3, 4, 5, 6)
        val threadSpinner = Spinner(this).apply {
            background = rounded(C_PANEL_2, 14, C_STROKE)
            setPopupBackgroundDrawable(rounded(C_PANEL, 16, C_STROKE))
            adapter = inferenceSettingAdapter(threadLabels)
            setSelection(threadValues.indexOf(preferences.getInt("inference_cpu_threads", 0)).coerceAtLeast(0))
        }
        root.addView(threadSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(14) })
        root.addView(sectionLabel("上下文长度（模式软性目标）"))
        root.addView(TextView(this).apply {
            text = "当前模式建议 ${InferenceBudgetPolicy.recommendedContextSize(responseModeIndex)} tokens；设置值 ${configuredContextSize()}；当前原生上下文 ${loadedModelContextSize?.toString() ?: "未加载"}。切换模式会同步更新此处设置值。"
            textSize = 11.5f; setTextColor(C_MUTED); setPadding(dp(4), 0, dp(4), dp(7))
        })
        val contextValues = listOf(1024, 2048, 3072, 4096)
        val contextLabels = contextValues.map { "$it tokens" }
        val contextSpinner = Spinner(this).apply {
            background = rounded(C_PANEL_2, 14, C_STROKE)
            setPopupBackgroundDrawable(rounded(C_PANEL, 16, C_STROKE))
            adapter = inferenceSettingAdapter(contextLabels)
            setSelection(contextValues.indexOf(configuredContextSize()).coerceAtLeast(0))
        }
        root.addView(contextSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
        root.addView(sectionLabel("GPU / Vulkan 卸载层数"))
        val gpuLayerValues = listOf(0, 4, 8, 12, 16, 20, 24, 28, 32, 64)
        val gpuLayerLabels = listOf(
            "0 层（CPU-only，默认）", "4 层", "8 层", "12 层", "16 层",
            "20 层", "24 层", "28 层", "32 层", "64 层（请求全部可支持层）"
        )
        val gpuLayerSpinner = Spinner(this).apply {
            background = rounded(C_PANEL_2, 14, C_STROKE)
            setPopupBackgroundDrawable(rounded(C_PANEL, 16, C_STROKE))
            adapter = inferenceSettingAdapter(gpuLayerLabels)
            setSelection(gpuLayerValues.indexOf(configuredGpuLayers()).coerceAtLeast(0))
        }
        root.addView(gpuLayerSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })

        root.addView(sectionLabel("KV Cache 量化（实验性）"))
        val kvCacheValues = listOf(0, 1)
        val kvCacheLabels = listOf("F16（兼容优先，缓存占用较大）", "Q8_0（尝试降低缓存占用）")
        val kvCacheSpinner = Spinner(this).apply {
            background = rounded(C_PANEL_2, 14, C_STROKE)
            setPopupBackgroundDrawable(rounded(C_PANEL, 16, C_STROKE))
            adapter = inferenceSettingAdapter(kvCacheLabels)
            setSelection(configuredKvCacheQuantization())
        }
        root.addView(kvCacheSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })

        root.addView(sectionLabel("GPU Flash Attention"))
        val flashAttentionValues = listOf(true, false)
        val flashAttentionLabels = listOf("自动（GPU 请求时才尝试）", "关闭（兼容优先）")
        val flashAttentionSpinner = Spinner(this).apply {
            background = rounded(C_PANEL_2, 14, C_STROKE)
            setPopupBackgroundDrawable(rounded(C_PANEL, 16, C_STROKE))
            adapter = inferenceSettingAdapter(flashAttentionLabels)
            setSelection(if (configuredGpuFlashAttention()) 0 else 1)
        }
        root.addView(flashAttentionSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })

        root.addView(sectionLabel("推测解码（可选草稿模型）"))
        val draftFiles = modelFiles().filter { it.isFile && it.name != modelFile.name }.sortedBy { it.name.lowercase(Locale.ROOT) }
        val draftNames = listOf("") + draftFiles.map { it.name }
        val draftLabels = listOf("关闭（默认单模型推理）") + draftFiles.map { "草稿：${modelDisplayName(it)} · ${formatBytes(it.length())}" }
        val savedDraftName = preferences.getString("inference_draft_model_filename", "").orEmpty()
        val draftSpinner = Spinner(this).apply {
            background = rounded(C_PANEL_2, 14, C_STROKE)
            setPopupBackgroundDrawable(rounded(C_PANEL, 16, C_STROKE))
            adapter = inferenceSettingAdapter(draftLabels)
            setSelection(draftNames.indexOf(savedDraftName).takeIf { it >= 0 } ?: 0)
        }
        root.addView(draftSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
        root.addView(TextView(this).apply {
            text = "推测解码仅在你主动选择第二个 GGUF 草稿模型后启用；目标与草稿模型必须具有完全相同的 Token 词表。草稿模型使用 CPU + F16 KV Cache，额外占用内存，实际加速效果尚未在设备上验证。若词表不兼容会明确提示，不会自动换模型。NPU/APU 尚不能通用接入，需要对应芯片厂商 SDK 和驱动；当前不宣称支持。此设置不会改变未启用推测解码时的正常推理路径。保存后退出并重新加载模型生效。"
            textSize = 11.5f; setTextColor(C_MUTED); setLineSpacing(dp(2).toFloat(), 1f); setPadding(0, 0, 0, dp(12))
        })
        root.addView(styledButton("保存参数", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener {
                val threadValue = threadValues.getOrElse(threadSpinner.selectedItemPosition) { 0 }
                val contextValue = contextValues.getOrElse(contextSpinner.selectedItemPosition) { 2048 }
                val gpuLayerValue = gpuLayerValues.getOrElse(gpuLayerSpinner.selectedItemPosition) { 0 }
                val kvCacheValue = kvCacheValues.getOrElse(kvCacheSpinner.selectedItemPosition) { 0 }
                val flashValue = flashAttentionValues.getOrElse(flashAttentionSpinner.selectedItemPosition) { true }
                val draftName = draftNames.getOrElse(draftSpinner.selectedItemPosition) { "" }

                fun persistSettings(effectiveGpuLayers: Int) {
                    preferences.edit()
                        .putInt("inference_cpu_threads", threadValue)
                        .putInt("inference_context_size", contextValue)
                        .putInt("inference_gpu_layers", effectiveGpuLayers)
                        .putInt("inference_kv_cache_quantization", kvCacheValue)
                        .putBoolean("inference_gpu_flash_attention", flashValue)
                        .putString("inference_draft_model_filename", draftName)
                        .apply()
                    val loaded = generateReply != null
                    Toast.makeText(this@MainActivity, if (loaded) "已保存。请退出并重新加载模型使参数生效。" else "参数已保存，将在下次加载模型时生效。", Toast.LENGTH_LONG).show()
                    showInferenceSettingsScreen()
                }

                if (gpuLayerValue > 0) {
                    Toast.makeText(this@MainActivity, "正在验证 Vulkan 后端，再保存 GPU 参数……", Toast.LENGTH_SHORT).show()
                    lifecycleScope.launch {
                        val report = readVulkanGpuBackendReport()
                        if (hasVerifiedVulkanGpuBackend(report)) {
                            persistSettings(gpuLayerValue)
                        } else {
                            // Save other options, but never persist an unusable GPU request.
                            persistSettings(0)
                            Toast.makeText(this@MainActivity, "未检测到可用的 Vulkan GPU 后端，已将 GPU 层数设为 0（CPU）；其他参数已正常保存。", Toast.LENGTH_LONG).show()
                            AppDiagnostics.log(this@MainActivity, "WARN", "gpu_layer_setting_rejected", report.take(3000))
                        }
                    }
                } else {
                    persistSettings(0)
                }
            }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(10) })
        root.addView(TextView(this).apply {
            text = "已保存配置：CPU ${if (preferences.getInt("inference_cpu_threads", 0) == 0) "自动（当前有效值 ${configuredCpuThreads()} 线程）" else "${configuredCpuThreads()} 线程"} · 上下文 ${configuredContextSize()} tokens · GPU 请求 ${configuredGpuLayers()} 层 · KV ${if (configuredKvCacheQuantization() == 1) "Q8_0" else "F16"} · GPU FA ${if (configuredGpuFlashAttention()) "AUTO" else "关闭"} · 推测解码 ${preferences.getString("inference_draft_model_filename", "").orEmpty().ifBlank { "关闭" }}\n当前已加载模型：${loadedModelFileName?.let { modelDisplayName(File(modelDirectory, it)) } ?: "未加载"}"
            textSize = 12f; setTextColor(C_TEXT); setPadding(dp(10), dp(8), dp(10), dp(8)); background = rounded(C_PANEL, 14, C_STROKE_SOFT)
        })
    }

    private fun showMemoryStatusScreen() {
        val root = makeFeatureScreen("内存状态", ::showMoreFeaturesScreen)
        val view = TextView(this).apply {
            textSize = 12.5f; setTextColor(C_TEXT); setLineSpacing(dp(3).toFloat(), 1f); setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(C_PANEL, 18, C_STROKE_SOFT)
        }
        fun update() {
            val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            runCatching { manager?.getMemoryInfo(memoryInfo) }
            val processInfo = Debug.MemoryInfo()
            runCatching { Debug.getMemoryInfo(processInfo) }
            val selected = modelFile
            val nativeHeap = Debug.getNativeHeapAllocatedSize()
            view.text = buildString {
                append("系统可用内存：").append(if (memoryInfo.availMem > 0L) formatBytes(memoryInfo.availMem) else "未提供").append('\n')
                append("系统总内存：").append(if (memoryInfo.totalMem > 0L) formatBytes(memoryInfo.totalMem) else "未提供").append('\n')
                append("系统低内存标志：").append(if (memoryInfo.lowMemory) "是" else "否/未报告").append('\n')
                append("应用进程 PSS：").append(if (processInfo.totalPss > 0) formatBytes(processInfo.totalPss.toLong() * 1024L) else "未提供或为 0").append('\n')
                append("Native Heap 已分配：").append(formatBytes(nativeHeap)).append('\n')
                append("当前选中模型文件：").append(if (selected.isFile) formatBytes(selected.length()) else "尚未选择有效文件").append('\n')
                append("当前模型实例：").append(if (loadedModelFileName == selected.name) "此进程已加载" else "未确认加载").append('\n')
                append("上下文配置：").append(configuredContextSize()).append(" tokens；CPU 线程配置：").append(configuredCpuThreads()).append("\n\n")
                append("GPU 显存：当前接口不可直接读取，未估算。内存数据只用于提示；本页不会自动降低线程、上下文或生成长度，也不会切换模型或删除个人数据。PSS 是进程比例集大小，不等于纯私有内存。")
            }
        }
        root.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(styledButton("刷新内存状态", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply { setOnClickListener { update() } }, LinearLayout.LayoutParams(-1, dp(44)))
        update()
    }

    private fun getEngineStatusText(): String = buildString {
        if (!NativeLlamaEngine.isAvailable) {
            append("原生引擎状态：不可用\n")
            append(NativeLlamaEngine.statusReport())
        } else {
            append(NativeLlamaEngine.statusReport()).append("\n\n")
            append(NativeLlamaEngine.loadedModelReport(nativeModelHandle))
        }
    }

    private fun getSystemVersionText(): String = buildString {
        val packageInfo = runCatching { packageManager.getPackageInfo(packageName, 0) }.getOrNull()
        append("Android 版本：").append(Build.VERSION.RELEASE ?: "未知").append('\n')
        append("API 级别：").append(Build.VERSION.SDK_INT).append('\n')
        append("安全补丁级别：").append(if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "系统未公开此字段").append('\n')
        append("设备型号：").append(Build.MANUFACTURER.orEmpty()).append(' ').append(Build.MODEL.orEmpty()).append('\n')
        append("系统架构：").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\n')
        append("应用版本：").append(packageInfo?.versionName ?: "未知")
        if (packageInfo != null && Build.VERSION.SDK_INT >= 28) append(" (versionCode ").append(packageInfo.longVersionCode).append(')')
        append('\n').append("Vulkan 硬件级别功能：").append(if (packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)) "系统已报告" else "系统未报告").append('\n')
        if (Build.VERSION.SDK_INT >= 29) {
            append("Vulkan 硬件版本功能：").append(if (packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_VERSION)) "系统已报告" else "系统未报告").append('\n')
        }
        append("注意：系统功能标志不等于当前 Vulkan 后端已加载，也不代表当前模型正在 GPU 上运行。")
    }

    private fun refreshEngineAndSystem(engineView: TextView, systemStatusView: TextView?, fromButton: android.view.View?) {
        fromButton?.isEnabled = false
        engineView.text = "正在刷新原生引擎与后端状态…\n此操作仅检测当前 APK，不会启动模型推理。"
        lifecycleScope.launch {
            val engineReport = withContext(Dispatchers.IO) {
                runCatching {
                    NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
                    getEngineStatusText()
                }.getOrElse { "引擎状态读取失败：${it.javaClass.simpleName}: ${it.message.orEmpty()}" }
            }
            engineView.text = engineReport
            systemStatusView?.text = getSystemVersionText()
            fromButton?.isEnabled = true
        }
    }

    private fun showEngineCapabilityReport() {
        val report = buildString {
            append("主引擎：上游 llama.cpp v0.6.0；配置目标为 Android arm64-v8a。\n\n")
            append("计算路径：ARM CPU/NEON + GGML Vulkan 后端；模型加载时尝试按 GPU 层数卸载，失败会回退 CPU-only。\n\n")
            append("状态区会分别显示：原生 JNI 是否成功加载、后端是否构建/发现 Vulkan、系统是否枚举出 Vulkan 设备、当前模型句柄采用的 GPU 层配置。设备被枚举到不能单独证明 GPU 已参与当前推理。\n\n")
            append("输出通过原生 Token 回调逐步传给界面预览；取消请求会设置原生取消标志，并在下一次生成循环检查点停止。GPU 内核内正在执行的单次计算无法瞬间中止。\n\n")
            append("若状态显示原生引擎不可用，通常说明 APK 尚未通过配套工作流把 JNI、llama.cpp 和 Vulkan 后端打包进去，或运行设备/驱动不支持。构建成功也不等于实机性能已验证。")
        }
        AlertDialog.Builder(this).setTitle("推理引擎诊断报告").setMessage(report)
            .setPositiveButton("查看任务日志") { _, _ -> showTaskCenterScreen() }.setNegativeButton("返回", null).show()
    }

    private fun aiDisplayName(): String = preferences.getString("ai_name", "pls").orEmpty().trim().ifBlank { "pls" }

    private fun ensureModelSelection() {
        runCatching { if (!modelDirectory.exists()) modelDirectory.mkdirs() }
        val saved = preferences.getString("selected_model_file", "").orEmpty().let { File(it).name }
        if (saved.isNotBlank() && File(modelDirectory, saved).isFile) return
        val legacy = File(modelDirectory, "assistant-model.gguf")
        val firstModel = if (legacy.isFile) legacy else modelFiles().firstOrNull()
        preferences.edit().putString("selected_model_file", firstModel?.name.orEmpty()).apply()
    }

    private fun modelFiles(): List<File> = runCatching {
        modelDirectory.listFiles()?.filter { it.isFile && it.extension.equals("gguf", ignoreCase = true) }
            ?.sortedWith(compareByDescending<File> { it.lastModified() }.thenBy { it.name.lowercase(Locale.ROOT) })
            .orEmpty()
    }.getOrDefault(emptyList())

    private fun stripGgufSuffix(name: String): String = if (name.lowercase(Locale.ROOT).endsWith(".gguf")) name.dropLast(5) else name
    private fun modelDisplayName(file: File): String = stripGgufSuffix(file.name)
    private fun selectedModelName(): String = preferences.getString("selected_model_file", "").orEmpty()

    private fun buildModelManagerCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(C_PANEL, 20, C_STROKE_SOFT)
        }
        val selectedName = selectedModelName()
        val loadedName = loadedModelFileName
        card.addView(TextView(this).apply {
            text = "当前加载模型：${loadedName?.let { modelDisplayName(File(modelDirectory, it)) } ?: "尚未加载"}"
            textSize = 14f
            setTextColor(C_TEXT)
            setTypeface(null, Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        card.addView(TextView(this).apply {
            text = "待加载模型：${selectedName.takeIf { it.isNotBlank() }?.let { modelDisplayName(File(modelDirectory, it)) } ?: "未选择"}"
            textSize = 12f
            setTextColor(C_BLUE_TEXT)
            setPadding(0, 0, 0, dp(8))
        })
        selectedModelProfile()?.let { profile ->
            card.addView(TextView(this).apply {
                text = "已分析所选模型：${profile.architecture} · ${profile.quantizationHint}\n可用回答模式：${profile.modeLabels.joinToString(" / ")}\n${profile.notes}"
                textSize = 12f
                setTextColor(C_BLUE_TEXT)
                setLineSpacing(dp(2).toFloat(), 1f)
                setPadding(0, 0, 0, dp(9))
            })
        }
        card.addView(TextView(this).apply {
            text = "模型文件保存在本机。选择模型只会更改待加载项；如需切换正在运行的模型，请先在聊天页点「退出模型」。重命名或删除当前正在加载的文件前，也必须先退出模型。"
            textSize = 12f
            setTextColor(C_MUTED)
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(0, 0, 0, dp(9))
        })
        val files = modelFiles()
        if (files.isEmpty()) {
            card.addView(TextView(this).apply {
                text = "目前还没有导入模型。回到聊天页，点击「选择模型」导入 .gguf 文件。"
                textSize = 12.5f
                setTextColor(C_MUTED)
            })
            return card
        }
        files.forEach { file ->
            val rowCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = rounded(C_PANEL_2, 15, C_STROKE_SOFT)
            }
            val selected = file.name == selectedName
            val loaded = file.name == loadedName
            rowCard.addView(TextView(this).apply {
                text = modelDisplayName(file) + when {
                    loaded -> "  · 正在加载"
                    selected -> "  · 已选中"
                    else -> ""
                }
                textSize = 13.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(if (loaded) C_BLUE_BRIGHT else C_TEXT)
            })
            rowCard.addView(TextView(this).apply {
                text = "${formatBytes(file.length())}  ·  ${file.name}"
                textSize = 10.5f
                setTextColor(C_MUTED)
                setPadding(0, dp(3), 0, dp(7))
            })
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            actions.addView(styledButton(if (selected) "已选择" else "选择", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
                isEnabled = !selected
                setOnClickListener {
                    preferences.edit().putString("selected_model_file", file.name).apply()
                    showProfileScreen()
                    if (loadedModelFileName != null && loadedModelFileName != file.name) {
                        statusTextSafe("已选中「${modelDisplayName(file)}」。当前模型仍在运行；请回聊天页退出旧模型后再加载。")
                    }
                }
            }, LinearLayout.LayoutParams(0, dp(38), 1f))
            actions.addView(styledButton("重命名", C_PANEL, C_TEXT, C_STROKE_SOFT).apply {
                setOnClickListener { renameModel(file) }
            }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(6) })
            actions.addView(styledButton("删除", C_PANEL, C_MUTED, C_STROKE_SOFT).apply {
                setOnClickListener { deleteModel(file) }
            }, LinearLayout.LayoutParams(0, dp(38), 0.8f).apply { marginStart = dp(6) })
            rowCard.addView(actions)
            card.addView(rowCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        return card
    }

    private fun statusTextSafe(message: String) {
        if (::statusText.isInitialized) statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun renameModel(file: File) {
        if (isBusy || isModelTransferOrLoading) {
            statusTextSafe("当前正在处理任务，请稍后再管理模型。")
            return
        }
        if (loadedModelFileName == file.name || modelInferenceActive) {
            statusTextSafe("请先在聊天页退出当前加载的模型，再重命名这个文件。")
            return
        }
        val input = EditText(this).apply {
            setSingleLine(true)
            setText(modelDisplayName(file))
            setSelection(text.length)
            hint = "输入新的模型名称"
        }
        AlertDialog.Builder(this)
            .setTitle("重命名模型")
            .setMessage("只更改本机显示和文件名称，不会修改模型内部权重。")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val base = stripGgufSuffix(input.text.toString().trim())
                    .replace(Regex("""[\\/:*?"<>|]"""), "_").take(72).trim().trim('.')
                if (base.isBlank()) {
                    statusTextSafe("模型名称不能为空。")
                    return@setPositiveButton
                }
                val target = File(modelDirectory, "$base.gguf")
                if (target.exists() && target.absolutePath != file.absolutePath) {
                    statusTextSafe("已经存在同名模型，请换一个名称。")
                    return@setPositiveButton
                }
                if (!file.renameTo(target)) {
                    statusTextSafe("重命名失败，可能是存储权限或文件占用问题。")
                    return@setPositiveButton
                }
                if (selectedModelName() == file.name) preferences.edit().putString("selected_model_file", target.name).apply()
                showProfileScreen()
                statusTextSafe("模型已重命名为「${modelDisplayName(target)}」。")
            }.show()
    }

    private fun deleteModel(file: File) {
        if (isBusy || isModelTransferOrLoading) {
            statusTextSafe("当前正在处理任务，请稍后再删除模型。")
            return
        }
        if (loadedModelFileName == file.name || modelInferenceActive) {
            statusTextSafe("这个模型正在加载或运行，请先退出模型再删除。")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("删除本机模型？")
            .setMessage("将永久删除「${modelDisplayName(file)}」（${formatBytes(file.length())}）。此操作无法撤销。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                val wasSelected = selectedModelName() == file.name
                if (!file.delete()) {
                    statusTextSafe("删除失败，请检查文件是否被占用。")
                    return@setPositiveButton
                }
                if (wasSelected) {
                    val next = modelFiles().firstOrNull()
                    preferences.edit().putString("selected_model_file", next?.name.orEmpty()).apply()
                }
                showProfileScreen()
                statusTextSafe("模型文件已删除。")
            }.show()
    }

    private fun showPersonalizationScreen() {
        isProfileScreen = true
        isPersonalizationScreen = true
        isMoreFeaturesScreen = false
        val scroller = ScrollView(this).apply { setBackgroundColor(C_BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
        }
        scroller.addView(root)
        setContentView(scroller)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(styledButton("‹ 返回个人中心", C_PANEL_2, C_TEXT, C_STROKE).apply {
            setOnClickListener { showProfileScreen() }
        }, LinearLayout.LayoutParams(dp(132), dp(42)))
        top.addView(TextView(this).apply {
            text = "个性化与记忆"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
            setTextColor(C_TEXT)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(TextView(this).apply {
            text = "这些资料保存在手机本地，不绑定某个 AI 模型。更换兼容模型后，应用仍会把相关资料放进提示上下文。只在和问题相关时使用，不会没话找话地重复你的隐私。"
            textSize = 12.5f
            setTextColor(C_MUTED)
            setLineSpacing(dp(3).toFloat(), 1f)
            background = rounded(C_PANEL, 16, C_STROKE_SOFT)
            setPadding(dp(12), dp(11), dp(12), dp(11))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        // Category 1: personal basics
        root.addView(sectionLabel("① 日常资料"))
        val heightField = profileEditText(preferences.getString("personalization_height", "").orEmpty(), "身高，例如：169 cm")
        val weightField = profileEditText(preferences.getString("personalization_weight", "").orEmpty(), "体重，例如：55 kg")
        val bodyCard = personalizationSectionCard()
        bodyCard.addView(fieldLabel("身高（可选）"))
        bodyCard.addView(heightField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        bodyCard.addView(fieldLabel("体重（可选）"))
        bodyCard.addView(weightField, LinearLayout.LayoutParams(-1, -2))
        root.addView(bodyCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        // Category 2: tastes and routine
        root.addView(sectionLabel("② 兴趣爱好与日常喜好"))
        val interestsField = profileEditText(preferences.getString("personalization_interests", "").orEmpty(), "例如：AI、历史、英语、科技", multiline = true)
        val dailyField = profileEditText(preferences.getString("personalization_daily_preferences", "").orEmpty(), "例如：喜欢先听结论、偏好轻松聊天", multiline = true)
        val likesCard = personalizationSectionCard()
        likesCard.addView(fieldLabel("兴趣爱好"))
        likesCard.addView(interestsField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        likesCard.addView(fieldLabel("日常偏好与习惯"))
        likesCard.addView(dailyField, LinearLayout.LayoutParams(-1, -2))
        root.addView(likesCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        // Category 3: preferred interaction style and requests
        root.addView(sectionLabel("③ 对 AI 的要求与聊天风格"))
        val chatStyleField = profileEditText(preferences.getString("personalization_chat_preferences", "").orEmpty(), "例如：自然一点、有情绪回应、别太啰嗦", multiline = true)
        val requestsField = profileEditText(preferences.getString("personalization_user_requests", "").orEmpty(), "记录希望 AI 长期遵守的要求", multiline = true)
        val styleCard = personalizationSectionCard()
        styleCard.addView(fieldLabel("喜欢的交流方式"))
        styleCard.addView(chatStyleField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        styleCard.addView(fieldLabel("长期要求／不要做的事"))
        styleCard.addView(requestsField, LinearLayout.LayoutParams(-1, -2))
        root.addView(styleCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        // Category 4: memories. One line per memory; users can edit or remove any entry.
        root.addView(sectionLabel("④ 重要记忆"))
        root.addView(TextView(this).apply {
            text = "当你明确说‘记住’、‘以后请’或表达稳定偏好时，AI 可以把简短内容记在这里。你可以逐条编辑或删除。仅保存有用的文字，不会自动记录每一句闲聊。"
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(dp(2), 0, dp(2), dp(7))
        })
        val memoryField = profileEditText(loadPersonalMemories().joinToString("\n"), "每行一条重要记忆；不需要的内容删掉即可", multiline = true)
        memoryField.minLines = 5
        val memoryCard = personalizationSectionCard()
        memoryCard.addView(memoryField, LinearLayout.LayoutParams(-1, -2))
        root.addView(memoryCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        // New: auditable self-review journal, separated from verified memories.
        root.addView(sectionLabel("⑤ AI 错误复盘与新学习"))
        val learningRecords = LearningMemoryStore.load(preferences)
        val learningCard = personalizationSectionCard()
        learningCard.addView(CheckBox(this).apply {
            text = "开启错误复盘记录（仅本机保存）"
            textSize = 13f
            setTextColor(C_TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
            isChecked = preferences.getBoolean("learning_review_enabled", true)
            setOnCheckedChangeListener { _, checked -> preferences.edit().putBoolean("learning_review_enabled", checked).apply() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        learningCard.addView(TextView(this).apply {
            val verified = learningRecords.count { it.verified }
            val pending = learningRecords.size - verified
            text = "本地学习记录：${learningRecords.size} 条（已验证 $verified，待复核 $pending）\n记忆与学习记录估算文本大小：${formatBytes(LearningMemoryStore.storageBytes(preferences))}\n\n当你明确指出回答有误时，东巴壳会保存复盘线索。未经验证的内容不会直接当作正确知识塞给模型；你可以检查后标记为已验证，或删除记录。"
            textSize = 12f
            setTextColor(C_MUTED)
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        if (learningRecords.isEmpty()) {
            learningCard.addView(TextView(this).apply {
                text = "还没有自动复盘记录。遇到回答错误时，可以直接告诉东巴壳哪里不对。"
                textSize = 12f
                setTextColor(C_MUTED)
                setPadding(0, dp(8), 0, 0)
            })
        } else {
            learningRecords.takeLast(12).asReversed().forEach { record ->
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(9), dp(9), dp(9), dp(9))
                    background = rounded(C_PANEL_2, 13, C_STROKE_SOFT)
                }
                val stamp = java.text.SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(java.util.Date(record.createdAt))
                item.addView(TextView(this).apply {
                    text = "$stamp · ${record.kind} · ${if (record.verified) "已验证" else "待复核"}\n问题：${record.question.ifBlank { "（未关联上一问题）" }.take(180)}\n记录：${record.correction.take(240)}"
                    textSize = 12f
                    setTextColor(C_TEXT)
                    setLineSpacing(dp(2).toFloat(), 1f)
                })
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
                if (!record.verified) actions.addView(styledButton("✓ 标记已验证", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
                    setOnClickListener {
                        LearningMemoryStore.setVerified(preferences, record.id, true)
                        showPersonalizationScreen()
                    }
                }, LinearLayout.LayoutParams(0, dp(37), 1f).apply { marginEnd = dp(6) })
                actions.addView(styledButton("删除", C_PANEL, C_MUTED, C_STROKE_SOFT).apply {
                    setOnClickListener {
                        LearningMemoryStore.delete(preferences, record.id)
                        showPersonalizationScreen()
                    }
                }, LinearLayout.LayoutParams(dp(72), dp(37)))
                item.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
                learningCard.addView(item, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
        }
        learningCard.addView(styledButton("清空全部复盘记录", C_PANEL, C_MUTED, C_STROKE_SOFT).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("清空学习记录？")
                    .setMessage("只会删除复盘记录，不会删除聊天记录、模型文件或个人资料。")
                    .setNegativeButton("取消", null).setPositiveButton("清空") { _, _ ->
                        LearningMemoryStore.clear(preferences)
                        showPersonalizationScreen()
                    }.show()
            }
        }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(9) })
        root.addView(learningCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        // Category 6: optional location memory, opt-in and on-demand only.
        root.addView(sectionLabel("⑥ 位置与天气"))
        val locationCard = personalizationSectionCard()
        locationCard.addView(TextView(this).apply {
            text = "只有开启并授予 Android 定位权限后，应用才会在你主动询问天气或位置时按需定位。不会后台持续跟踪；天气查询会把坐标发送给天气服务。"
            textSize = 12f
            setTextColor(C_MUTED)
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(0, 0, 0, dp(8))
        })
        val rememberLocation = CheckBox(this).apply {
            text = "允许在我询问天气／位置时获取并保存当前位置"
            textSize = 13f
            setTextColor(C_TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
            isChecked = preferences.getBoolean("personalization_location_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                preferences.edit().putBoolean("personalization_location_enabled", checked).apply()
                if (!checked) clearSavedLocation()
                Toast.makeText(this@MainActivity, if (checked) "已开启按需定位，不会后台跟踪。" else "已关闭位置记忆并清除位置记录。", Toast.LENGTH_LONG).show()
            }
        }
        locationCard.addView(rememberLocation, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        val savedLocationLabel = preferences.getString("last_location_label", "").orEmpty()
        val savedLocationTime = preferences.getLong("last_location_time", 0L)
        locationCard.addView(TextView(this).apply {
            text = if (savedLocationLabel.isBlank()) "最近位置：尚未记录" else "最近位置：$savedLocationLabel\n记录时间：${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(java.util.Date(savedLocationTime))}"
            textSize = 12f
            setTextColor(C_BLUE_TEXT)
            setPadding(0, dp(4), 0, dp(5))
        })
        locationCard.addView(styledButton("清除已保存的位置", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener {
                clearSavedLocation()
                Toast.makeText(this@MainActivity, "已清除保存的位置", Toast.LENGTH_SHORT).show()
                showPersonalizationScreen()
            }
        }, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(locationCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        root.addView(styledButton("保存全部个性化设置", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener {
                preferences.edit()
                    .putString("personalization_height", heightField.text.toString().trim())
                    .putString("personalization_weight", weightField.text.toString().trim())
                    .putString("personalization_interests", interestsField.text.toString().trim())
                    .putString("personalization_daily_preferences", dailyField.text.toString().trim())
                    .putString("personalization_chat_preferences", chatStyleField.text.toString().trim())
                    .putString("personalization_user_requests", requestsField.text.toString().trim())
                    .apply()
                savePersonalMemories(memoryField.text.toString().lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList())
                Toast.makeText(this@MainActivity, "个性化资料和重要记忆已保存在本机 ✨", Toast.LENGTH_LONG).show()
                showPersonalizationScreen()
            }
        }, LinearLayout.LayoutParams(-1, dp(49)))

        root.addView(styledButton("清除全部重要记忆", C_PANEL, C_MUTED, C_STROKE_SOFT).apply {
            setOnClickListener {
                savePersonalMemories(emptyList())
                Toast.makeText(this@MainActivity, "重要记忆已清除", Toast.LENGTH_SHORT).show()
                showPersonalizationScreen()
            }
        }, LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(8) })
    }

    private fun personalizationSectionCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rounded(C_PANEL, 19, C_STROKE_SOFT)
    }

    private fun loadPersonalMemories(): List<String> {
        return try {
            val arr = JSONArray(preferences.getString("personalization_memories", "[]").orEmpty())
            (0 until arr.length()).mapNotNull { arr.optString(it).trim().takeIf { value -> value.isNotBlank() } }.takeLast(30)
        } catch (_: Exception) { emptyList() }
    }

    private fun savePersonalMemories(items: List<String>) {
        val clean = items.map { it.trim().replace(Regex("\\s+"), " ").take(220) }
            .filter { it.isNotBlank() }.distinctBy { it.lowercase(Locale.ROOT) }.takeLast(30)
        val array = JSONArray()
        clean.forEach { array.put(it) }
        preferences.edit().putString("personalization_memories", array.toString()).apply()
    }

    private fun maybeRememberUserMessage(message: String) {
        val value = message.trim()
        if (value.isBlank() || value.length > 500) return
        val cues = listOf("请记住", "记住我", "记一下", "记下来", "帮我记", "以后都", "以后请", "不要再", "别再", "我喜欢", "我不喜欢", "我更喜欢", "我的身高是", "我的体重是", "我身高是", "我体重是", "我的要求是", "我偏好", "我习惯", "请一直", "我希望你", "我不希望你")
        if (cues.none { value.contains(it, ignoreCase = true) }) return
        val cleaned = value.replace(Regex("^(请你?|帮我)?(记住|记一下|记下来|记录一下)[：:，,\\s]*"), "").trim().ifBlank { value }
        val current = loadPersonalMemories().toMutableList()
        if (current.none { it.equals(cleaned, ignoreCase = true) }) {
            current.add(cleaned.take(220))
            savePersonalMemories(current)
            runOnUiThread {
                if (::statusText.isInitialized) statusText.text = "🧠 已把这条重要偏好保存到「个人中心 → 个性化 → 重要记忆」"
                Toast.makeText(this, "已保存到个性化记忆，可随时查看或删除", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun maybeRecordCorrection(message: String) {
        if (!preferences.getBoolean("learning_review_enabled", true)) return
        val q = message.trim()
        if (q.length !in 2..700) return
        val signals = listOf("你错了", "你说错了", "不对", "不是这样的", "刚才不准确", "回答有误", "你理解错了", "我说的是", "正确答案是", "应该是", "你搞错了", "这个结果不对")
        if (signals.none { q.contains(it, ignoreCase = true) }) return
        val previous = history.lastOrNull()
        val relatedQuestion = previous?.first.orEmpty()
        val correction = q.removePrefix("不对").trim().ifBlank { q }
        val added = LearningMemoryStore.addPending(preferences, "用户纠正", relatedQuestion, correction)
        if (added) runOnUiThread {
            if (::statusText.isInitialized) statusText.text = "已保存一条待复核的纠正记录；验证后才会作为经验提供给模型。"
            Toast.makeText(this, "已记录错误复盘，可在「个性化与记忆」中检查", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearSavedLocation() {
        preferences.edit().remove("last_location_label").remove("last_location_lat").remove("last_location_lon").remove("last_location_time").apply()
    }

    private fun loadSavedSessions() {
        sessions.clear()
        try {
            if (!sessionsFile.exists()) return
            val array = JSONArray(sessionsFile.readText(Charsets.UTF_8))
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val messagesJson = obj.optJSONArray("messages") ?: JSONArray()
                val messages = mutableListOf<ChatLine>()
                for (j in 0 until messagesJson.length()) {
                    val msg = messagesJson.optJSONObject(j) ?: continue
                    messages.add(ChatLine(msg.optString("who", ""), msg.optString("message", ""), msg.optBoolean("isUser", false), msg.optString("reasoning", "").take(4000)))
                }
                if (messages.any { it.isUser }) {
                    sessions.add(ChatSession(obj.optString("id", System.currentTimeMillis().toString() + i), obj.optString("title", "历史话题"), obj.optLong("createdAt", System.currentTimeMillis()), messages))
                }
            }
        } catch (_: Exception) {
            // A damaged history file should not prevent the assistant from starting.
        }
    }

    private fun saveSessions() {
        try {
            val array = JSONArray()
            sessions.filter { session -> session.messages.any { it.isUser } }.takeLast(100).forEach { session ->
                val obj = JSONObject()
                obj.put("id", session.id)
                obj.put("title", session.title)
                obj.put("createdAt", session.createdAt)
                val messages = JSONArray()
                session.messages.forEach { line ->
                    val msg = JSONObject()
                    msg.put("who", line.who)
                    msg.put("message", line.message)
                    msg.put("isUser", line.isUser)
                    if (line.reasoning.isNotBlank()) msg.put("reasoning", line.reasoning.take(4000))
                    messages.put(msg)
                }
                obj.put("messages", messages)
                array.put(obj)
            }
            sessionsFile.writeText(array.toString(), Charsets.UTF_8)
        } catch (_: Exception) {
            // Keep chatting even if storage is temporarily unavailable.
        }
    }

    private fun createNewConversation(showWelcome: Boolean = true) {
        if (activeQuestionJob != null) {
            interruptActiveResponse("已创建新话题，上一条回答已停止。")
        }
        val session = ChatSession(System.currentTimeMillis().toString(), "新话题 · ${java.text.SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(java.util.Date())}", System.currentTimeMillis())
        sessions.add(session)
        while (sessions.size > 100) sessions.removeAt(0)
        currentSessionId = session.id
        transcript = session.messages
        history.clear()
        saveSessions()
        if (::chatMessages.isInitialized) {
            buildInterface()
            if (showWelcome) Toast.makeText(this, "已创建新话题，旧聊天会保留在历史记录里。", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openConversation(id: String) {
        val session = sessions.firstOrNull { it.id == id } ?: return
        if (activeQuestionJob != null) {
            interruptActiveResponse("已切换历史话题，上一条回答已停止。")
        }
        currentSessionId = session.id
        transcript = session.messages
        history.clear()
        var lastQuestion: String? = null
        transcript.forEach { line ->
            if (line.isUser) lastQuestion = line.message
            else if (lastQuestion != null && !line.who.contains("思考") && !line.who.contains("来源") && !line.who.contains("搜索") && !line.who.contains("提示") && !line.who.contains("失败")) {
                history.add(lastQuestion!! to line.message)
                lastQuestion = null
            }
        }
        saveSessions()
        buildInterface()
    }

    private fun showConversationList() {
        isProfileScreen = true
        isPersonalizationScreen = false
        val scroller = ScrollView(this).apply { setBackgroundColor(C_BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(20))
        }
        scroller.addView(root)
        setContentView(scroller)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(styledButton("‹ 返回聊天", C_PANEL_2, C_TEXT, C_STROKE).apply { setOnClickListener { buildInterface() } }, LinearLayout.LayoutParams(dp(112), dp(42)))
        top.addView(TextView(this).apply {
            text = "历史话题"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(C_TEXT)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        root.addView(TextView(this).apply {
            text = "支持继续聊天、重命名、批量选择与删除。历史记录只保存在这台手机。"
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(dp(2), dp(2), dp(2), dp(10))
        })
        root.addView(styledButton("＋ 创建新话题", C_BLUE, Color.WHITE, C_BLUE_BRIGHT).apply {
            setOnClickListener { historySelectMode = false; selectedSessionIds.clear(); createNewConversation() }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(8) })

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actionRow.addView(styledButton(if (historySelectMode) "取消多选" else "☑ 多选管理", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener {
                historySelectMode = !historySelectMode
                selectedSessionIds.clear()
                showConversationList()
            }
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actionRow.addView(styledButton("全选", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener {
                historySelectMode = true
                selectedSessionIds.clear()
                selectedSessionIds.addAll(sessions.map { it.id })
                showConversationList()
            }
        }, LinearLayout.LayoutParams(0, dp(42), 0.7f).apply { marginStart = dp(6) })
        actionRow.addView(styledButton("删除所选 (${selectedSessionIds.size})", C_PANEL, if (selectedSessionIds.isEmpty()) C_MUTED else Color.rgb(255, 140, 160), C_STROKE_SOFT).apply {
            isEnabled = selectedSessionIds.isNotEmpty()
            setOnClickListener { confirmDeleteSelectedSessions() }
        }, LinearLayout.LayoutParams(0, dp(42), 1.15f).apply { marginStart = dp(6) })
        root.addView(actionRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        if (sessions.isEmpty()) {
            root.addView(TextView(this).apply { text = "还没有保存的话题。开始聊天后，它们会自动出现在这里。"; setTextColor(C_TEXT); textSize = 14f })
        } else {
            sessions.asReversed().forEach { session ->
                val itemRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                if (historySelectMode) {
                    val check = CheckBox(this).apply {
                        buttonTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
                        isChecked = selectedSessionIds.contains(session.id)
                        setOnCheckedChangeListener { _, checked ->
                            if (checked) selectedSessionIds.add(session.id) else selectedSessionIds.remove(session.id)
                            showConversationList()
                        }
                    }
                    itemRow.addView(check, LinearLayout.LayoutParams(dp(38), -2))
                }
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(13), dp(12), dp(13), dp(12))
                    background = rounded(C_PANEL, 17, if (session.id == currentSessionId) C_BLUE_BRIGHT else C_STROKE_SOFT)
                    setOnClickListener {
                        if (historySelectMode) {
                            if (selectedSessionIds.contains(session.id)) selectedSessionIds.remove(session.id) else selectedSessionIds.add(session.id)
                            showConversationList()
                        } else {
                            historySelectMode = false
                            selectedSessionIds.clear()
                            openConversation(session.id)
                        }
                    }
                }
                card.addView(TextView(this).apply {
                    text = session.title
                    textSize = 15f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(C_TEXT)
                })
                card.addView(TextView(this).apply {
                    val date = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(java.util.Date(session.createdAt))
                    text = "$date · ${session.messages.count { it.isUser }} 条用户消息${if (session.id == currentSessionId) " · 当前话题" else ""}"
                    textSize = 11f
                    setTextColor(C_MUTED)
                    setPadding(0, dp(5), 0, 0)
                })
                itemRow.addView(card, LinearLayout.LayoutParams(0, -2, 1f))
                itemRow.addView(styledButton("重命名", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
                    setOnClickListener { renameConversation(session) }
                }, LinearLayout.LayoutParams(dp(76), dp(42)).apply { marginStart = dp(6) })
                root.addView(itemRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(styledButton("清除全部历史话题", C_PANEL, C_MUTED, C_STROKE_SOFT).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("清除全部历史话题？")
                    .setMessage("这会删除本机保存的所有历史话题，无法撤销。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("全部删除") { _, _ ->
                        sessions.clear()
                        selectedSessionIds.clear()
                        historySelectMode = false
                        currentSessionId = ""
                        createNewConversation(showWelcome = false)
                        showConversationList()
                    }.show()
            }
        }, LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(12) })
    }

    private fun renameConversation(session: ChatSession) {
        val input = EditText(this).apply {
            setText(session.title)
            setSelection(text.length)
            hint = "输入新的话题名称"
            setTextColor(C_TEXT)
            setHintTextColor(C_MUTED)
        }
        val container = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle("重命名话题")
            .setView(container)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val name = input.text.toString().trim().replace(Regex("\\s+"), " ").take(50)
                if (name.isNotBlank()) {
                    session.title = name
                    saveSessions()
                    showConversationList()
                    Toast.makeText(this, "话题名称已更新", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun confirmDeleteSelectedSessions() {
        val toDelete = selectedSessionIds.toSet()
        if (toDelete.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("删除所选话题？")
            .setMessage("将删除 ${toDelete.size} 个话题，无法撤销。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                val deletingCurrent = currentSessionId in toDelete
                sessions.removeAll { it.id in toDelete }
                selectedSessionIds.clear()
                historySelectMode = false
                if (deletingCurrent) {
                    currentSessionId = ""
                    createNewConversation(showWelcome = false)
                } else {
                    saveSessions()
                }
                showConversationList()
                Toast.makeText(this, "已删除 ${toDelete.size} 个话题", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTypeface(null, Typeface.BOLD)
        setTextColor(C_TEXT)
        setPadding(dp(3), dp(2), dp(3), dp(8))
    }

    private fun fieldLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(C_MUTED)
        setPadding(dp(2), 0, 0, dp(5))
    }

    private fun profileEditText(value: String, hintText: String, multiline: Boolean = false): EditText = EditText(this).apply {
        setText(value)
        hint = hintText
        textSize = 14f
        setTextColor(C_TEXT)
        setHintTextColor(C_MUTED)
        background = rounded(C_BG, 13, C_STROKE_SOFT)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (multiline) { minLines = 3; maxLines = 6 } else { minLines = 1; maxLines = 2 }
    }

    private fun createAvatarView(aiAvatar: Boolean, sizeDp: Int): View {
        if (aiAvatar) {
            val custom = if (aiAvatarFile.exists() && aiAvatarFile.length() > 0L) {
                if (aiAvatarBitmapCache == null) aiAvatarBitmapCache = decodeImage(aiAvatarFile)
                aiAvatarBitmapCache
            } else null
            return ImageView(this).apply {
                if (custom != null) setImageBitmap(custom) else setImageResource(R.drawable.ai_avatar)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = oval(C_BLUE_BRIGHT)
                clipToOutline = true
                outlineProvider = ViewOutlineProvider.BACKGROUND
                contentDescription = "${aiDisplayName()} 头像"
            }
        }
        if (userAvatarFile.exists() && userAvatarFile.length() > 0L) {
            if (userAvatarBitmapCache == null) userAvatarBitmapCache = decodeUserAvatar()
            val bitmap = userAvatarBitmapCache
            if (bitmap != null) {
                return ImageView(this).apply {
                    setImageBitmap(bitmap)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = oval(C_BLUE_BRIGHT)
                    clipToOutline = true
                    outlineProvider = ViewOutlineProvider.BACKGROUND
                    contentDescription = "我的头像"
                }
            }
        }
        val nick = preferences.getString("profile_name", "我").orEmpty().trim().ifBlank { "我" }
        return TextView(this).apply {
            text = nick.take(1)
            textSize = (sizeDp * 0.42f).coerceAtLeast(18f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = ovalGradient(C_BLUE, C_PURPLE)
            contentDescription = "我的默认头像"
        }
    }

    private fun decodeUserAvatar(): Bitmap? = decodeImage(userAvatarFile)

    private fun decodeImage(file: File): Bitmap? {
        if (!file.exists()) return null
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, options)
        var sample = 1
        while (options.outWidth / sample > 800 || options.outHeight / sample > 800) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun showAvatarSourceChooser(forAi: Boolean) {
        AlertDialog.Builder(this)
            .setTitle(if (forAi) "选择 AI 头像来源" else "选择个人头像来源")
            .setItems(arrayOf("系统相册／照片选择器", "系统文件选择器（原有方式）")) { _, which ->
                when (which) {
                    0 -> if (forAi) chooseAiAvatarFromGallery.launch("image/*") else chooseUserAvatarFromGallery.launch("image/*")
                    1 -> if (forAi) chooseAiAvatar.launch(arrayOf("image/*")) else chooseUserAvatar.launch(arrayOf("image/*"))
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showAvatarCrop(uri: Uri, forAi: Boolean) {
        lifecycleScope.launch {
            var source: Bitmap? = null
            try {
                source = withContext(Dispatchers.IO) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("无法识别这张图片，请换一张图片试试。")
                    var sample = 1
                    while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                    contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                    } ?: error("读取图片失败")
                }
                val original = source ?: error("读取图片失败")
                val cropView = AvatarCropView(this@MainActivity, original)
                val container = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(8), dp(16), dp(4))
                    addView(cropView, LinearLayout.LayoutParams(-1, dp(300)))
                    addView(TextView(this@MainActivity).apply {
                        text = "拖动图片调整位置；用下方滑块缩放。保存后会裁成正方形头像。"
                        textSize = 12f
                        setTextColor(C_MUTED)
                        gravity = Gravity.CENTER
                        setPadding(0, dp(8), 0, dp(4))
                    }, LinearLayout.LayoutParams(-1, -2))
                    val zoom = SeekBar(this@MainActivity).apply {
                        max = 200
                        progress = 0
                        setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                                cropView.setZoom(1f + progress / 100f)
                            }
                            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                        })
                    }
                    addView(zoom, LinearLayout.LayoutParams(-1, dp(42)))
                }
                val dialog = AlertDialog.Builder(this@MainActivity)
                    .setTitle("裁剪头像")
                    .setView(container)
                    .setNegativeButton("取消", null)
                    .setNeutralButton("重新居中", null)
                    .setPositiveButton("使用这张头像", null)
                    .create()
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                        cropView.resetCrop()
                        (container.getChildAt(2) as? SeekBar)?.progress = 0
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val cropped = try { cropView.makeCroppedBitmap(512) } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "裁剪失败：${e.message ?: "请重新选择图片"}", Toast.LENGTH_LONG).show()
                            return@setOnClickListener
                        }
                        dialog.dismiss()
                        saveAvatarBitmap(cropped, forAi)
                    }
                }
                dialog.setOnDismissListener { if (!original.isRecycled) original.recycle() }
                dialog.show()
            } catch (e: Exception) {
                source?.takeIf { !it.isRecycled }?.recycle()
                Toast.makeText(this@MainActivity, "头像导入失败：${e.message ?: "请换一张图片"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveAvatarBitmap(cropped: Bitmap, forAi: Boolean) {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val target = if (forAi) aiAvatarFile else userAvatarFile
                    target.outputStream().use { cropped.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                }
                if (forAi) {
                    aiAvatarBitmapCache?.recycle()
                    aiAvatarBitmapCache = null
                } else {
                    userAvatarBitmapCache?.recycle()
                    userAvatarBitmapCache = null
                }
                Toast.makeText(this@MainActivity, if (forAi) "AI 头像已裁剪并更新" else "个人头像已裁剪并更新", Toast.LENGTH_SHORT).show()
                if (isProfileScreen) showProfileScreen() else buildInterface()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "保存头像失败：${e.message ?: "请重试"}", Toast.LENGTH_LONG).show()
            } finally {
                if (!cropped.isRecycled) cropped.recycle()
            }
        }
    }

    private fun styledButton(label: String, fill: Int, textColor: Int, stroke: Int): Button {
        return Button(this).apply {
            text = label
            textSize = 11.5f
            setTextColor(textColor)
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(fill, 14, stroke)
            stateListAnimator = null
            elevation = 0f
            minimumHeight = 0
            minHeight = 0
            setPadding(dp(4), dp(3), dp(4), dp(3))
        }
    }

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }
    }

    private fun roundedGradient(top: Int, bottom: Int, radiusDp: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable {
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }
    }

    private fun oval(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(dp(2), C_BLUE_BRIGHT)
    }

    private fun ovalGradient(first: Int, second: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(first, second)).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(2), C_BLUE_BRIGHT)
    }

    private fun currentModelModeLabels(): List<String> = (loadedModelProfile ?: selectedModelProfile())?.modeLabels ?: listOf("快速", "详细回答")

    private fun selectedModelProfile(): ModelProfile? {
        val file = File(modelDirectory, File(selectedModelName()).name)
        return readCachedModelProfile(file)
    }

    private fun readCachedModelProfile(file: File): ModelProfile? {
        if (!file.isFile) return null
        val saved = preferences.getString("model_profile_${file.name}", null)
        if (saved.isNullOrBlank()) return null
        return runCatching {
            val o = JSONObject(saved)
            if (o.optLong("modelBytes", -1L) != file.length() || o.optLong("fileLastModified", -1L) != file.lastModified()) return@runCatching null
            ModelProfile(
                displayName = o.optString("displayName", file.nameWithoutExtension),
                architecture = o.optString("architecture", "未知架构"),
                quantizationHint = o.optString("quantizationHint", "未知"),
                supportsReasoningTemplate = o.optBoolean("supportsReasoningTemplate", false),
                modelBytes = o.optLong("modelBytes", file.length()),
                notes = o.optString("notes", "未分析"),
                ggufVersion = o.optLong("ggufVersion", 0L),
                tensorCount = o.optLong("tensorCount", 0L),
                metadataCount = o.optLong("metadataCount", 0L),
                tensorQuantizationSummary = o.optString("tensorQuantizationSummary", ""),
                parameterCount = if (o.has("parameterCount") && !o.isNull("parameterCount")) o.optLong("parameterCount") else null,
                tokenizerModel = o.optString("tokenizerModel", ""),
                hasChatTemplate = o.optBoolean("hasChatTemplate", false)
            )
        }.getOrNull()
    }

    private fun saveModelProfile(file: File, profile: ModelProfile) {
        val obj = JSONObject().put("displayName", profile.displayName).put("architecture", profile.architecture)
            .put("quantizationHint", profile.quantizationHint).put("supportsReasoningTemplate", profile.supportsReasoningTemplate)
            .put("modelBytes", profile.modelBytes).put("notes", profile.notes).put("fileLastModified", file.lastModified())
            .put("ggufVersion", profile.ggufVersion).put("tensorCount", profile.tensorCount).put("metadataCount", profile.metadataCount)
            .put("tensorQuantizationSummary", profile.tensorQuantizationSummary)
            .put("parameterCount", profile.parameterCount ?: JSONObject.NULL)
            .put("tokenizerModel", profile.tokenizerModel).put("hasChatTemplate", profile.hasChatTemplate)
        preferences.edit().putString("model_profile_${file.name}", obj.toString()).apply()
    }

    private fun updateModeButton() {
        if (!::modeButton.isInitialized) return
        val labels = currentModelModeLabels()
        if (responseModeIndex >= labels.size) responseModeIndex = labels.lastIndex.coerceAtLeast(0)
        fastMode = responseModeIndex == 0
        modeButton.text = "🧠 ${labels[responseModeIndex]}"
    }

    private fun updateSearchButton() {
        if (!::searchButton.isInitialized) return
        searchButton.text = if (webSearchEnabled) "🌐 联网搜索：开" else "🌐 联网搜索：关"
        searchButton.background = rounded(if (webSearchEnabled) C_BLUE_DARK else C_PANEL, 14, if (webSearchEnabled) C_BLUE else C_STROKE_SOFT)
        searchButton.setTextColor(if (webSearchEnabled) Color.WHITE else C_MUTED)
    }

    private fun updateVoiceButton() {
        if (!::voiceButton.isInitialized) return
        voiceButton.text = if (voiceEnabled) "🔊 自动朗读：开" else "🔇 自动朗读：关"
        voiceButton.background = rounded(if (voiceEnabled) C_BLUE_DARK else C_PANEL, 14, if (voiceEnabled) C_BLUE else C_STROKE_SOFT)
        voiceButton.setTextColor(if (voiceEnabled) Color.WHITE else C_MUTED)
    }

    private fun initialiseSpeech() {
        speechEngine = TextToSpeech(this) { result ->
            val engine = speechEngine
            if (result == TextToSpeech.SUCCESS && engine != null) {
                runCatching { engine.setLanguage(Locale.SIMPLIFIED_CHINESE) }
                offlineChineseVoices = engine.voices.orEmpty()
                    .filter { it.locale.language.equals("zh", true) && !it.isNetworkConnectionRequired }
                    .sortedBy { it.name.lowercase(Locale.ROOT) }
                val preferredName = preferences.getString("speech_voice_name", "").orEmpty()
                val voice = offlineChineseVoices.firstOrNull { it.name == preferredName } ?: offlineChineseVoices.firstOrNull()
                speechReady = voice?.let { selected ->
                    runCatching { engine.setVoice(selected) == TextToSpeech.SUCCESS }.getOrDefault(false)
                } ?: false
                applySavedSpeechTuning()
                runOnUiThread {
                    if (voiceEnabled && !speechReady && ::statusText.isInitialized) {
                        statusText.text = "没有找到无需联网的中文语音。打开「语音设置」进入系统文字转语音设置，安装离线中文语音后即可离线朗读。"
                    } else if (speechReady && ::statusText.isInitialized) {
                        statusText.text = "本地离线中文语音已就绪：${voice?.name ?: "默认音色"}。"
                    }
                }
            } else {
                speechReady = false
                runOnUiThread {
                    if (::statusText.isInitialized) statusText.text = "系统文字转语音引擎不可用，请检查手机的文字转语音设置。"
                }
            }
        }
    }

    private fun applySavedSpeechTuning() {
        val engine = speechEngine ?: return
        speechVolume = preferences.getFloat("speech_volume", 1.0f).coerceIn(0f, 1f)
        engine.setSpeechRate(preferences.getFloat("speech_speed", 1.0f).coerceIn(0.5f, 2.0f))
        engine.setPitch(preferences.getFloat("speech_pitch", 1.0f).coerceIn(0.5f, 2.0f))
    }

    private fun restorePersistedSpeechSettings() {
        val engine = speechEngine ?: return
        val savedVoice = preferences.getString("speech_voice_name", "").orEmpty()
        val voice = offlineChineseVoices.firstOrNull { it.name == savedVoice } ?: offlineChineseVoices.firstOrNull()
        speechReady = voice?.let { selected ->
            runCatching { engine.setVoice(selected) == TextToSpeech.SUCCESS }.getOrDefault(false)
        } ?: false
        applySavedSpeechTuning()
    }

    private fun stopSpeechPlayback() {
        speechEngine?.stop()
        activeSpeechId = null
        activeSpeechButton?.text = "▶ 朗读本条"
        activeSpeechButton = null
    }

    private fun speakAnswer(text: String) {
        // Automatic playback must never fall back to a network voice or nag on every reply.
        if (!voiceEnabled || !speechReady) return
        speakText(text, "auto-${System.nanoTime()}", null)
    }

    private fun speakText(text: String, utteranceId: String, button: Button?) {
        if (!speechReady || speechEngine == null) {
            Toast.makeText(this, "暂时没有可用的离线中文音色。点「语音设置」安装/选择系统本地语音。", Toast.LENGTH_LONG).show()
            return
        }
        stopSpeechPlayback()
        val spoken = text.replace(Regex("https?://\\S+"), "网页链接").take(3000)
        val volume = speechVolume.coerceIn(0f, 1f)
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume) }
        activeSpeechId = utteranceId
        activeSpeechButton = button
        button?.text = "■ 停止朗读"
        val engine = speechEngine ?: return
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { runOnUiThread { if (activeSpeechId == utteranceId) stopSpeechPlayback() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { runOnUiThread { if (activeSpeechId == utteranceId) stopSpeechPlayback() } }
            override fun onError(utteranceId: String?, errorCode: Int) { runOnUiThread { if (activeSpeechId == utteranceId) stopSpeechPlayback() } }
        })
        val result = engine.speak(spoken, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (result == TextToSpeech.ERROR) {
            stopSpeechPlayback()
            Toast.makeText(this, "本地语音合成失败，请到语音设置检查音色。", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showVoiceSetupDialog() {
        AlertDialog.Builder(this)
            .setTitle("需要离线中文语音")
            .setMessage("为了保证完全离线朗读，东巴壳只使用系统标记为「无需网络」的中文语音，不会改用联网音色。你可以打开系统文字转语音设置，下载/安装一个离线中文语音包。安装完成后回到本页，再打开语音设置即可。")
            .setNegativeButton("稍后", null)
            .setPositiveButton("打开系统语音设置") { _, _ ->
                runCatching { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                    .onFailure { Toast.makeText(this, "请在系统设置中搜索「文字转语音输出」", Toast.LENGTH_LONG).show() }
            }.show()
    }

    private fun showVoiceSettingsDialog() {
        val engine = speechEngine
        if (engine == null) {
            showVoiceSetupDialog()
            return
        }
        offlineChineseVoices = engine.voices.orEmpty()
            .filter { it.locale.language.equals("zh", true) && !it.isNetworkConnectionRequired }
            .sortedBy { it.name.lowercase(Locale.ROOT) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val scroller = ScrollView(this)
        scroller.addView(root)
        root.addView(TextView(this).apply {
            text = "只显示本机无需网络的中文音色。不同音色支持的音质与可调范围由语音引擎决定。"
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(0, 0, 0, dp(10))
        })
        val voiceSpinner = Spinner(this)
        val voiceNames = offlineChineseVoices.map { "${it.name} · ${it.locale.displayName}" }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, if (voiceNames.isEmpty()) listOf("未发现离线中文音色") else voiceNames)
        val savedVoice = preferences.getString("speech_voice_name", "").orEmpty()
        val selectedIndex = offlineChineseVoices.indexOfFirst { it.name == savedVoice }.let { if (it < 0) 0 else it }
        if (voiceNames.isNotEmpty()) voiceSpinner.setSelection(selectedIndex)
        root.addView(fieldLabel("本地音色 / 声线气质"))
        root.addView(voiceSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })

        fun addTuning(initial: Int, valueLabel: (Int) -> String): SeekBar {
            val labelView = TextView(this).apply { setTextColor(C_TEXT); textSize = 13f; text = valueLabel(initial); setPadding(0, dp(5), 0, dp(2)) }
            root.addView(labelView)
            val seek = SeekBar(this).apply { max = 100; progress = initial }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { labelView.text = valueLabel(progress) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
            root.addView(seek, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(4) })
            return seek
        }
        val speedSeek = addTuning(((preferences.getFloat("speech_speed", 1f) - 0.5f) / 1.5f * 100).toInt().coerceIn(0, 100)) { "语速：%.2f×".format(Locale.CHINA, 0.5f + it / 100f * 1.5f) }
        val pitchSeek = addTuning(((preferences.getFloat("speech_pitch", 1f) - 0.5f) / 1.5f * 100).toInt().coerceIn(0, 100)) { "音调：%.2f×".format(Locale.CHINA, 0.5f + it / 100f * 1.5f) }
        val volumeSeek = addTuning((preferences.getFloat("speech_volume", 1f) * 100).toInt().coerceIn(0, 100)) { "音量：$it%" }
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        presetRow.addView(styledButton("温柔", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { speedSeek.progress = 26; pitchSeek.progress = 27 }
        }, LinearLayout.LayoutParams(0, dp(38), 1f))
        presetRow.addView(styledButton("自然", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { speedSeek.progress = 33; pitchSeek.progress = 33 }
        }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        presetRow.addView(styledButton("活泼", C_PANEL_2, C_TEXT, C_STROKE_SOFT).apply {
            setOnClickListener { speedSeek.progress = 43; pitchSeek.progress = 42 }
        }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        root.addView(fieldLabel("快速气质预设（仍可手动微调）"))
        root.addView(presetRow, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(6) })
        root.addView(styledButton("打开系统语音设置 / 安装离线中文语音", C_BLUE_DARK, Color.WHITE, C_BLUE).apply {
            setOnClickListener {
                runCatching { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                    .onFailure { Toast.makeText(this@MainActivity, "请在系统设置中搜索「文字转语音输出」", Toast.LENGTH_LONG).show() }
            }
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("离线语音设置")
            .setView(scroller)
            .setNegativeButton("关闭", null)
            .setNeutralButton("测试朗读", null)
            .setPositiveButton("保存设置", null)
            .create()
        dialog.setOnDismissListener {
            stopSpeechPlayback()
            restorePersistedSpeechSettings()
        }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                if (offlineChineseVoices.isEmpty()) {
                    showVoiceSetupDialog()
                } else {
                    val voice = offlineChineseVoices[voiceSpinner.selectedItemPosition.coerceIn(0, offlineChineseVoices.lastIndex)]
                    applySpeechTuning(voice, speedSeek.progress, pitchSeek.progress, volumeSeek.progress, false)
                    speakText("你好呀，我是东巴壳。现在正在使用本地离线语音。", "test-${System.nanoTime()}", null)
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (offlineChineseVoices.isEmpty()) {
                    dialog.dismiss()
                    showVoiceSetupDialog()
                } else {
                    val voice = offlineChineseVoices[voiceSpinner.selectedItemPosition.coerceIn(0, offlineChineseVoices.lastIndex)]
                    applySpeechTuning(voice, speedSeek.progress, pitchSeek.progress, volumeSeek.progress, true)
                    dialog.dismiss()
                    Toast.makeText(this, "离线语音设置已保存", Toast.LENGTH_SHORT).show()
                }
            }
        }
        dialog.show()
    }

    private fun applySpeechTuning(voice: Voice, speedProgress: Int, pitchProgress: Int, volumeProgress: Int, persist: Boolean) {
        val speed = (0.5f + speedProgress / 100f * 1.5f).coerceIn(0.5f, 2f)
        val pitch = (0.5f + pitchProgress / 100f * 1.5f).coerceIn(0.5f, 2f)
        val volume = (volumeProgress / 100f).coerceIn(0f, 1f)
        speechReady = runCatching { speechEngine?.setVoice(voice) == TextToSpeech.SUCCESS }.getOrDefault(false)
        speechEngine?.setSpeechRate(speed)
        speechEngine?.setPitch(pitch)
        speechVolume = volume
        if (persist) preferences.edit()
            .putString("speech_voice_name", voice.name)
            .putFloat("speech_speed", speed)
            .putFloat("speech_pitch", pitch)
            .putFloat("speech_volume", volume)
            .apply()
    }

    private fun showThinking(message: String?, progressPercent: Int? = null) {
        processingMessage = message?.takeIf { it.isNotBlank() }
        processingProgressPercent = if (processingMessage == null) null else progressPercent?.coerceIn(0, 100)
        if (::thinkingText.isInitialized) thinkingText.visibility = View.GONE
        if (!::chatMessages.isInitialized || isProfileScreen || isPersonalizationScreen) return
        if (processingMessage == null) {
            processingRow?.let { row -> (row.parent as? LinearLayout)?.removeView(row) }
            processingRow = null
            processingBodyView = null
            processingHeaderView = null
            processingProgressBar = null
            processingProgressPercent = null
            return
        }
        if (processingRow == null || processingRow?.parent !== chatMessages) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.START; setPadding(0, dp(1), 0, dp(3)) }
            row.addView(createAvatarView(true, 30), LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(6); topMargin = dp(2) })
            val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.START }
            stack.addView(TextView(this).apply {
                text = "${aiDisplayName()} · 正在处理"
                textSize = 11.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(C_AI_NAME)
                setPadding(dp(2), 0, dp(2), dp(4))
            })
            val bubble = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(9), dp(12), dp(10))
                background = roundedGradient(C_THINK_BUBBLE, C_PANEL_2, 18, C_PURPLE)
            }
            val header = TextView(this).apply {
                textSize = 12.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(C_BLUE_TEXT)
                setPadding(0, 0, 0, dp(4))
                setOnClickListener {
                    processingExpanded = !processingExpanded
                    processingBodyView?.visibility = if (processingExpanded) View.VISIBLE else View.GONE
                    processingHeaderView?.text = if (processingExpanded) "✦ 正在处理 · 点此收起" else "✦ 正在处理 · 点此展开"
                }
            }
            val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                progressTintList = android.content.res.ColorStateList.valueOf(C_BLUE_BRIGHT)
                minimumHeight = dp(3)
                max = 100
                val knownPercent = processingProgressPercent
                isIndeterminate = knownPercent == null
                if (knownPercent != null) this.progress = knownPercent
            }
            val body = TextView(this).apply {
                textSize = 12.5f
                setTextColor(C_TEXT)
                setLineSpacing(dp(2).toFloat(), 1.0f)
                maxWidth = dp((resources.displayMetrics.widthPixels / resources.displayMetrics.density * 0.68f).toInt().coerceAtLeast(170))
            }
            bubble.addView(header)
            bubble.addView(progress, LinearLayout.LayoutParams(-1, dp(3)).apply { bottomMargin = dp(6) })
            bubble.addView(body)
            stack.addView(bubble)
            row.addView(stack, LinearLayout.LayoutParams(-2, -2))
            chatMessages.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            processingRow = row
            processingBodyView = body
            processingHeaderView = header
            processingProgressBar = progress
        }
        processingProgressBar?.let { bar ->
            val knownPercent = processingProgressPercent
            bar.isIndeterminate = knownPercent == null
            if (knownPercent != null) bar.progress = knownPercent
        }
        processingHeaderView?.text = if (processingExpanded) "✦ 正在处理 · 点此收起" else "✦ 正在处理 · 点此展开"
        val progressNote = if (processingProgressPercent == null) {
            "当前进度条表示处理状态；只有底层提供真实百分比时才会显示精确进度。"
        } else {
            "应用流程阶段进度：${processingProgressPercent}%（仅代表当前软件流程，不代表权重真实加载比例）。"
        }
        processingBodyView?.text = "${processingMessage}\n\n$progressNote\n这里只显示操作状态，不显示模型内部隐藏推理内容。"
        processingBodyView?.visibility = if (processingExpanded) View.VISIBLE else View.GONE
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun modelNameFromUri(uri: Uri): String {
        val rawName = runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull().orEmpty().ifBlank { "imported-model.gguf" }
        var name = File(rawName).name.replace(Regex("""[\\/:*?"<>|]"""), "_").trim().take(96)
        if (!name.lowercase(Locale.ROOT).endsWith(".gguf")) name += ".gguf"
        if (name.equals(".gguf", ignoreCase = true)) name = "imported-model.gguf"
        return name
    }

    private fun uniqueModelFileName(originalName: String): String {
        val name = File(originalName).name
        val base = stripGgufSuffix(name).ifBlank { "imported-model" }
        var candidate = "$base.gguf"
        var index = 2
        while (File(modelDirectory, candidate).exists()) {
            candidate = "$base ($index).gguf"
            index++
        }
        return candidate
    }

    private fun importModel(uri: Uri) {
        if (isBusy || isModelTransferOrLoading) return
        isBusy = true
        isModelTransferOrLoading = true
        setActionButtonsEnabled(false)
        val destinationName = uniqueModelFileName(modelNameFromUri(uri))
        val destination = File(modelDirectory, destinationName)
        AppDiagnostics.log(this, "INFO", "model_import_begin", "file=$destinationName; uriScheme=${uri.scheme.orEmpty()}")
        statusText.text = "正在导入模型「${modelDisplayName(destination)}」；其他模型文件会保留。请保持应用打开。"
        showThinking("📦 正在导入模型文件并检查 GGUF 格式…")
        beginTrackedTask("模型导入", "目标文件：${destination.name}；原有模型文件会保留。")
        lifecycleScope.launch {
            try {
                updateTrackedTask("模型导入", "复制文件", "正在从系统文件选择器复制到应用模型目录；校验完成前使用临时文件。", null)
                val previousRelease = releaseModel
                if (previousRelease != null) {
                    withContext(Dispatchers.IO) { previousRelease.invoke() }
                    releaseModel = null
                    generateReply = null
                    loadedModelFileName = null
                    loadedModelContextSize = null
                    loadedModelProfile = null
                }
                val copiedBytes = withContext(Dispatchers.IO) {
                    if (!modelDirectory.exists() && !modelDirectory.mkdirs()) error("无法创建模型目录")
                    val tempFile = File(modelDirectory, ".${destination.name}.part")
                    if (tempFile.exists()) tempFile.delete()
                    try {
                        contentResolver.openInputStream(uri)?.use { input ->
                            tempFile.outputStream().buffered(1024 * 1024).use { output -> input.copyTo(output, 1024 * 1024) }
                        } ?: error("无法读取所选文件")
                        if (tempFile.length() < 4L) error("文件太小，不像有效的 GGUF 模型")
                        val header = ByteArray(4)
                        tempFile.inputStream().use {
                            if (it.read(header) != 4 || String(header, Charsets.US_ASCII) != "GGUF") error("所选文件不是 GGUF 模型，请选择 .gguf 文件")
                        }
                        if (!tempFile.renameTo(destination)) error("模型复制后无法保存")
                        destination.length()
                    } catch (e: Exception) {
                        tempFile.delete()
                        throw e
                    }
                }
                updateTrackedTask("模型导入", "解析 GGUF", "文件复制与 GGUF 魔数检查完成，开始读取元数据。", null)
                val profile = withContext(Dispatchers.IO) { ModelProfileAnalyzer.analyze(destination) }
                updateTrackedTask("模型导入", "保存模型档案", "已识别：${profile.architecture}；量化线索：${profile.quantizationHint}。", null)
                saveModelProfile(destination, profile)
                preferences.edit().putString("selected_model_file", destination.name).apply()
                responseModeIndex = responseModeIndex.coerceAtMost(profile.modeLabels.lastIndex)
                fastMode = responseModeIndex == 0
                preferences.edit().putInt("response_mode_index", responseModeIndex).putBoolean("fast_mode", fastMode).apply()
                statusText.text = "模型已导入并分析：${profile.architecture} · ${profile.quantizationHint} · 模式：${profile.modeLabels.joinToString(" / ")}。${profile.notes}"
                finishTrackedTask("模型导入", true, "导入与元数据分析成功：${profile.architecture}；${profile.quantizationHint}；文件大小 ${formatBytes(profile.modelBytes)}。")
                AppDiagnostics.log(this@MainActivity, "INFO", "model_import_success", "file=${destination.name}; bytes=${destination.length()}; architecture=${profile.architecture}; quantization=${profile.quantizationHint}")
                Toast.makeText(this@MainActivity, "模型分析完成；已保留其他模型和聊天数据。", Toast.LENGTH_LONG).show()
                if (::modeButton.isInitialized) updateModeButton()
            } catch (e: Exception) {
                AppDiagnostics.logThrowable(this@MainActivity, "ERROR", "model_import_exception", "model import failed: ${e.message.orEmpty()}", e)
                finishTrackedTask("模型导入", false, "导入失败：${e.message ?: "未知错误"}")
                statusText.text = "导入失败：${e.message ?: "未知错误"}"
            } finally {
                showThinking(null)
                isBusy = false
                isModelTransferOrLoading = false
                setActionButtonsEnabled(true)
                updateSendButtonState()
            }
        }
    }

    private fun loadLocalModel(autoTriggered: Boolean = false) {
        if (generateReply != null) {
            val loadedLabel = loadedModelFileName?.let { modelDisplayName(File(modelDirectory, it)) } ?: "当前模型"
            val selectedLabel = modelDisplayName(modelFile)
            statusText.text = if (loadedModelFileName != modelFile.name) {
                "现在运行的是「$loadedLabel」，你选中的是「$selectedLabel」。请先点「退出模型」，再加载所选模型。"
            } else {
                "模型「$loadedLabel」已经加载，无需重复加载。想换模型请先点「退出模型」。"
            }
            return
        }
        if (isBusy) return
        if (!modelFile.exists() || modelFile.length() == 0L) {
            chooseModel.launch(arrayOf("*/*"))
            return
        }
        isBusy = true
        isModelTransferOrLoading = true
        setActionButtonsEnabled(false)
        val loadStartedAt = android.os.SystemClock.elapsedRealtime()
        val loadFileSize = modelFile.length()
        AppDiagnostics.beginOperation(this, "model_load", "file=${modelFile.name}; bytes=$loadFileSize")
        AppDiagnostics.log(this, "INFO", "model_load_configuration", "file=${modelFile.name}; path=${modelFile.absolutePath}; bytes=$loadFileSize; context=${configuredContextSize()}; threads=${configuredCpuThreads()}; requestedGpuLayers=${configuredGpuLayers()}; kvCache=${if (configuredKvCacheQuantization() == 1) "Q8_0" else "F16"}; gpuFlashAttention=${configuredGpuFlashAttention()}; ${AppDiagnostics.memorySnapshot(this)}; ${AppDiagnostics.deviceSnapshot(this)}; ${AppDiagnostics.processSnapshot()}")
        statusText.text = "加载阶段 1/4：检查模型文件「${modelDisplayName(modelFile)}」（${formatBytes(loadFileSize)}）…"
        showThinking("加载阶段 1/4 · 校验本地模型文件\n文件名：${modelFile.name}\n文件大小：${formatBytes(loadFileSize)}", null)
        beginTrackedTask("模型加载", "文件：${modelFile.name}；大小 ${formatBytes(loadFileSize)}。进度按真实阶段记录，原生库没有逐字节加载回调。")
        InferenceKeepAliveService.start(this, "正在加载本地模型…")
        lifecycleScope.launch {
            try {
                val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
                val memoryInfo = ActivityManager.MemoryInfo()
                runCatching { manager?.getMemoryInfo(memoryInfo) }
                // Keep memory metrics for diagnosis only. Model file length is not its resident RAM use
                // (GGUF weights are memory-mapped and the OS pages them in on demand), so never reject
                // a model merely because file bytes exceed an estimated free-RAM threshold.
                AppDiagnostics.log(this@MainActivity, "INFO", "model_load_memory_snapshot", "file=${modelFile.name}; fileBytes=$loadFileSize; available=${memoryInfo.availMem}; total=${memoryInfo.totalMem}; lowMemory=${memoryInfo.lowMemory}; admissionGate=disabled")
                updateTrackedTask("模型加载", "检查文件", "记录当前内存状态用于诊断；不会按模型文件大小预先拒绝加载。", null)
                val previousRelease = releaseModel
                if (previousRelease != null) {
                    statusText.text = "加载阶段 1/4：先安全释放上一个模型…"
                    showThinking("加载阶段 1/4 · 正在释放旧模型，避免两个大型模型同时占用内存…", null)
                    withContext(Dispatchers.IO) { previousRelease.invoke() }
                }
                generateReply = null
                releaseModel = null
                showThinking("加载阶段 2/4 · 正在解析 GGUF 元数据\n读取架构、模型名称、量化类型和聊天模板线索…", null)
                statusText.text = "加载阶段 2/4：分析 GGUF 元数据…"
                updateTrackedTask("模型加载", "解析 GGUF 元数据", "读取模型架构、名称、量化与模板线索；这不是完整权重扫描。", null)
                val cachedProfile = readCachedModelProfile(modelFile)
                val profile = cachedProfile ?: withContext(Dispatchers.IO) { ModelProfileAnalyzer.analyze(modelFile) }
                if (cachedProfile == null) saveModelProfile(modelFile, profile)
                updateTrackedTask("模型加载", "模型档案", if (cachedProfile != null) "复用了与当前文件大小、修改时间一致的模型元数据缓存。" else "已重新读取 GGUF 头部、元数据和张量目录；未读取整个模型权重。", null)
                loadedModelProfile = profile
                AppDiagnostics.log(this@MainActivity, "INFO", "model_load_profile", "name=${profile.displayName}; architecture=${profile.architecture}; quantization=${profile.quantizationHint}; ggufVersion=${profile.ggufVersion}; tensorCount=${profile.tensorCount}; metadataCount=${profile.metadataCount}; parameterCount=${profile.parameterCount}; chatTemplate=${profile.hasChatTemplate}; modelBytes=${profile.modelBytes}")
                responseModeIndex = responseModeIndex.coerceAtMost(profile.modeLabels.lastIndex)
                fastMode = responseModeIndex == 0
                preferences.edit().putInt("response_mode_index", responseModeIndex).putBoolean("fast_mode", fastMode).apply()
                val path = modelFile.absolutePath
                val cpuThreads = configuredCpuThreads()
                val contextSize = configuredContextSize()
                statusText.text = "加载阶段 3/4：原生引擎正在载入权重（${formatBytes(loadFileSize)}；上下文 $contextSize；线程 $cpuThreads）…"
                showThinking(
                    "加载阶段 3/4 · 原生 llama 引擎载入中\n模型：${profile.displayName}\n架构：${profile.architecture}\n量化线索：${profile.quantizationHint}\n文件大小：${formatBytes(profile.modelBytes)}\n配置：上下文 $contextSize · CPU 线程 $cpuThreads\n原生引擎没有提供逐字节权重加载回调，因此这里只显示阶段和耗时，不虚构加载百分比。",
                    null
                )
                modelLoadTicker?.cancel()
                updateTrackedTask("模型加载", "加载原生权重", "原生 loadModel 正在执行；仅报告等待阶段，不声称真实权重百分比。", null)
                modelLoadTicker = lifecycleScope.launch {
                    while (true) {
                        delay(900)
                        val elapsedSeconds = ((android.os.SystemClock.elapsedRealtime() - loadStartedAt) / 1000L).coerceAtLeast(0L)
                        val detail = "加载阶段 3/4 · 原生 llama 引擎载入中\n模型：${profile.displayName}\n架构：${profile.architecture} · ${profile.quantizationHint}\n文件大小：${formatBytes(profile.modelBytes)}\n上下文：$contextSize · CPU 线程：$cpuThreads\n原生加载已等待：${elapsedSeconds} 秒\n注意：依赖库没有真实加载百分比回调，动态进度条代表引擎仍在载入，并非伪造的百分比。"
                        statusText.text = "加载阶段 3/4：原生引擎载入中 · 已等待 ${elapsedSeconds} 秒（${formatBytes(profile.modelBytes)}）"
                        showThinking(detail, null)
                    }
                }
                NativeLlamaEngine.clearNativeLogTail()
                val nativeLogCollector = lifecycleScope.launch(Dispatchers.IO) {
                    var previousTail = ""
                    while (kotlin.coroutines.coroutineContext[kotlinx.coroutines.Job]?.isActive == true) {
                        if (!preferences.getBoolean("runtime_logging_enabled", true)) {
                            delay(1000)
                            continue
                        }
                        val currentTail = NativeLlamaEngine.lastNativeLogTail()
                        if (currentTail.isNotBlank() && currentTail != previousTail) {
                            val delta = when {
                                previousTail.isBlank() -> currentTail.takeLast(5000)
                                currentTail.startsWith(previousTail) -> currentTail.substring(previousTail.length).takeLast(5000)
                                else -> {
                                    val probe = previousTail.takeLast(1024)
                                    val overlapAt = if (probe.length >= 256) currentTail.indexOf(probe) else -1
                                    if (overlapAt >= 0) currentTail.substring(overlapAt + probe.length).takeLast(5000) else currentTail.takeLast(2500)
                                }
                            }
                            if (delta.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "llama_cpp", delta)
                            previousTail = currentTail
                        }
                        delay(250)
                    }
                }
                val loadedHandles = try {
                    withContext(Dispatchers.IO) {
                        AppDiagnostics.log(this@MainActivity, "INFO", "native_backend_init_begin", "nativeLibraryDir=${applicationInfo.nativeLibraryDir}; GPU device enumeration is disabled for CPU-only load mode.")
                        NativeLlamaEngine.initializeBackend(applicationInfo.nativeLibraryDir)
                        AppDiagnostics.log(this@MainActivity, "INFO", "native_backend_init_complete", "${NativeLlamaEngine.lastNativeLogTail().takeLast(3000)}")
                        val requestedGpuLayers = configuredGpuLayers()
                        val kvCacheQuantization = configuredKvCacheQuantization()
                        val gpuFlashAttention = configuredGpuFlashAttention()
                        AppDiagnostics.log(this@MainActivity, "INFO", "native_model_load_call", "path=$path; bytes=$loadFileSize; context=$contextSize; threads=$cpuThreads; gpuLayers=$requestedGpuLayers; kvCache=${if (kvCacheQuantization == 1) "Q8_0" else "F16"}; gpuFlashAttention=$gpuFlashAttention; loadMode=${if (requestedGpuLayers == 0) "MMAP (file-backed CPU weights)" else "AUTO (GPU path)"}")
                        val targetHandle = NativeLlamaEngine.loadModel(
                            path = path,
                            contextSize = contextSize,
                            threads = cpuThreads,
                            gpuLayers = requestedGpuLayers,
                            kvCacheQuantization = kvCacheQuantization,
                            gpuFlashAttention = gpuFlashAttention
                        )
                        val draftName = preferences.getString("inference_draft_model_filename", "").orEmpty().let { File(it).name }
                        var draftHandle = 0L
                        if (draftName.isNotBlank() && draftName != modelFile.name) {
                            val draftFile = File(modelDirectory, draftName)
                            if (draftFile.isFile && draftFile.length() > 0L) {
                                try {
                                    AppDiagnostics.log(this@MainActivity, "INFO", "speculative_draft_load_begin", "file=${draftFile.name}; bytes=${draftFile.length()}; backend=CPU; kvCache=F16")
                                    draftHandle = NativeLlamaEngine.loadModel(
                                        path = draftFile.absolutePath, contextSize = contextSize, threads = cpuThreads,
                                        gpuLayers = 0, kvCacheQuantization = 0, gpuFlashAttention = false
                                    )
                                    AppDiagnostics.log(this@MainActivity, "INFO", "speculative_draft_load_success", "file=${draftFile.name}; handle=$draftHandle")
                                } catch (draftError: Exception) {
                                    AppDiagnostics.logThrowable(this@MainActivity, "WARN", "speculative_draft_load_failed", "file=${draftFile.name}; normalSingleModelPathPreserved=true", draftError)
                                }
                            } else {
                                AppDiagnostics.log(this@MainActivity, "WARN", "speculative_draft_missing", "file=${draftFile.absolutePath}; normalSingleModelPathPreserved=true")
                            }
                        }
                        Pair(targetHandle, draftHandle)
                    }
                } finally {
                    nativeLogCollector.cancelAndJoin()
                    val finalNativeTail = withContext(Dispatchers.IO) { NativeLlamaEngine.lastNativeLogTail() }
                    if (finalNativeTail.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "native_load_final_tail", finalNativeTail.takeLast(8000))
                    modelLoadTicker?.cancel()
                    modelLoadTicker = null
                }
                val loadedHandle = loadedHandles.first
                val loadedDraftHandle = loadedHandles.second
                nativeModelHandle = loadedHandle
                nativeDraftModelHandle = loadedDraftHandle
                val configuredDraftName = preferences.getString("inference_draft_model_filename", "").orEmpty().let { File(it).name }
                val draftLoadStatus = when {
                    configuredDraftName.isBlank() -> "推测解码关闭"
                    configuredDraftName == modelFile.name -> "草稿模型与目标模型相同，推测解码未启用"
                    loadedDraftHandle != 0L -> "草稿模型已加载（词表检查会在首次推理时执行，运行效果待验证）"
                    else -> "草稿模型未能加载，推测解码未启用；请查看任务日志"
                }
                AppDiagnostics.finishOperation(this@MainActivity, "model_load", "success", "file=${modelFile.name}; bytes=$loadFileSize; draftStatus=$draftLoadStatus; elapsedMs=${android.os.SystemClock.elapsedRealtime() - loadStartedAt}")
                generateReply = { prompt, webResearch ->
                    val policyQuestion = activeQuestionText.ifBlank { prompt }.take(800)
                    val effort = classifyQuestion(policyQuestion)
                    // Fast mode always uses a compact personalization/context payload, even for hard questions.
                    // Standalone questions should not pay the mobile prefill cost for unrelated old sessions.
                    // Keep the larger personalization/history payload only for clear follow-ups.
                    val compactContext = fastMode || effort <= ResponseEffort.SIMPLE || !needsRecentConversationContext(policyQuestion)
                    val personalContext = buildString {
                        val userName = preferences.getString("profile_name", "我").orEmpty().trim()
                        if (userName.isNotBlank()) append("用户昵称：").append(userName.take(40)).append("。")
                        if (compactContext) {
                            // Avoid large memory/history prefill for greetings and simple questions.
                            val chatPreferences = preferences.getString("personalization_chat_preferences", "").orEmpty().trim()
                            if (chatPreferences.isNotBlank()) append("聊天风格偏好：").append(chatPreferences.take(100)).append("。")
                        } else {
                            val signature = preferences.getString("profile_signature", "").orEmpty().trim()
                            val intro = preferences.getString("profile_intro", "").orEmpty().trim()
                            val interests = preferences.getString("personalization_interests", "").orEmpty().trim()
                            val dailyPreferences = preferences.getString("personalization_daily_preferences", "").orEmpty().trim()
                            val chatPreferences = preferences.getString("personalization_chat_preferences", "").orEmpty().trim()
                            val userRequests = preferences.getString("personalization_user_requests", "").orEmpty().trim()
                            if (signature.isNotBlank()) append("用户签名/偏好：").append(signature.take(120)).append("。")
                            if (intro.isNotBlank()) append("用户自我介绍：").append(intro.take(240)).append("。")
                            if (interests.isNotBlank()) append("用户兴趣爱好：").append(interests.take(200)).append("。")
                            if (dailyPreferences.isNotBlank()) append("用户日常喜好：").append(dailyPreferences.take(220)).append("。")
                            if (chatPreferences.isNotBlank()) append("用户偏好的聊天风格：").append(chatPreferences.take(220)).append("。")
                            if (userRequests.isNotBlank()) append("用户希望长期遵守的要求：").append(userRequests.take(240)).append("。")
                            val height = preferences.getString("personalization_height", "").orEmpty().trim()
                            val weight = preferences.getString("personalization_weight", "").orEmpty().trim()
                            if ((height.isNotBlank() || weight.isNotBlank()) && Regex("身高|体重|减肥|增重|健身|热量|饮食|BMI|运动|身体|穿衣|尺码", RegexOption.IGNORE_CASE).containsMatchIn(policyQuestion)) {
                                if (height.isNotBlank()) append("用户记录的身高（仅在相关问题时使用）：").append(height.take(24)).append("。")
                                if (weight.isNotBlank()) append("用户记录的体重（仅在相关问题时使用）：").append(weight.take(24)).append("。")
                            }
                            val savedMemories = loadPersonalMemories().takeLast(8)
                            if (savedMemories.isNotEmpty()) append("用户明确保存的重要记忆（仅在相关时使用，不要没话找话提起）：").append(savedMemories.joinToString("；") { it.take(180) }).append("。")
                            val validatedLessons = LearningMemoryStore.validatedLessons(preferences, 5)
                            if (validatedLessons.isNotEmpty()) append("用户确认过的纠正经验（只在相关时使用；不是通用事实来源）：").append(validatedLessons.joinToString("；") { it.take(320) }).append("。")
                            if (preferences.getBoolean("personalization_location_enabled", false) && Regex("天气|位置|哪里|附近|地点|定位", RegexOption.IGNORE_CASE).containsMatchIn(policyQuestion)) {
                                val savedPlace = preferences.getString("last_location_label", "").orEmpty().trim()
                                if (savedPlace.isNotBlank()) append("用户最近一次主动请求时记录的位置：").append(savedPlace.take(90)).append("。只把它当作最近记录，不要声称是实时位置。")
                            }
                            val previousSnippets = sessions.asReversed().filter { it.id != currentSessionId && it.messages.isNotEmpty() }.take(2)
                            if (previousSnippets.isNotEmpty() && needsRecentConversationContext(policyQuestion)) {
                                append("最近旧话题参考（仅用于保持连续性，不要当作当前问题）：")
                                previousSnippets.forEach { oldSession ->
                                    append("话题《").append(oldSession.title.take(36)).append("》")
                                    oldSession.messages.filter { it.isUser }.takeLast(1).forEach { append("；用户曾提到：").append(it.message.take(100)) }
                                    oldSession.messages.filter { !it.isUser && !it.who.contains("思考") && !it.who.contains("来源") && !it.who.contains("搜索") && !it.who.contains("提示") && !it.who.contains("失败") }.takeLast(1).forEach { append("；助手之前回答要点：").append(it.message.take(120)) }
                                    append("。")
                                }
                            }
                        }
                        if (compactContext && !fastMode) {
                            val recentTopics = sessions.asReversed()
                                .filter { it.id != currentSessionId && it.messages.isNotEmpty() }
                                .take(2)
                            if (recentTopics.isNotEmpty()) {
                                append("最近其他话题的简短记忆（只在相关时引用）：")
                                recentTopics.forEach { oldSession ->
                                    val oldQuestion = oldSession.messages.lastOrNull { it.isUser }?.message.orEmpty()
                                    val oldAnswer = oldSession.messages.lastOrNull { !it.isUser && !it.who.contains("思考") && !it.who.contains("来源") && !it.who.contains("搜索") && !it.who.contains("提示") && !it.who.contains("失败") }?.message.orEmpty()
                                    append("《").append(oldSession.title.take(28)).append("》")
                                    if (oldQuestion.isNotBlank()) append("用户最后提问：").append(oldQuestion.take(100)).append("；")
                                    if (oldAnswer.isNotBlank()) append("助手回答摘要：").append(oldAnswer.take(110)).append("；")
                                }
                            }
                        }
                    }
                    val effectiveContextSize = InferenceBudgetPolicy.effectiveContextSize(configuredContextSize(), loadedModelContextSize)
                    val generationBudget = InferenceBudgetPolicy.forMode(responseModeIndex, effectiveContextSize)
                    val simpleQuestion = effort <= ResponseEffort.SIMPLE || isCasualMessage(policyQuestion)
                    val systemPrompt = InferencePromptPolicy.systemPrompt(
                        responseModeIndex,
                        simpleQuestion,
                        webResearch,
                        loadedModelProfile?.supportsReasoningTemplate == true,
                        aiDisplayName(),
                        generationBudget.softThinkingTokens
                    )
                    val personalContextLimit = when (responseModeIndex) { 0 -> 180; 1 -> 700; else -> 1400 }
                    val compactPersonalContext = personalContext.take(personalContextLimit)
                    val promptWithPersonalContext = if (compactPersonalContext.isBlank()) prompt else
                        "相关个人偏好/记忆（仅在与问题相关时使用）：$compactPersonalContext\n\n$prompt"
                    val toolRoute = withContext(Dispatchers.IO) {
                        LocalEmbeddingRouter.route(this@MainActivity, policyQuestion, AiToolRegistry.callableDefinitions(webSearchEnabled))
                    }
                    val candidateNames = toolRoute.toolNames.takeIf { !toolRoute.fallback }
                    val toolCatalogue = AiToolRegistry.prompt(webSearchEnabled, candidateNames)
                    AppDiagnostics.log(this@MainActivity, if (toolRoute.fallback) "WARN" else "INFO", "embedding_tool_route",
                        "enabled=${!toolRoute.fallback}; elapsedMs=${toolRoute.elapsedMs}; reason=${toolRoute.reason}; fallback=${toolRoute.fallback}; candidates=${toolRoute.toolNames.joinToString(",")}; scores=${toolRoute.scores.take(500)}; availableTools=${AiToolRegistry.callableDefinitions(webSearchEnabled).size}; modelFilesPresent=${LocalEmbeddingRouter.isReady(this@MainActivity)}")
                    val trimmedUserContext = InferenceBudgetPolicy.trimPromptToSoftCharLimit(
                        promptWithPersonalContext,
                        responseModeIndex,
                        effectiveContextSize,
                        reservedChars = toolCatalogue.length + 2
                    )
                    // Keep the catalogue before the user's trimmed conversation so it is never cut off by tail trimming.
                    val actualPrompt = toolCatalogue + "\n\n" + trimmedUserContext
                    AppDiagnostics.log(this@MainActivity, "INFO", "inference_prompt_policy",
                        "modeIndex=$responseModeIndex; mode=${generationBudget.modeName}; systemPromptChars=${systemPrompt.length}; toolCatalogueChars=${toolCatalogue.length}; personalContextChars=${compactPersonalContext.length}; inputPromptChars=${actualPrompt.length}; estimatedInputTokens=not_available_in_kotlin_layer; routeFallback=${toolRoute.fallback}; routeElapsedMs=${toolRoute.elapsedMs}; prefixKvCache=exact_token_prefix_cache_enabled_native_context_persisted_until_memory_pressure; softPromptCharLimit=${InferenceBudgetPolicy.softPromptCharLimit(responseModeIndex, effectiveContextSize)}; configuredContext=${configuredContextSize()}; loadedNativeContext=${loadedModelContextSize ?: "none"}; effectiveContext=$effectiveContextSize; softThinkingTokens=${generationBudget.softThinkingTokens}; firstPassTokens=${generationBudget.firstPassTokens}; hardOutputTokens=${generationBudget.hardOutputTokens}; webResearch=$webResearch")
                    check(systemPrompt.length <= 100) { "Mode system prompt exceeded the 100-character budget: ${systemPrompt.length}" }
                    // Soft thinking targets guide the model; they do not cut off a turn.
                    // The first-pass boundary triggers an answer-only continuation if reached.
                    // The high safety cap is tied to context size so input history is not crowded out.
                    val tokenLimit = generationBudget.firstPassTokens
                    val hardTokenLimit = generationBudget.hardOutputTokens
                    // JNI generation runs off the UI thread and reports real token text as it is decoded.
                    // UI preview updates are throttled to avoid posting one frame per token.
                    val inferenceStartedAt = android.os.SystemClock.elapsedRealtime()
                    beginTrackedTask("本地模型回答", "提示词已准备，进入 llama.cpp 原生逐 Token 生成。")
                    val streamBuffer = StringBuilder()
                    var continuationTriggered = false
                    var continuationStillCapped = false
                    var continuationReasonUsed = "none"
                    var firstPassElapsedMs = 0L
                    var continuationElapsedMs = 0L
                    var firstPassOutputChars = 0
                    var firstPassHasThinkTags = false
                    var firstPassVisibleThinkChars = 0
                    var firstPassNativeMetrics = "unavailable"
                    var continuationNativeMetrics = "not_run"
                    var lastUiUpdateAt = 0L
                    AppDiagnostics.beginOperation(this@MainActivity, "model_inference", "model=${loadedModelFileName ?: "unknown"}; architecture=${loadedModelProfile?.architecture ?: "unknown"}; context=$effectiveContextSize; configuredContext=${configuredContextSize()}; loadedNativeContext=${loadedModelContextSize ?: "none"}; threads=${configuredCpuThreads()}; promptChars=${actualPrompt.length}; cpuFlashAttention=disabled")
                    InferenceKeepAliveService.start(this@MainActivity, "正在生成本地 AI 回答…")
                    val raw = try {
                        modelInferenceMutex.withLock {
                            modelInferenceActive = true
                            updateTrackedTask("本地模型回答", "原生逐 Token 推理中", "引擎：llama.cpp v0.6.0；GPU 层配置与后端检测结果可在「更多功能 → 推理引擎 / GPU 状态」刷新查看。", null)
                            try {
                                withContext(Dispatchers.IO) {
                                    // A SIGSEGV cannot be caught by Kotlin. Persist native log-tail checkpoints
                                    // concurrently so the last engine stage survives an abrupt process exit.
                                    NativeLlamaEngine.clearNativeLogTail()
                                    coroutineScope {
                                        val nativeLogCollector = launch {
                                            var previousTail = ""
                                            while (true) {
                                                currentCoroutineContext().ensureActive()
                                                val runtimeLoggingEnabled = preferences.getBoolean("runtime_logging_enabled", true)
                                                val liveStatsEnabled = preferences.getBoolean("runtime_live_stats_enabled", true)
                                                if (!runtimeLoggingEnabled) {
                                                    delay(1000)
                                                    continue
                                                }
                                                val currentTail = NativeLlamaEngine.lastNativeLogTail()
                                                if (currentTail.isNotBlank() && currentTail != previousTail) {
                                                    val delta = when {
                                                        previousTail.isBlank() -> currentTail.takeLast(5000)
                                                        currentTail.startsWith(previousTail) -> currentTail.substring(previousTail.length).takeLast(5000)
                                                        else -> currentTail.takeLast(2500)
                                                    }
                                                    if (delta.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "llama_inference_checkpoint", delta)
                                                    previousTail = currentTail
                                                }
                                                delay(if (liveStatsEnabled) 180 else 1000)
                                            }
                                        }
                                        val onGeneratedToken: (String) -> Unit = { token ->
                                            // Live preview is optional. When disabled, avoid per-token StringBuilder copies
                                            // and UI-thread posts; the native engine still returns the complete final answer.
                                            if (preferences.getBoolean("runtime_live_stats_enabled", true)) {
                                                val snapshot: String
                                                synchronized(streamBuffer) {
                                                    streamBuffer.append(token)
                                                    snapshot = streamBuffer.toString()
                                                }
                                                val now = android.os.SystemClock.elapsedRealtime()
                                                if (now - lastUiUpdateAt >= 90L || token.contains('\n')) {
                                                    lastUiUpdateAt = now
                                                    runOnUiThread {
                                                        if (!isFinishing && !isDestroyed && (modelInferenceActive || isBusy)) {
                                                            showThinking("✍️ 正在逐 Token 生成…\n${snapshot.takeLast(1600)}", null)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        try {
                                            val firstPassStartedAt = android.os.SystemClock.elapsedRealtime()
                                            var generated = NativeLlamaEngine.generate(
                                                loadedHandle, actualPrompt, systemPrompt, tokenLimit,
                                                onToken = onGeneratedToken, draftHandle = loadedDraftHandle
                                            )
                                            firstPassElapsedMs = android.os.SystemClock.elapsedRealtime() - firstPassStartedAt
                                            firstPassOutputChars = generated.length
                                            val firstPassMetrics = NativeLlamaEngine.lastInferenceMetrics(loadedHandle)
                                            firstPassNativeMetrics = firstPassMetrics
                                            firstPassHasThinkTags = generated.contains("<think>", ignoreCase = true) || generated.contains("</think>", ignoreCase = true)
                                            firstPassVisibleThinkChars = Regex("(?is)<think>(.*?)</think>").findAll(generated).sumOf { it.groupValues[1].length }
                                            val continuationReason = InferenceBudgetPolicy.continuationReason(generated, firstPassMetrics, tokenLimit)
                                            continuationReasonUsed = continuationReason ?: "none"
                                            if (continuationReason != null) {
                                                continuationTriggered = true
                                                AppDiagnostics.log(
                                                    this@MainActivity, "WARN", "inference_soft_budget_continuation",
                                                    "mode=${generationBudget.modeName}; triggerReason=$continuationReason; softTargetTokens=${generationBudget.softThinkingTokens}; firstPassTokens=$tokenLimit; hardOutputTokens=$hardTokenLimit; generatedTokens=${Regex("generatedTokens=(\\d+)").find(firstPassMetrics)?.groupValues?.getOrNull(1) ?: "unknown"}; continuation=started"
                                                )
                                                synchronized(streamBuffer) { streamBuffer.setLength(0) }
                                                lastUiUpdateAt = 0L
                                                runOnUiThread {
                                                    if (!isFinishing && !isDestroyed) {
                                                        showThinking("🧠 已达到本模式的首轮预算，正在收敛思考并补全正式回答…", null)
                                                    }
                                                }
                                                // The partial first pass is context for a second, answer-focused call.
                                                // Put the latest user prompt and the tail of the draft at the end so they
                                                // survive context trimming on smaller phone context windows.
                                                val continuationPrompt = buildString {
                                                    append("上一阶段未完成草稿（只用于理解，不要复述）：\n")
                                                    append(generated.takeLast(520))
                                                    append("\n\n原问题与最近上下文（本段放在末尾，以避免小上下文裁剪掉用户的问题）：\n")
                                                    append(actualPrompt.takeLast(520))
                                                    append("\n\n请现在直接给出完整的正式回答，先给结论，再写必要依据；不要继续展开内部思考，不要复述草稿。")
                                                }
                                                val continuationSystemPrompt = "$systemPrompt\n\n【预算收敛规则】首轮预算已用尽。现在必须停止继续思考，基于已有内容直接生成最终答案；不要从头复述，不要输出思考过程。\n/no_think"
                                                val continuationStartedAt = android.os.SystemClock.elapsedRealtime()
                                                generated = NativeLlamaEngine.generate(
                                                    loadedHandle, continuationPrompt, continuationSystemPrompt, hardTokenLimit,
                                                    onToken = onGeneratedToken, draftHandle = 0L
                                                )
                                                continuationElapsedMs = android.os.SystemClock.elapsedRealtime() - continuationStartedAt
                                                val continuationMetrics = NativeLlamaEngine.lastInferenceMetrics(loadedHandle)
                                                continuationNativeMetrics = continuationMetrics
                                                continuationStillCapped = InferenceBudgetPolicy.reachedTokenLimit(continuationMetrics, hardTokenLimit)
                                                AppDiagnostics.log(
                                                    this@MainActivity,
                                                    if (continuationStillCapped) "WARN" else "INFO",
                                                    "inference_continuation_complete",
                                                    "mode=${generationBudget.modeName}; softTargetTokens=${generationBudget.softThinkingTokens}; hardOutputTokens=$hardTokenLimit; continuationStillCapped=$continuationStillCapped; outputChars=${generated.length}"
                                                )
                                                if (continuationStillCapped) {
                                                    generated = generated.trimEnd() + "\n\n（提示：本次回答仍触及输出安全上限，内容可能不完整。你可以发送“继续”，让我接着回答。）"
                                                }
                                            }
                                            generated
                                        } finally {
                                            nativeLogCollector.cancelAndJoin()
                                            val finalNativeTail = NativeLlamaEngine.lastNativeLogTail()
                                            if (finalNativeTail.isNotBlank()) AppDiagnostics.log(this@MainActivity, "NATIVE", "native_inference_final_tail", finalNativeTail.takeLast(8000))
                                        }
                                    }
                                }
                            } finally {
                                modelInferenceActive = false
                                runOnUiThread {
                                    if (!isBusy) setActionButtonsEnabled(true)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        val exceptionTerminationReason = if (e.javaClass.simpleName.contains("Timeout", ignoreCase = true) || e.message.orEmpty().contains("timeout", ignoreCase = true)) "timeout" else if (e is java.util.concurrent.CancellationException) "user_stop" else "engine_error"
                        AppDiagnostics.logThrowable(this@MainActivity, if (exceptionTerminationReason == "engine_error") "ERROR" else "WARN", if (exceptionTerminationReason == "engine_error") "native_inference_exception" else "native_inference_interrupted", "terminationReason=$exceptionTerminationReason; model=${loadedModelFileName ?: "unknown"}; context=${configuredContextSize()}; ${AppDiagnostics.memorySnapshot(this@MainActivity)}; nativeLog=${NativeLlamaEngine.lastNativeLogTail().takeLast(6000)}", e)
                        AppDiagnostics.finishOperation(this@MainActivity, "model_inference", if (exceptionTerminationReason == "user_stop") "cancelled" else "failed", "terminationReason=$exceptionTerminationReason; ${e.javaClass.simpleName}: ${e.message.orEmpty()}")
                        finishTrackedTask("本地模型回答", false, "原生推理失败或已中断：${e.message ?: e.javaClass.simpleName}")
                        throw e
                    } finally {
                        InferenceKeepAliveService.stop(this@MainActivity)
                    }
                    val nativeMetrics = NativeLlamaEngine.lastInferenceMetrics(loadedHandle)
                    val finalTerminationReason = InferenceBudgetPolicy.finalTerminationReason(
                        raw, nativeMetrics, if (continuationTriggered) hardTokenLimit else tokenLimit,
                        continuationStillCapped, NativeLlamaEngine.lastNativeLogTail()
                    )
                    AppDiagnostics.log(
                        this@MainActivity,
                        if (finalTerminationReason in setOf("engine_error", "context_limit", "timeout")) "ERROR" else if (finalTerminationReason in setOf("hard_limit", "user_stop")) "WARN" else "INFO",
                        "inference_termination",
                        "finalTerminationReason=$finalTerminationReason; continuationTriggerReason=$continuationReasonUsed; continuationTriggered=$continuationTriggered; continuationStillCapped=$continuationStillCapped; configuredContext=${configuredContextSize()}; loadedNativeContext=${loadedModelContextSize ?: "none"}; effectiveContext=$effectiveContextSize; promptContextTrimmedByApp=${actualPrompt.length < promptWithPersonalContext.length}"
                    )
                    val visibleThinkChars = Regex("(?is)<think>(.*?)</think>").findAll(raw).sumOf { it.groupValues[1].length }
                    val hasThinkTags = raw.contains("<think>", ignoreCase = true) || raw.contains("</think>", ignoreCase = true)
                    AppDiagnostics.log(this@MainActivity, "INFO", "inference_metrics", "schemaVersion=${AppDiagnostics.SCHEMA_VERSION}; model=${loadedModelFileName ?: "unknown"}; modeIndex=$responseModeIndex; mode=${generationBudget.modeName}; configuredContext=${configuredContextSize()}; loadedNativeContext=${loadedModelContextSize ?: "none"}; effectiveSoftContext=$effectiveContextSize; softPromptCharLimit=${InferenceBudgetPolicy.softPromptCharLimit(responseModeIndex, effectiveContextSize)}; systemPromptChars=${systemPrompt.length}; promptChars=${actualPrompt.length}; personalContextChars=${compactPersonalContext.length}; threads=${configuredCpuThreads()}; requestedGpuLayers=${configuredGpuLayers()}; kvCache=${if (configuredKvCacheQuantization() == 1) "Q8_0" else "F16"}; softThinkingTokens=${generationBudget.softThinkingTokens}; firstPassRequestedTokens=$tokenLimit; firstPassOutputChars=$firstPassOutputChars; firstPassElapsedMs=$firstPassElapsedMs; continuationReason=$continuationReasonUsed; continuationElapsedMs=$continuationElapsedMs; continuationTriggered=$continuationTriggered; continuationStillCapped=$continuationStillCapped; firstPassThinkTagsObserved=$firstPassHasThinkTags; firstPassVisibleThinkChars=$firstPassVisibleThinkChars; finalOutputThinkTagsObserved=$hasThinkTags; finalOutputVisibleThinkChars=$visibleThinkChars; firstPassNativeMetrics=$firstPassNativeMetrics; continuationNativeMetrics=$continuationNativeMetrics; finalNativeMetrics=${NativeLlamaEngine.lastInferenceMetrics(loadedHandle)}")
                    val nativeFailureMarkers = listOf("无法创建本地推理上下文", "无法初始化 Token 采样器", "模型预填充失败", "GPU 预填充失败", "无法加载此 GGUF 模型")
                    if (nativeFailureMarkers.any { raw.startsWith(it) }) {
                        AppDiagnostics.log(this@MainActivity, "ERROR", "native_inference_reported_error", "message=${raw.take(300)}; nativeLog=${NativeLlamaEngine.lastNativeLogTail().takeLast(4000)}")
                        AppDiagnostics.finishOperation(this@MainActivity, "model_inference", "reported_error", raw.take(300))
                    } else {
                        AppDiagnostics.finishOperation(
                            this@MainActivity,
                            "model_inference",
                            if (continuationStillCapped) "partial" else "success",
                            "model=${loadedModelFileName ?: "unknown"}; outputChars=${raw.length}; elapsedMs=${android.os.SystemClock.elapsedRealtime() - inferenceStartedAt}; continuationTriggered=$continuationTriggered; continuationStillCapped=$continuationStillCapped"
                        )
                    }
                    val inferenceSeconds = (android.os.SystemClock.elapsedRealtime() - inferenceStartedAt) / 1000.0
                    finishTrackedTask(
                        "本地模型回答", !continuationStillCapped,
                        String.format(
                            Locale.CHINA,
                            "原生逐 Token 生成耗时 %.2f 秒；返回文本 %d 个字符；模式 %s，软性思考目标 %d tokens，首轮预算 %d tokens，安全上限 %d tokens；触发续答=%s；续答后仍触顶=%s。\n原生指标：%s",
                            inferenceSeconds, raw.length, generationBudget.modeName, generationBudget.softThinkingTokens,
                            tokenLimit, hardTokenLimit, continuationTriggered, continuationStillCapped, nativeMetrics
                        )
                    )
                    parseModelReply(raw)
                }
                releaseModel = {
                    withContext(Dispatchers.IO) {
                        NativeLlamaEngine.release(loadedHandle)
                        if (loadedDraftHandle != 0L) NativeLlamaEngine.release(loadedDraftHandle)
                    }
                    if (nativeModelHandle == loadedHandle) nativeModelHandle = 0L
                    if (loadedModelFileName == modelFile.name) loadedModelContextSize = null
                    if (nativeDraftModelHandle == loadedDraftHandle) nativeDraftModelHandle = 0L
                }
                loadedModelFileName = modelFile.name
                loadedModelContextSize = contextSize
                updateModeButton()
                preferences.edit().putBoolean("model_auto_load", true).apply()
                val loadSeconds = (android.os.SystemClock.elapsedRealtime() - loadStartedAt) / 1000.0
                finishTrackedTask("模型加载", true, String.format(Locale.CHINA, "模型载入成功，总耗时 %.1f 秒；架构线索 %s；量化线索 %s。%s。GPU 的真实性能仍需运行时验证。", loadSeconds, profile.architecture, profile.quantizationHint, draftLoadStatus))
                statusText.text = if (configuredDraftName.isNotBlank() && configuredDraftName != modelFile.name && loadedDraftHandle == 0L) {
                    "目标模型已就绪，但草稿模型未加载；本次未启用推测解码。请查看任务日志。"
                } else String.format(Locale.CHINA, "加载阶段 4/4：模型就绪 · 总耗时 %.1f 秒 · %s · %s", loadSeconds, profile.architecture, profile.quantizationHint)
                showThinking("加载阶段 4/4 · 模型已成功载入\n名称：${profile.displayName}\n架构：${profile.architecture}\n量化线索：${profile.quantizationHint}\n文件大小：${formatBytes(profile.modelBytes)}\n载入总耗时：${String.format(Locale.CHINA, "%.1f", loadSeconds)} 秒\n$draftLoadStatus\n当前模型已载入本进程；发送新消息会复用当前模型实例。", 100)
                delay(350)
                if (!autoTriggered) Toast.makeText(this@MainActivity, "模型加载完成，可以开始聊天了。", Toast.LENGTH_SHORT).show()
            } catch (e: OutOfMemoryError) {
                if (autoTriggered) preferences.edit().putBoolean("model_auto_load", false).apply()
                if (autoTriggered) AppDiagnostics.log(this@MainActivity, "WARN", "model_auto_load_disabled_after_failure", "autoTriggered=true; failure=OutOfMemoryError; manualRetryRequired=true")
                AppDiagnostics.logThrowable(this@MainActivity, "FATAL", "model_load_out_of_memory", "file=${modelFile.name}; bytes=$loadFileSize; ${AppDiagnostics.memorySnapshot(this@MainActivity)}", e)
                AppDiagnostics.finishOperation(this@MainActivity, "model_load", "failed_memory", "OutOfMemoryError: ${e.message.orEmpty()}")
                finishTrackedTask("模型加载", false, "模型加载时内存不足。请关闭后台应用或换用更小的 GGUF 模型。")
                nativeModelHandle = 0L
                nativeDraftModelHandle = 0L
                loadedModelFileName = null
                statusText.text = "模型加载时内存不足。为避免再次闪退，请使用更小的模型或更低的上下文设置。"
            } catch (e: Exception) {
                if (autoTriggered) preferences.edit().putBoolean("model_auto_load", false).apply()
                if (autoTriggered) AppDiagnostics.log(this@MainActivity, "WARN", "model_auto_load_disabled_after_failure", "autoTriggered=true; failure=Exception; manualRetryRequired=true")
                AppDiagnostics.logThrowable(this@MainActivity, "ERROR", "model_load_exception", "file=${modelFile.name}; bytes=$loadFileSize; ${AppDiagnostics.memorySnapshot(this@MainActivity)}; nativeLog=${NativeLlamaEngine.lastNativeLogTail().takeLast(6000)}", e)
                AppDiagnostics.finishOperation(this@MainActivity, "model_load", "failed", "${e.javaClass.simpleName}: ${e.message.orEmpty()}")
                finishTrackedTask("模型加载", false, "模型加载失败：${e.message ?: "请确认这是受支持的 GGUF 模型"}")
                nativeModelHandle = 0L
                nativeDraftModelHandle = 0L
                loadedModelFileName = null
                loadedModelProfile = null
                statusText.text = "模型加载失败：${e.message ?: "请确认这是受支持的 GGUF 模型"}"
            } finally {
                InferenceKeepAliveService.stop(this@MainActivity)
                modelLoadTicker?.cancel()
                modelLoadTicker = null
                showThinking(null)
                isBusy = false
                isModelTransferOrLoading = false
                setActionButtonsEnabled(true)
                updateSendButtonState()
            }
        }
    }

    private fun sendMessage() {
        val question = promptInput.text.toString().trim()
        if (question.isEmpty()) {
            if (activeQuestionJob != null) {
                interruptActiveResponse("已停止当前回答。你可以继续补充问题。")
            }
            return
        }
        if (isModelTransferOrLoading) {
            statusText.text = "模型正在导入或加载，完成后就能继续聊天啦。"
            return
        }
        if (isBusy && activeQuestionJob == null) {
            statusText.text = "当前正在准备模型，请稍等片刻。"
            return
        }
        if (generateReply == null && instantSocialReply(question) == null && directMathExpression(question).isBlank()) {
            statusText.text = if (modelFile.exists() && modelFile.length() > 0L) {
                "模型「${modelDisplayName(modelFile)}」尚未加载。所有 AI 工具都必须先经过模型判断；请先点击“加载模型”。"
            } else {
                "还没有可用模型。请先导入并加载 GGUF 模型；为确保 AI 自主决定工具，不会在模型加载前自动执行天气、搜索或计算。"
            }
            Toast.makeText(this, statusText.text, Toast.LENGTH_LONG).show()
            return
        }
        val wasBusy = isBusy
        if (isBusy) interruptActiveResponse("上一条回答已中断，正在切换到你的新问题…")

        promptInput.setText("")
        activeQuestionText = question
        appendTranscript(preferences.getString("profile_name", "我").orEmpty().ifBlank { "我" }, question, true)
        maybeRememberUserMessage(question)
        maybeRecordCorrection(question)
        val requestId = ++activeRequestId
        isBusy = true
        setActionButtonsEnabled(false)
        updateSendButtonState()
        if (wasBusy) showThinking("↪️ 已收到新消息，上一轮结果将丢弃。正在切换到 AI 决策…")
        else showThinking("✦ AI 正在判断是否直接回答、需要澄清，或主动调用工具…")
        startQuestionWorkflow(question, requestId)
    }

    private fun interruptActiveResponse(statusMessage: String?) {
        NativeLlamaEngine.cancel(nativeModelHandle)
        activeRequestId += 1
        activeQuestionJob?.cancel()
        activeQuestionJob = null
        isBusy = false
        speechEngine?.stop()
        showThinking(null)
        if (statusMessage != null) statusText.text = statusMessage
        setActionButtonsEnabled(true)
        updateSendButtonState()
    }

    private fun updateSendButtonState() {
        if (!::sendButton.isInitialized) return
        val inputEmpty = !::promptInput.isInitialized || promptInput.text.isNullOrBlank()
        val canStop = (activeQuestionJob != null) && isBusy
        sendButton.text = if (inputEmpty && canStop) "■" else "➤"
        sendButton.contentDescription = if (inputEmpty && canStop) "停止当前回答" else "发送消息；生成中可发送新消息以中断当前回答"
        sendButton.isEnabled = !isModelTransferOrLoading
    }

    private fun startQuestionWorkflow(question: String, requestId: Long) {
        val trackedName = "消息处理 #$requestId"
        activeQuestionJob = lifecycleScope.launch {
            beginTrackedTask(trackedName, "已接收用户请求；不会在模型决策前调用计算、天气、定位或联网搜索工具。")
            try {
                updateTrackedTask(trackedName, "AI 决策与工具调度", "向当前模型提供真实工具清单；只有模型输出有效的显式工具调用后才进行权限校验和执行。", null)
                processQuestion(question)
                if (requestId == activeRequestId) {
                    finishTrackedTask(trackedName, true, "本轮 AI 决策/工具闭环结束；具体工具执行、结果回传和错误均以运行日志为准。")
                } else {
                    recordTaskJournalOnly(trackedName, "已被新请求替代", "此请求已被更新的用户请求取代；不覆盖新请求的当前状态。", "INTERRUPTED")
                }
            } catch (e: CancellationException) {
                recordTaskJournalOnly(trackedName, "已取消/被替代", "任务协程已取消；同步原生推理是否立即停止取决于底层接口，不能据此声称原生计算已被中止。", "INTERRUPTED")
            } catch (e: Exception) {
                if (requestId == activeRequestId) {
                    finishTrackedTask(trackedName, false, "处理失败：${e.message ?: e.javaClass.simpleName}")
                    showThinking(null)
                    appendTranscript("小提示", "处理失败：${e.message ?: "未知错误"}")
                    statusText.text = "处理失败，请稍后重试。"
                } else {
                    recordTaskJournalOnly(trackedName, "处理失败/被替代", "${e.message ?: e.javaClass.simpleName}；不覆盖新请求状态。", "FAILED")
                }
            } finally {
                if (requestId == activeRequestId) {
                    activeQuestionJob = null
                    isBusy = false
                    setActionButtonsEnabled(true)
                    updateSendButtonState()
                    if (::promptInput.isInitialized) promptInput.requestFocus()
                }
            }
        }
        updateSendButtonState()
    }

    /** Greetings and simple social turns do not need a 4B model pass and cannot invoke tools. */
    private fun instantSocialReply(question: String): String? {
        val q = question.trim().lowercase(Locale.ROOT)
            .replace(Regex("[，。！？!?,.\\s~～]+$"), "")
        return when (q) {
            "你好", "您好", "嗨", "哈喽", "hello", "hi", "hey", "下午好", "早上好", "中午好", "晚上好" ->
                "你好呀，我在呢。今天想聊点什么？"
            "在吗", "你在吗", "有人吗" -> "在呢，我在听。怎么啦？"
            "谢谢", "感谢", "谢谢你", "多谢" -> "不客气～能帮上忙就好。"
            "晚安", "睡了", "我去睡了" -> "晚安，早点休息。明天再聊也可以。"
            "拜拜", "再见", "回头见" -> "好呀，回头见。"
            else -> null
        }
    }

    private suspend fun processQuestion(question: String) {
        currentCoroutineContext().ensureActive()
        val fastExpression = directMathExpression(question)
        if (fastExpression.isNotBlank()) {
            val fastValue = executeSafePythonExpression(fastExpression)
            if (!fastValue.startsWith("ERROR:")) {
                AppDiagnostics.log(this, "INFO", "local_math_fast_path", "accepted=true; expressionChars=${fastExpression.length}; resultChars=${fastValue.length}; elapsedClass=bounded_expression_evaluator")
                history.add(question to fastValue)
                showThinking(null)
                appendTranscript(aiDisplayName(), fastValue)
                speakAnswer(fastValue)
                statusText.text = "本地安全算术完成 · 未启动语言模型"
                return
            }
            AppDiagnostics.log(this, "WARN", "local_math_fast_path", "accepted=false; reason=expression_evaluator_error; falling_back_to_model=true")
        }
        val instantSocialAnswer = instantSocialReply(question)
        if (instantSocialAnswer != null) {
            updateTrackedTask("消息处理 #$activeRequestId", "即时闲聊回复", "纯问候/礼貌回应直接返回，不启动模型推理或工具清单预填充。", null)
            currentCoroutineContext().ensureActive()
            history.add(question to instantSocialAnswer)
            showThinking(null)
            appendTranscript(aiDisplayName(), instantSocialAnswer)
            speakAnswer(instantSocialAnswer)
            statusText.text = "快速回应完成 · 无需调用语言模型"
            return
        }
        val generator = generateReply
        if (generator == null) {
            showThinking(null)
            appendTranscript(aiDisplayName(), "当前没有加载可用的本地模型。工具执行必须由 AI 先判断并发起调用，请先加载 GGUF 模型后再试。")
            statusText.text = "需要加载本地模型；未执行任何工具。"
            return
        }
        updateTrackedTask("消息处理 #$activeRequestId", "交给 AI 判断", "先生成模型回答；未出现显式调用标记时，不执行任何工具。", null)
        runLocalAnswer(question, generator)
    }

    /** Deterministically recalls saved user turns before invoking a small local model. */
    private fun recallCurrentConversation(question: String): String? {
        val q = question.trim()
        val asksAboutPriorTurns = Regex("""(我.{0,10}(前面|之前|刚才|刚刚).{0,18}(问|说).{0,14}(什么|哪些|哪几|几句|什么问题)|前面.{0,12}(问|说).{0,12}(什么|哪些|哪几)|刚才问过什么|我问了你什么|我之前问了什么|我前面问了什么|上(个|一个|一条)问题|刚才(我)?问的(什么|是什么))""").containsMatchIn(q)
        if (!asksAboutPriorTurns) return null
        val priorUserMessages = transcript.dropLast(1).filter { it.isUser && it.message.isNotBlank() }
        if (priorUserMessages.isEmpty()) return "我检查了当前话题的已保存聊天记录，但在你这条消息之前没有找到可回顾的用户问题。"
        val asksMultiple = Regex("""(哪些|哪几|几句|几个问题|都问了什么|全部问题|前面问了|之前问了|刚才问了|我问了你什么|我之前问了什么|我前面问了什么)""").containsMatchIn(q)
        if (!asksMultiple) return "你上一个问题问的是：${priorUserMessages.last().message}"
        val recent = priorUserMessages.takeLast(5)
        return buildString {
            append("我查了当前话题里保存的聊天记录，你前面最近问过这些：\n")
            recent.forEachIndexed { index, line -> append(index + 1).append(". ").append(line.message.trim().take(450)).append('\n') }
            append("我依据的是当前话题的已保存消息；如果你问的是另一个聊天话题，切回那个话题后我再帮你回顾。")
        }
    }

    /** Include more recent turns while keeping a bounded prompt for smaller local models. */
    private fun buildCurrentConversationContext(currentQuestion: String, maxChars: Int = 6800): String {
        val lines = transcript.dropLast(1).filterNot { line ->
            !line.isUser && (line.who.contains("思考") || line.who.contains("来源") || line.who.contains("搜索") || line.who.contains("提示") || line.who.contains("失败") || line.who.contains("加载"))
        }.takeLast(24)
        val chosen = mutableListOf<String>()
        var used = 0
        val contextBudget = maxChars.coerceIn(120, 7200)
        for (line in lines.asReversed()) {
            if (used >= contextBudget) break
            val speaker = if (line.isUser) "用户" else "助手"
            val text = line.message.trim().take(if (line.isUser) 620 else 900)
            if (text.isBlank()) continue
            val piece = "$speaker：$text"
            val allowance = contextBudget - used
            chosen.add(piece.take(allowance))
            used += minOf(piece.length, allowance)
        }
        return "当前话题的历史对话（来自本地保存的真实聊天记录，优先保留最近 24 条有效消息；请在回答前检查这些上下文）：\n" + chosen.asReversed().joinToString("\n")
    }

    private fun refreshChatAndRepair() {
        if (isModelTransferOrLoading) {
            statusText.text = "模型正在加载或导入，完成后再刷新更安全。"
            return
        }
        if (activeQuestionJob != null) {
            interruptActiveResponse("已刷新聊天状态；上一轮回答已停止。")
        }
        // Rebind the view to the current persisted session and reset stale UI flags.
        sessions.firstOrNull { it.id == currentSessionId }?.let { session -> transcript = session.messages }
        history.clear()
        var lastQuestion: String? = null
        transcript.forEach { line ->
            if (line.isUser) lastQuestion = line.message
            else if (lastQuestion != null && !line.who.contains("思考") && !line.who.contains("来源") && !line.who.contains("搜索") && !line.who.contains("提示") && !line.who.contains("失败")) {
                history.add(lastQuestion!! to line.message)
                lastQuestion = null
            }
        }
        showThinking(null)
        buildInterface()
        if (generateReply == null) {
            statusText.text = if (modelFile.exists() && modelFile.length() > 0L) "聊天界面已刷新，但模型尚未就绪；请点「加载模型」。" else "聊天界面已刷新；请先选择并加载 GGUF 模型。"
        } else {
            statusText.text = "聊天界面已刷新，当前话题记录已重新绑定，可以继续发送消息。"
        }
        Toast.makeText(this, "聊天状态已刷新", Toast.LENGTH_SHORT).show()
    }

    private fun unloadLocalModel() {
        if (isBusy || modelInferenceActive || isModelTransferOrLoading) {
            statusText.text = "当前模型正在处理任务，先停止回答或等待任务结束，再退出模型。"
            return
        }
        val release = releaseModel
        if (release == null || generateReply == null) {
            statusText.text = "当前没有已加载的模型。你可以选择文件后再加载。"
            return
        }
        isBusy = true
        isModelTransferOrLoading = true
        setActionButtonsEnabled(false)
        beginTrackedTask("模型释放", "准备释放当前本地模型；模型文件与聊天/记忆数据会保留。")
        updateTrackedTask("模型释放", "等待安全释放", "在后台线程释放当前模型句柄；此处只显示实际阶段，不估算释放百分比。", null)
        showThinking("⏏ 正在释放模型占用的内存…")
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { release.invoke() }
                finishTrackedTask("模型释放", true, "当前模型句柄已释放；原始模型文件与聊天/记忆数据未删除。")
                generateReply = null
                releaseModel = null
                nativeModelHandle = 0L
                nativeDraftModelHandle = 0L
                loadedModelFileName = null
                loadedModelProfile = null
                updateModeButton()
                statusText.text = "模型已退出，模型文件仍保留。你可以选择其他 GGUF 文件或重新加载。"
                Toast.makeText(this@MainActivity, "模型已退出", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                finishTrackedTask("模型释放", false, "释放模型失败：${e.message ?: e.javaClass.simpleName}")
                statusText.text = "退出模型时出现问题：${e.message ?: "未知错误"}"
            } finally {
                showThinking(null)
                isBusy = false
                isModelTransferOrLoading = false
                setActionButtonsEnabled(true)
                updateSendButtonState()
            }
        }
    }


    /**
     * Classifies short social/conversational turns for response-style budgeting only.
     * This function MUST NOT select, execute, or dispatch tools.
     */
    private fun isCasualMessage(question: String): Boolean {
        val q = question.trim()
            .trimEnd('。', '！', '？', '!', '?', '…', '.', ',', '，')
            .lowercase()
        if (q.isBlank() || q.length > 40) return false

        val exact = setOf(
            "你好", "您好", "嗨", "哈喽", "嘿", "hello", "hi", "hey",
            "在吗", "谢谢", "感谢", "好的", "好吧", "好", "嗯", "嗯嗯", "哦", "噢",
            "啊", "是的", "没错", "对", "行", "可以", "收到", "明白了",
            "晚安", "早安", "早上好", "晚上好", "再见", "拜拜", "辛苦了",
            "我回来了", "继续聊聊", "哈哈", "呵呵", "笑死", "笑死了", "真的吗"
        )
        if (q in exact) return true

        return Regex(
            "^(你好|您好|嗨+|哈喽+|嘿+|hello+|hi+|hey+|在吗|谢谢|感谢|好的|好吧|嗯+|哦+|噢+|啊+|哈哈+|呵呵+|再见|拜拜|晚安|早安|早上好|晚上好|笑死了?)[呀啊哦呢嘛吧哇～~！!，,。 ]*$",
            RegexOption.IGNORE_CASE
        ).matches(q)
    }

    private fun classifyQuestion(question: String): ResponseEffort {
        val q = question.trim()
        if (q.isEmpty()) return ResponseEffort.INSTANT
        if (directMathExpression(q).isNotBlank() || isCasualMessage(q)) return ResponseEffort.INSTANT
        val veryDeepMarkers = listOf("深度研究", "全面研究", "完整报告", "系统性分析", "从历史到现在", "详细推导", "长篇", "全面比较", "研究论文")
        val complexMarkers = listOf("为什么", "原理", "机制", "推导", "分析", "比较", "对比", "利弊", "影响", "方案", "架构", "设计", "排查", "调试", "如何实现", "怎么解决", "总结", "详细解释")
        if (veryDeepMarkers.any { q.contains(it, ignoreCase = true) } || q.length >= 180) return ResponseEffort.VERY_COMPLEX
        if (complexMarkers.any { q.contains(it, ignoreCase = true) } || q.length >= 90) return ResponseEffort.COMPLEX
        val basicLiveMarkers = listOf("最新", "今天", "现在", "实时", "新闻", "天气", "价格", "汇率", "股价", "排名")
        if (q.length <= 32 && basicLiveMarkers.none { q.contains(it, ignoreCase = true) } && listOf("怎么", "如何", "为什么", "区别", "原理", "详细", "分析", "解释", "步骤").none { q.contains(it) }) return ResponseEffort.SIMPLE
        return ResponseEffort.NORMAL
    }

    private fun directMathExpression(question: String): String = LocalizedMathExpression.direct(question)

    private fun hasLocationPermission(): Boolean = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private suspend fun getCurrentLocationOnce(): Location? = withContext(Dispatchers.Main) {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        if (!hasLocationPermission()) return@withContext null
        val fineGranted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val providers = mutableListOf<String>()
        // Request a fresh fix from each usable provider in parallel. Choosing NETWORK alone can
        // hang/fail on some devices even though GPS has a valid fix, and vice versa.
        if (fineGranted && runCatching { manager.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)) {
            providers.add(LocationManager.GPS_PROVIDER)
        }
        if (runCatching { manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)) {
            providers.add(LocationManager.NETWORK_PROVIDER)
        }
        if (providers.isEmpty()) return@withContext null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val freshLocations = coroutineScope {
                providers.map { provider ->
                    async(Dispatchers.Main.immediate) {
                        withTimeoutOrNull(6_500L) { requestFreshLocation(manager, provider) }
                    }
                }.awaitAll().filterNotNull()
            }
            val now = System.currentTimeMillis()
            val freshBest = freshLocations
                .filter { now - it.time in 0..120_000L }
                .maxWithOrNull(compareBy<Location> { it.time }.thenBy { -it.accuracy })
            if (freshBest != null) return@withContext freshBest
        }

        // If the provider cannot produce a new fix, only accept a reasonably recent cached fix.
        // Avoid silently reporting a location that is many hours or days old as current.
        val now = System.currentTimeMillis()
        providers.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.filter { now - it.time in 0..900_000L }
            .maxWithOrNull(compareBy<Location> { it.time }.thenBy { -it.accuracy })
    }

    @android.annotation.SuppressLint("MissingPermission")
    private suspend fun requestFreshLocation(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            try {
                val signal = CancellationSignal()
                continuation.invokeOnCancellation { signal.cancel() }
                manager.getCurrentLocation(provider, signal, mainExecutor, Consumer { location ->
                    if (continuation.isActive) continuation.resume(location)
                })
            } catch (_: SecurityException) {
                if (continuation.isActive) continuation.resume(null)
            } catch (_: Exception) {
                if (continuation.isActive) continuation.resume(null)
            }
        }

    private suspend fun saveLocationPersonalization(location: Location) {
        val label = withContext(Dispatchers.IO) {
            try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val addresses = Geocoder(this@MainActivity, Locale.SIMPLIFIED_CHINESE).getFromLocation(location.latitude, location.longitude, 1)
                    val address = addresses?.firstOrNull()
                    listOfNotNull(address?.locality, address?.subAdminArea, address?.adminArea, address?.countryName)
                        .distinct().joinToString("、").ifBlank { "已获取位置（附近城市暂不可识别）" }
                } else "已获取位置（附近城市暂不可识别）"
            } catch (_: Exception) { "已获取位置（附近城市暂不可识别）" }
        }
        preferences.edit().putString("last_location_label", label).putString("last_location_lat", location.latitude.toString())
            .putString("last_location_lon", location.longitude.toString()).putLong("last_location_time", System.currentTimeMillis()).apply()
    }

    private suspend fun fetchWeatherForPlace(place: String): Pair<String, String>? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val encoded = URLEncoder.encode(place, "UTF-8")
            val endpoint = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=zh&format=json"
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Accept", "application/json")
            }
            if (connection.responseCode !in 200..299) return@withContext null
            val root = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val result = root.optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
            val lat = result.optDouble("latitude", Double.NaN)
            val lon = result.optDouble("longitude", Double.NaN)
            if (!lat.isFinite() || !lon.isFinite()) return@withContext null
            val placeName = listOf(result.optString("name"), result.optString("admin1"), result.optString("country")).filter { it.isNotBlank() }.distinct().joinToString("、").ifBlank { place }
            val weather = fetchWeather(lat, lon) ?: return@withContext null
            placeName to weather
        } catch (_: Exception) {
            null
        } finally { connection?.disconnect() }
    }

    private suspend fun fetchWeather(latitude: Double, longitude: Double): String? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val endpoint = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1"
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("Accept", "application/json")
            }
            if (connection.responseCode !in 200..299) return@withContext null
            val json = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val current = json.optJSONObject("current") ?: return@withContext null
            val daily = json.optJSONObject("daily")
            val code = current.optInt("weather_code", -1)
            val weatherText = weatherCodeToChinese(code)
            val out = StringBuilder()
            out.append("当前天气：").append(weatherText)
            if (current.has("temperature_2m")) out.append("；气温 ").append(formatWeatherNumber(current.optDouble("temperature_2m"))).append("°C")
            if (current.has("apparent_temperature")) out.append("；体感温度 ").append(formatWeatherNumber(current.optDouble("apparent_temperature"))).append("°C")
            if (current.has("relative_humidity_2m")) out.append("；相对湿度 ").append(current.optInt("relative_humidity_2m")).append("%")
            if (current.has("wind_speed_10m")) out.append("；风速 ").append(current.optDouble("wind_speed_10m")).append(" km/h")
            if (daily != null) {
                val highs = daily.optJSONArray("temperature_2m_max")
                val lows = daily.optJSONArray("temperature_2m_min")
                val rain = daily.optJSONArray("precipitation_probability_max")
                if (highs != null && highs.length() > 0 && lows != null && lows.length() > 0) out.append("；今日最高/最低 ").append(formatWeatherNumber(highs.optDouble(0))).append("/ ").append(formatWeatherNumber(lows.optDouble(0))).append("°C")
                if (rain != null && rain.length() > 0) out.append("；今日降水概率 ").append(rain.optInt(0)).append("%")
            }
            out.append("。观测/预报数据时间：").append(current.optString("time", "未提供"))
            out.toString()
        } catch (_: Exception) {
            null
        } finally { connection?.disconnect() }
    }

    private fun formatWeatherNumber(value: Double): String = String.format(Locale.US, "%.1f", value).removeSuffix(".0")

    private fun weatherCodeToChinese(code: Int): String = when (code) {
        0 -> "晴朗"
        1 -> "大致晴朗"
        2 -> "局部多云"
        3 -> "阴天"
        45, 48 -> "有雾"
        51, 53, 55 -> "毛毛雨"
        56, 57 -> "冻毛毛雨"
        61, 63, 65 -> "下雨"
        66, 67 -> "冻雨"
        71, 73, 75, 77 -> "降雪或雪粒"
        80, 81, 82 -> "阵雨"
        85, 86 -> "阵雪"
        95 -> "雷暴"
        96, 99 -> "可能有冰雹的雷暴"
        else -> "天气状况未知"
    }

    /** Short answers usually stand alone; only selector/follow-up language earns history tokens. */
    private fun needsRecentConversationContext(question: String): Boolean {
        val q = question.trim()
        if (q.isBlank()) return false
        if (q.matches(Regex("""^(?:\d{1,2}|[A-Da-d]|[一二三四五六七八九十]|是|不是|对|不对)$"""))) return true
        val markers = listOf(
            "然后", "接下来", "下一步", "继续", "刚才", "前面", "上面", "上一条", "你刚才", "你说的", "你提到",
            "这个", "那个", "这些", "这种", "那怎么办", "那这样", "按之前", "照你说的", "第一个", "第二个",
            "第三个", "选项", "方案", "这次", "这项", "原来那个", "刚才的", "怎么理解", "还有呢"
        )
        if (q in listOf("为什么", "怎么回事", "真的吗", "然后呢", "怎么办")) return true
        if (markers.any { q.contains(it) }) return true
        // Pronoun-led follow-ups need context, while ordinary stand-alone questions stay on the fast path.
        return Regex("""^(它|他|她)(呢|怎么样|怎么回事|为什么|要怎么办|怎么办|呢[？?]?)$""").containsMatchIn(q)
    }

    private suspend fun runModelWithTools(
        initialPrompt: String,
        generator: suspend (String, Boolean) -> ModelReply
    ): ModelReply {
        var currentPrompt = initialPrompt
        var executedCalls = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val reply = withContext(Dispatchers.IO) { generator(currentPrompt, false) }
            val parsed = AiToolRegistry.parseResponse(reply.answer)
            if (!parsed.containsCallMarker) return reply
            val call = parsed.call
            if (call == null) {
                val error = parsed.error ?: "工具调用标记无效。"
                AppDiagnostics.log(this, "WARN", "ai_tool_call_invalid", "round=$executedCalls; reason=${error.take(200)}")
                if (executedCalls >= AiToolRegistry.MAX_TOOL_CALLS_PER_TURN) {
                    return ModelReply("本轮工具调用协议连续无效，已停止继续尝试。原因：$error")
                }
                currentPrompt = AiToolRegistry.appendToolResult(currentPrompt, "invalid_call", AiToolExecutionResult(false, error), activeQuestionText)
                executedCalls++
                continue
            }
            if (executedCalls >= AiToolRegistry.MAX_TOOL_CALLS_PER_TURN) {
                AppDiagnostics.log(this, "WARN", "ai_tool_call_limit", "limit=${AiToolRegistry.MAX_TOOL_CALLS_PER_TURN}; extraTool=${call.name.take(80)}; executed=$executedCalls")
                val exhaustedPrompt = AiToolRegistry.appendToolResult(
                    currentPrompt, call.name,
                    AiToolExecutionResult(false, "本轮最多执行 ${AiToolRegistry.MAX_TOOL_CALLS_PER_TURN} 次工具调用；这次请求未执行。请现在直接给出最终回答，不要再请求工具。"),
                    activeQuestionText
                ) + "\n\n本轮工具调用预算已耗尽，必须直接给出最终用户回答，不再输出任何工具调用标记。"
                val finalReply = withContext(Dispatchers.IO) { generator(exhaustedPrompt, false) }
                val finalParse = AiToolRegistry.parseResponse(finalReply.answer)
                return if (finalParse.containsCallMarker) {
                    ModelReply(finalParse.call?.let { "本轮工具调用已达到安全上限；未执行额外的 ${it.name} 请求。请用户发起新一轮问题继续。" }
                        ?: "本轮工具调用已达到安全上限，且模型再次输出了无效工具协议。请用户发起新一轮问题继续。", finalReply.reasoning)
                } else finalReply
            }
            val toolStartedAt = android.os.SystemClock.elapsedRealtime()
            val result = executeAiToolCall(call)
            val toolElapsedMs = android.os.SystemClock.elapsedRealtime() - toolStartedAt
            AppDiagnostics.log(
                this,
                if (result.success) "INFO" else "WARN",
                "ai_tool_execution",
                "tool=${call.name.take(80)}; success=${result.success}; elapsedMs=$toolElapsedMs; resultChars=${result.content.length}; round=${executedCalls + 1}"
            )
            currentPrompt = AiToolRegistry.appendToolResult(currentPrompt, call.name, result, activeQuestionText)
            executedCalls++
        }
    }

    private suspend fun executeAiToolCall(call: AiToolCall): AiToolExecutionResult {
        val validationError = AiToolRegistry.validate(call, webSearchEnabled)
        if (validationError != null) {
            AppDiagnostics.log(this, "WARN", "ai_tool_call_rejected", "tool=${call.name.take(80)}; reason=${validationError.take(220)}")
            return AiToolExecutionResult(false, validationError)
        }
        return try {
            when (call.name) {
                "python" -> {
                    val expression = call.arguments["expression"] as String
                    val output = executeSafePythonExpression(expression)
                    if (output.startsWith("ERROR:")) AiToolExecutionResult(false, output)
                    else AiToolExecutionResult(true, output)
                }
                "code_sandbox" -> {
                    val code = call.arguments["code"] as String
                    val output = executeSafeCodeSandbox(code)
                    if (output.startsWith("ERROR:")) AiToolExecutionResult(false, output)
                    else AiToolExecutionResult(true, output)
                }
                "web_search" -> {
                    val query = (call.arguments["query"] as String).trim()
                    val results = withTimeoutOrNull(10_000L) {
                        withContext(Dispatchers.IO) { fetchSearchResults(query) }
                    } ?: throw IllegalStateException("联网搜索超过 10 秒仍未返回结果。")
                    AiToolExecutionResult(true, formatSearchResults(results).take(9000))
                }
                "weather" -> {
                    val city = (call.arguments["city"] as? String).orEmpty().trim()
                    val useDeviceLocation = call.arguments["use_device_location"] as? Boolean ?: false
                    if (city.isNotBlank()) {
                        val response = withTimeoutOrNull(12_000L) { fetchWeatherForPlace(city) }
                            ?: throw IllegalStateException("天气服务在 12 秒内没有返回有效数据。")
                        AiToolExecutionResult(true, "${response.first}：${response.second}")
                    } else if (useDeviceLocation) {
                        if (!ensureLocationPermissionForAiTool()) throw IllegalStateException("用户未授予位置权限；未读取位置。请询问用户城市名称或等待用户授权。")
                        val location = withTimeoutOrNull(12_000L) { getCurrentLocationOnce() }
                            ?: throw IllegalStateException("没有获取到本次请求的有效位置；未查询或猜测天气。")
                        saveLocationPersonalization(location)
                        val weather = withTimeoutOrNull(12_000L) { fetchWeather(location.latitude, location.longitude) }
                            ?: throw IllegalStateException("已取得位置，但天气服务没有返回数据。")
                        val place = preferences.getString("last_location_label", "你附近").orEmpty().ifBlank { "你附近" }
                        AiToolExecutionResult(true, "$place：$weather")
                    } else {
                        throw IllegalArgumentException("必须提供城市，或明确请求 use_device_location=true。")
                    }
                }
                "location" -> {
                    if (!ensureLocationPermissionForAiTool()) throw IllegalStateException("用户未授予位置权限；未读取位置。")
                    val location = withTimeoutOrNull(12_000L) { getCurrentLocationOnce() }
                        ?: throw IllegalStateException("没有获取到本次请求的有效位置。")
                    saveLocationPersonalization(location)
                    val label = preferences.getString("last_location_label", "").orEmpty().ifBlank { "位置已读取，但未能解析到具体城市" }
                    AiToolExecutionResult(true, "$label（本次按需读取；不进行后台跟踪）")
                }
                // This is an explicit deny-by-construction backstop; these names are not registered.
                "calculator", "computer", "manual_calculator" -> AiToolExecutionResult(false, "AI 无权调用用户专用计算器；该请求已拒绝。")
                else -> AiToolExecutionResult(false, "未知工具或权限不足：${call.name.take(80)}")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AppDiagnostics.logThrowable(this, "WARN", "ai_tool_execution_failed", "tool=${call.name.take(80)}; ${e.javaClass.simpleName}", e)
            AiToolExecutionResult(false, "工具执行失败：${e.message ?: e.javaClass.simpleName}。本次没有获得成功结果。")
        }
    }

    private suspend fun ensureLocationPermissionForAiTool(): Boolean {
        if (hasLocationPermission()) return true
        val deferred = CompletableDeferred<Boolean>()
        withContext(Dispatchers.Main.immediate) {
            if (hasLocationPermission()) {
                deferred.complete(true)
            } else {
                pendingToolLocationPermission = deferred
                requestLocationPermissions.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            }
        }
        return try {
            withTimeoutOrNull(60_000L) { deferred.await() } ?: false
        } finally {
            withContext(Dispatchers.Main.immediate) {
                if (pendingToolLocationPermission === deferred) pendingToolLocationPermission = null
            }
        }
    }

    private suspend fun executeSafePythonExpression(expression: String): String {
        if (expression.isBlank() || expression.length > 180) return "ERROR: 表达式为空或超过 180 字符"
        return withTimeoutOrNull(5_000L) {
            withContext(Dispatchers.Main.immediate) {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this@MainActivity))
            }
            withContext(Dispatchers.IO) {
                Python.getInstance().getModule("calculator").callAttr("evaluate", expression).toString()
            }
        } ?: "ERROR: Python 数学计算超过 5 秒，已停止等待。"
    }

    private suspend fun executeSafeCodeSandbox(code: String): String {
        if (code.isBlank() || code.length > 12000) return "ERROR: 代码为空或超过 12000 字符"
        val start = android.os.SystemClock.elapsedRealtime()
        return withTimeoutOrNull(35_000L) {
            withContext(Dispatchers.Main.immediate) {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this@MainActivity))
            }
            withContext(Dispatchers.IO) {
                val result = Python.getInstance().getModule("code_sandbox")
                    .callAttr("run", code, 30000, 100000, 20000).toString()
                AppDiagnostics.log(this@MainActivity, if (result.startsWith("ERROR:")) "WARN" else "INFO", "code_sandbox_execution",
                    "elapsedMs=${android.os.SystemClock.elapsedRealtime() - start}; codeChars=${code.length}; resultChars=${result.length}; outcome=${if (result.startsWith("ERROR:")) "error" else "success"}; isolation=restricted_ast_interpreter_no_os_sandbox")
                result
            }
        } ?: "ERROR: 沙箱调用超过 35 秒；已停止等待。"
    }

    private suspend fun runLocalAnswer(question: String, generator: suspend (String, Boolean) -> ModelReply) {
        updateTrackedTask("消息处理 #$activeRequestId", "构建本地提示词", "按回答模式截取历史与个性化上下文；短闲聊走更短的输入路径。", null)
        showThinking(when {
            fastMode -> "⚡ 快速模式：正在生成 1–3 句短答；正文会随原生 Token 回调逐步预览。"
            responseModeIndex == 1 -> "🧠 正在整理答案和关键步骤；正文会随 Token 回调逐步预览…"
            else -> "🧠 正在深度分析…正文会随 Token 回调逐步预览（效果取决于当前模型）"
        })
        val needsContext = needsRecentConversationContext(question)
        val contextPrompt = when {
            isCasualMessage(question) -> {
                // Short social turns skip saved history and long-term memories: less prompt prefill.
                "请用自然、简短、友好的简体中文回应用户。保持对话感，直接接话，不要无故搜索或长篇解释。\n用户：${question.take(160)}\n助手："
            }
            fastMode && !needsContext -> {
                // Fast path: no old turns or memory recap for independent questions.
                "请直接、简洁地回答当前问题；不要复述问题，不要展开无关推理。\n用户：${question.take(1600)}\n助手："
            }
            !needsContext -> {
                // The selected response style may be detailed, but an independent question still
                // does not need unrelated transcript tokens in the prefill sequence.
                "请回答当前问题；只有用户明确引用前文时才使用历史，不要把旧聊天误当成当前输入。\n用户：${question.take(1600)}\n助手："
            }
            else -> buildString {
                val contextBudget = when {
                    fastMode -> if (needsContext) 300 else 180
                    responseModeIndex == 1 -> 2600
                    else -> 5200
                }
                append(buildCurrentConversationContext(question, contextBudget))
                append("\n用户：").append(question.take(1600)).append("\n助手：")
            }
        }
        val startedAt = android.os.SystemClock.elapsedRealtime()
        val reply = coroutineScope {
            // Keep elapsed status visible while JNI token callbacks update the live text preview.
            val waitTicker = launch(Dispatchers.Main.immediate) {
                while (true) {
                    delay(1_000)
                    val elapsedSeconds = (android.os.SystemClock.elapsedRealtime() - startedAt) / 1000L
                    statusText.text = if (fastMode) {
                        "快速回答 · 本地模型生成中 · 已等待 ${elapsedSeconds} 秒（正文随 Token 逐步预览）"
                    } else {
                        "本地模型生成中 · 已等待 ${elapsedSeconds} 秒 · 正文随 Token 逐步预览"
                    }
                }
            }
            try {
                runModelWithTools(contextPrompt, generator)
            } finally {
                waitTicker.cancel()
            }
        }
        currentCoroutineContext().ensureActive()
        val seconds = (android.os.SystemClock.elapsedRealtime() - startedAt) / 1000.0
        history.add(question to reply.answer)
        showThinking(null)
        appendReply(reply, aiDisplayName())
        speakAnswer(reply.answer)
        val modeLabel = currentModelModeLabels().getOrElse(responseModeIndex) { "详细回答" }
        statusText.text = String.format(Locale.CHINA, "回答完成 · 本地推理 · %.1f 秒 · %s模式", seconds, modeLabel)
    }

    private fun normalizeSearchQuery(question: String): String {
        var query = question.trim()
        val fillerPhrases = listOf(
            "请你帮我联网搜索一下", "帮我联网搜索一下", "请帮我搜索一下", "帮我搜索一下", "请帮我查一下", "帮我查一下",
            "你帮我查一下", "帮我查查", "请你查查", "请搜索一下", "联网搜索一下", "联网搜索", "请问一下", "麻烦你",
            "能不能帮我", "你能不能", "可以帮我", "请帮我", "帮我", "搜索一下", "查一下", "查询一下", "查一查", "查查",
            "告诉我一下", "给我看看", "一下就好", "好吗"
        )
        fillerPhrases.forEach { query = query.replace(it, " ", ignoreCase = true) }
        query = query.replace(Regex("[，。！？!?、,；;：:]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return query.ifBlank { question.trim() }.take(160)
    }

    private fun searchKeywords(question: String): List<String> {
        val query = normalizeSearchQuery(question).lowercase(Locale.ROOT)
        val keywords = linkedSetOf<String>()
        val stopWords = setOf("帮我", "请问", "一下", "这个", "那个", "怎么", "如何", "为什么", "什么", "现在", "目前", "请你", "一下", "告诉我", "搜索", "查询")
        Regex("[a-z0-9][a-z0-9._+/-]{1,}", RegexOption.IGNORE_CASE).findAll(query)
            .map { it.value.trim('.', '/', '+', '-') }
            .filter { it.length >= 2 && it !in stopWords }
            .forEach { keywords.add(it) }
        Regex("[\\u4e00-\\u9fff]{2,}").findAll(query).forEach { match ->
            val phrase = match.value
            if (phrase.length <= 5 && phrase !in stopWords) keywords.add(phrase)
            if (phrase.length > 5) {
                keywords.add(phrase.take(5))
                for (i in 0 until phrase.length - 1) keywords.add(phrase.substring(i, i + 2))
            }
        }
        return keywords.take(28)
    }

    private fun rankSearchResults(question: String, results: List<WebResult>): List<WebResult> {
        val keywords = searchKeywords(question)
        if (keywords.isEmpty()) return results
        return results.withIndex().sortedWith(
            compareByDescending<IndexedValue<WebResult>> { indexed ->
                val title = indexed.value.title.lowercase(Locale.ROOT)
                val snippet = indexed.value.snippet.lowercase(Locale.ROOT)
                SearchSourcePolicy.authorityScore(indexed.value.url) * 4 +
                    keywords.sumOf { key -> (if (title.contains(key)) 3 else 0) + (if (snippet.contains(key)) 1 else 0) }
            }.thenBy { it.index }
        ).map { it.value }
    }

    private fun fetchSearchResults(query: String): List<WebResult> {
        val effectiveQuery = SearchSourcePolicy.queryFor(query)
        val encoded = URLEncoder.encode(effectiveQuery, "UTF-8")
        val browserAgent = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        val allResults = mutableListOf<WebResult>()
        val errors = mutableListOf<String>()

        // Query two independent search providers instead of treating Bing as a fallback only.
        // Bound each request and cap total results to keep mobile latency predictable.
        try {
            val doc = Jsoup.connect("https://html.duckduckgo.com/html/")
                .method(Connection.Method.GET).data("q", effectiveQuery).userAgent(browserAgent)
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.7").timeout(4_500).get()
            for (item in doc.select(".result")) {
                val anchor = item.selectFirst("a.result__a") ?: continue
                val title = anchor.text().trim()
                val url = resolveSearchUrl(anchor.absUrl("href").ifBlank { anchor.attr("href") })
                val snippet = item.selectFirst(".result__snippet")?.text()?.trim().orEmpty()
                if (title.isNotBlank() && url.startsWith("http") && allResults.none { it.url == url }) allResults.add(WebResult(title, url, snippet))
                if (allResults.size >= 5) break
            }
        } catch (e: Exception) { errors.add("DuckDuckGo: ${e.message.orEmpty().take(70)}") }

        try {
            val doc = Jsoup.connect("https://www.bing.com/search?q=$encoded").userAgent(browserAgent)
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.7").timeout(4_500).get()
            for (item in doc.select("li.b_algo")) {
                val anchor = item.selectFirst("h2 a") ?: continue
                val title = anchor.text().trim()
                val url = anchor.absUrl("href").ifBlank { anchor.attr("href") }
                val snippet = item.selectFirst(".b_caption p")?.text()?.trim() ?: item.selectFirst("p")?.text()?.trim().orEmpty()
                if (title.isNotBlank() && url.startsWith("http") && allResults.none { it.url == url }) allResults.add(WebResult(title, url, snippet))
                if (allResults.size >= 9) break
            }
        } catch (e: Exception) { errors.add("Bing: ${e.message.orEmpty().take(70)}") }

        if (allResults.isEmpty()) {
            throw IllegalStateException("搜索站点没有返回可用结果，可能被当前网络拦截。请检查网络后重试。${errors.firstOrNull()?.let { "（$it）" }.orEmpty()}")
        }
        return rankSearchResults(query, allResults).take(6)
    }

    private fun resolveSearchUrl(raw: String): String {
        if (raw.isBlank()) return ""
        return try {
            val uri = Uri.parse(raw)
            val redirect = uri.getQueryParameter("uddg")
            when {
                !redirect.isNullOrBlank() && redirect.startsWith("http") -> redirect
                raw.startsWith("//") -> "https:$raw"
                raw.startsWith("http://") || raw.startsWith("https://") -> raw
                else -> ""
            }
        } catch (_: Exception) { raw.takeIf { it.startsWith("http://") || it.startsWith("https://") }.orEmpty() }
    }

    private fun formatSearchResults(results: List<WebResult>): String = buildString {
        append("检索流程会尝试查询 DuckDuckGo 与 Bing；医疗、航天、经济、法律和学术问题会优先寻找 WHO、CDC、NASA、世界银行、政府法规或 PubMed 等来源。以下为相关来源与摘要：\n\n")
        results.forEachIndexed { index, item ->
            append("[").append(index + 1).append("] ").append(item.title).append("\n")
            if (item.snippet.isNotBlank()) append(item.snippet.take(320)).append("\n")
            append(item.url).append("\n\n")
        }
    }.trim()

    private fun parseModelReply(raw: String): ModelReply {
        // A reasoning model may put the explicit tool call at the end of <think>.
        // Preserve only a canonical standalone call for the dispatcher; never execute
        // a quoted call surrounded by visible prose.
        val thoughtPattern = Regex("(?is)<think>(.*?)(?:</think>|$)")
        val extractedToolCall = AiToolRegistry.extractExplicitToolCallBlock(raw)
        val reasoning = thoughtPattern.findAll(raw).map { match ->
            val block = match.groupValues[1]
            (if (extractedToolCall != null) block.replace(extractedToolCall, "") else block).trim()
        }.filter { it.isNotBlank() }.joinToString("\n\n").take(4000)
        if (extractedToolCall != null) return ModelReply(extractedToolCall, reasoning)

        val strippedThink = thoughtPattern.replace(raw, "")
        // Keep invalid protocol markers visible to parseResponse so it can return a
        // protocol error to the model instead of turning a malformed call into an empty answer.
        if (raw.contains("[[TOOL_CALL") || raw.contains("[[/TOOL_CALL")) {
            val candidate = strippedThink.trim().ifBlank { raw.trim() }
            return ModelReply(candidate, reasoning)
        }
        val answer = strippedThink.replace(Regex("(?m)^\\s*(assistant|助手|AI管家)\\s*[:：]\\s*"), "").trim()
        return ModelReply(answer.ifBlank { "模型这次没有生成明确答案，请换个问法再试试。" }, reasoning)
    }
    private fun appendReply(reply: ModelReply, who: String) {
        appendTranscript(who, reply.answer, reasoning = reply.reasoning)
    }

    private fun setActionButtonsEnabled(enabled: Boolean) {
        // Chat switches stay interactive during inference; a new turn uses the latest settings.
        // Only model transfer/loading locks controls because swapping a live native model is unsafe.
        val controlsReady = !isModelTransferOrLoading
        if (::sendButton.isInitialized) sendButton.isEnabled = controlsReady
        if (::searchButton.isInitialized) searchButton.isEnabled = controlsReady
        if (::modeButton.isInitialized) modeButton.isEnabled = controlsReady
        if (::voiceButton.isInitialized) voiceButton.isEnabled = controlsReady
        if (::voiceSettingsButton.isInitialized) voiceSettingsButton.isEnabled = controlsReady
        if (::loadButton.isInitialized) loadButton.isEnabled = controlsReady && generateReply == null && !modelInferenceActive
        if (::ejectButton.isInitialized) ejectButton.isEnabled = controlsReady && generateReply != null && !modelInferenceActive
        if (::refreshButton.isInitialized) refreshButton.isEnabled = controlsReady
        updateSendButtonState()
    }

    private fun appendTranscript(who: String, message: String, isUser: Boolean = false, reasoning: String = "") {
        val line = ChatLine(who, message, isUser, reasoning.take(4000))
        transcript.add(line)
        val session = sessions.firstOrNull { it.id == currentSessionId }
        if (session != null) {
            if (isUser && session.title.startsWith("新话题")) session.title = message.replace(Regex("\\s+"), " ").take(28).ifBlank { "新话题" }
            saveSessions()
        }
        if (::chatMessages.isInitialized && !isProfileScreen) renderTranscript(line)
    }

    private fun renderTranscript(line: ChatLine) {
        val userName = preferences.getString("profile_name", "我").orEmpty().ifBlank { "我" }
        val aiName = aiDisplayName()
        val systemLine = !line.isUser && (line.who.contains("思考") || line.who.contains("来源") || line.who.contains("搜索") || line.who.contains("失败") || line.who.contains("提示") || line.who.contains("小提示"))
        val label = when {
            line.isUser -> userName
            systemLine -> line.who
            else -> aiName
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (line.isUser) Gravity.END else Gravity.START
            setPadding(0, dp(1), 0, dp(2))
        }
        val identityAndBubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (line.isUser) Gravity.END else Gravity.START
            setPadding(0, 0, 0, 0)
        }
        val labelView = TextView(this).apply {
            text = label
            textSize = 11.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(when {
                line.isUser -> C_USER_NAME
                systemLine -> C_MINT
                else -> C_AI_NAME
            })
            gravity = if (line.isUser) Gravity.END else Gravity.START
            setPadding(dp(2), 0, dp(2), dp(4))
            maxWidth = dp((resources.displayMetrics.widthPixels / resources.displayMetrics.density * 0.70f).toInt().coerceAtLeast(180))
        }
        identityAndBubble.addView(labelView)
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(10))
            val fill = when {
                line.isUser -> C_USER_BUBBLE
                line.who.contains("思考") -> C_THINK_BUBBLE
                line.who.contains("来源") || line.who.contains("搜索") -> C_SOURCE_BUBBLE
                line.who.contains("失败") || line.who.contains("提示") -> C_ERROR_BUBBLE
                else -> C_AI_BUBBLE
            }
            val stroke = when {
                line.isUser -> C_BLUE_BRIGHT
                line.who.contains("思考") -> C_PURPLE
                line.who.contains("来源") || line.who.contains("搜索") -> C_STROKE
                else -> C_STROKE_SOFT
            }
            background = roundedGradient(fill, if (line.isUser) C_USER_BUBBLE_2 else fill, 18, stroke)
        }
        val maxBubbleWidth = (resources.displayMetrics.widthPixels / resources.displayMetrics.density * 0.70f).toInt().coerceAtLeast(180)
        val body = TextView(this).apply {
            text = line.message
            textSize = 14f
            setTextColor(C_TEXT)
            setLineSpacing(dp(2).toFloat(), 1.02f)
            maxWidth = dp(maxBubbleWidth)
            Linkify.addLinks(this, Linkify.WEB_URLS)
            movementMethod = LinkMovementMethod.getInstance()
            linksClickable = true
        }
        bubble.addView(body)
        if (!line.isUser && !systemLine && line.reasoning.isNotBlank()) {
            val reasoningBody = TextView(this).apply {
                text = line.reasoning
                textSize = 12f
                setTextColor(C_MUTED)
                setLineSpacing(dp(2).toFloat(), 1.0f)
                maxWidth = dp(maxBubbleWidth)
                visibility = View.GONE
                setPadding(dp(2), dp(5), dp(2), dp(2))
            }
            val reasoningToggle = TextView(this).apply {
                text = "⌄ 思考记录（点此展开）"
                textSize = 11.5f
                setTextColor(C_BLUE_TEXT)
                setPadding(dp(2), dp(7), dp(2), dp(2))
                contentDescription = "展开或收起模型生成的思考记录"
                setOnClickListener {
                    val expanded = reasoningBody.visibility != View.VISIBLE
                    reasoningBody.visibility = if (expanded) View.VISIBLE else View.GONE
                    text = if (expanded) "⌃ 思考记录（点此收起）" else "⌄ 思考记录（点此展开）"
                }
            }
            bubble.addView(reasoningToggle)
            bubble.addView(reasoningBody)
        }
        identityAndBubble.addView(bubble)
        if (!line.isUser && !systemLine && line.message.isNotBlank()) {
            val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.START; setPadding(dp(2), dp(4), 0, 0) }
            val readButton = styledButton("▶ 朗读本条", C_PANEL_2, C_BLUE_TEXT, C_STROKE_SOFT).apply {
                textSize = 11f
                minHeight = dp(30)
                setPadding(dp(9), 0, dp(9), 0)
                setOnClickListener {
                    val id = "line-${System.identityHashCode(line)}-${System.nanoTime()}"
                    if (activeSpeechButton === this && activeSpeechId != null) {
                        stopSpeechPlayback()
                    } else {
                        speakText(line.message, id, this)
                    }
                }
            }
            controls.addView(readButton, LinearLayout.LayoutParams(-2, dp(31)))
            identityAndBubble.addView(controls)
        }
        if (!line.isUser) row.addView(createAvatarView(true, 34), LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(6); topMargin = dp(2) })
        row.addView(identityAndBubble, LinearLayout.LayoutParams(-2, -2).apply { if (line.isUser) marginStart = dp(3) else marginEnd = dp(3) })
        if (line.isUser) row.addView(createAvatarView(false, 34), LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginStart = dp(6); topMargin = dp(2) })
        chatMessages.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format(Locale.CHINA, "%.2f GB", mb / 1024.0) else String.format(Locale.CHINA, "%.0f MB", mb)
    }

    override fun onBackPressed() {
        when {
            isPersonalizationScreen -> showProfileScreen()
            isMoreFeaturesScreen -> showProfileScreen()
            isProfileScreen -> buildInterface()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        taskCenterTicker?.cancel()
        taskCenterTicker = null
        val release = releaseModel
        releaseModel = null
        generateReply = null
        if (release != null) {
            // A synchronous native call cannot be force-cancelled by coroutine cancellation. Wait for
            // the model mutex from an independent one-shot scope before freeing the native handle.
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO).launch {
                runCatching { modelInferenceMutex.withLock { release.invoke() } }
            }
        }
        speechEngine?.stop()
        speechEngine?.shutdown()
        super.onDestroy()
    }

    companion object {
        private val C_BG = Color.rgb(5, 12, 29)
        private val C_PANEL = Color.rgb(12, 25, 49)
        private val C_PANEL_2 = Color.rgb(17, 37, 70)
        private val C_STROKE = Color.rgb(48, 105, 174)
        private val C_STROKE_SOFT = Color.rgb(37, 69, 115)
        private val C_TEXT = Color.rgb(235, 243, 255)
        private val C_MUTED = Color.rgb(151, 177, 213)
        private val C_BLUE = Color.rgb(38, 121, 255)
        private val C_BLUE_BRIGHT = Color.rgb(81, 174, 255)
        private val C_BLUE_DARK = Color.rgb(28, 78, 153)
        private val C_BLUE_TEXT = Color.rgb(137, 199, 255)
        private val C_PURPLE = Color.rgb(127, 121, 255)
        private val C_MINT = Color.rgb(103, 231, 206)
        private val C_USER_BUBBLE = Color.rgb(33, 99, 210)
        private val C_USER_BUBBLE_2 = Color.rgb(44, 113, 237)
        private val C_AI_BUBBLE = Color.rgb(19, 42, 77)
        private val C_THINK_BUBBLE = Color.rgb(32, 35, 77)
        private val C_SOURCE_BUBBLE = Color.rgb(15, 44, 68)
        private val C_ERROR_BUBBLE = Color.rgb(72, 35, 51)
        private val C_USER_NAME = Color.rgb(111, 203, 255)
        private val C_AI_NAME = Color.rgb(190, 167, 255)
    }
}
