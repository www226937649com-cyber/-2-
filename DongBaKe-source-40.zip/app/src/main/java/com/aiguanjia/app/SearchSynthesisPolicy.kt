package com.aiguanjia.app

internal data class SearchSynthesisBudget(
    val modeName: String,
    val maxSources: Int,
    val questionChars: Int,
    val sourceChars: Int,
    val totalPromptChars: Int
)

/** Bounds retrieved-source prompts separately from ordinary local-chat context. */
internal object SearchSynthesisPolicy {
    fun forMode(modeIndex: Int, contextSize: Int): SearchSynthesisBudget {
        val contextCharBound = contextSize.coerceIn(512, 32768) * 2
        val budget = when (modeIndex.coerceIn(0, 2)) {
            0 -> SearchSynthesisBudget("快速", 2, 500, 1400, 2300)
            1 -> SearchSynthesisBudget("均衡", 3, 800, 3000, 4300)
            else -> SearchSynthesisBudget("深度", 4, 1200, 5000, 6500)
        }
        return budget.copy(totalPromptChars = minOf(budget.totalPromptChars, contextCharBound).coerceAtLeast(700))
    }

    fun trimPrompt(prompt: String, budget: SearchSynthesisBudget): String {
        val limit = budget.totalPromptChars.coerceAtLeast(1)
        if (prompt.length <= limit) return prompt
        val marker = "\n[较早检索资料已按当前模式压缩。]\n"
        if (limit <= marker.length + 2) return prompt.takeLast(limit)
        // Keep the beginning (question/source-safety instructions) and the end (final synthesis instructions).
        val usable = limit - marker.length
        val desiredPrefix = budget.questionChars + 100
        val prefixLength = desiredPrefix.coerceAtMost((usable * 0.70).toInt()).coerceAtLeast(1)
        val suffixLength = (usable - prefixLength).coerceAtLeast(1)
        return (prompt.take(prefixLength) + marker + prompt.takeLast(suffixLength)).take(limit)
    }
}
