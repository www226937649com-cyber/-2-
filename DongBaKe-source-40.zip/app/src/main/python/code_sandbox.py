"""A restricted Python-like calculation sandbox, not a general Python interpreter.

No imports, attribute access, file/network/system APIs, eval, exec, or process creation are allowed.
Code is parsed into AST and interpreted by an allowlisted evaluator with wall-clock, step,
loop, container and output limits. Run in-process limitations are explicit: this is application-
level isolation, not an OS-level security sandbox.
"""
import ast
import math
import statistics
import time

MAX_CODE_CHARS = 12000
MAX_AST_NODES = 1800
MAX_STEPS = 100000
MAX_LOOP_ITEMS = 20000
MAX_CONTAINER_ITEMS = 20000
MAX_OUTPUT_CHARS = 12000
MAX_INT_BITS = 4096
_ALLOWED_MATH = {
    "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "log": math.log, "log10": math.log10, "exp": math.exp, "fabs": math.fabs,
    "floor": math.floor, "ceil": math.ceil, "factorial": math.factorial,
    "pi": math.pi, "e": math.e,
}
_ALLOWED_CALLS = {
    "abs": abs, "round": round, "min": min, "max": max, "sum": sum,
    "len": len, "sorted": sorted, "range": range, "enumerate": enumerate,
    "mean": statistics.mean, "median": statistics.median,
    "pstdev": statistics.pstdev, "stdev": statistics.stdev,
}
_BIN_OPS = {
    ast.Add: lambda a, b: a + b, ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b, ast.Div: lambda a, b: a / b,
    ast.FloorDiv: lambda a, b: a // b, ast.Mod: lambda a, b: a % b,
    ast.Pow: lambda a, b: a ** b,
}
_CMP_OPS = {
    ast.Eq: lambda a, b: a == b, ast.NotEq: lambda a, b: a != b,
    ast.Lt: lambda a, b: a < b, ast.LtE: lambda a, b: a <= b,
    ast.Gt: lambda a, b: a > b, ast.GtE: lambda a, b: a >= b,
    ast.In: lambda a, b: a in b, ast.NotIn: lambda a, b: a not in b,
}

class SandboxError(ValueError):
    pass

class _Sandbox:
    def __init__(self, timeout_ms, max_steps, max_items):
        self.deadline = time.monotonic() + max(1, min(int(timeout_ms), 60000)) / 1000.0
        self.max_steps = max(100, min(int(max_steps), MAX_STEPS))
        self.max_items = max(100, min(int(max_items), MAX_CONTAINER_ITEMS))
        self.steps = 0
        self.env = {"pi": math.pi, "e": math.e}
        self.output = []
        self.return_value = None

    def tick(self):
        self.steps += 1
        if self.steps > self.max_steps:
            raise SandboxError("超过指令步数上限")
        if time.monotonic() > self.deadline:
            raise SandboxError("超过沙箱执行时间限制")

    def check(self, value):
        if isinstance(value, bool) or value is None or isinstance(value, str):
            if isinstance(value, str) and len(value) > MAX_OUTPUT_CHARS:
                raise SandboxError("字符串结果过长")
            return value
        if isinstance(value, int):
            if value.bit_length() > MAX_INT_BITS:
                raise SandboxError("整数结果过大")
            return value
        if isinstance(value, float):
            if not math.isfinite(value):
                raise SandboxError("计算结果不是有限数值")
            return value
        if isinstance(value, (list, tuple)):
            if len(value) > self.max_items:
                raise SandboxError("集合长度超过上限")
            return value
        if isinstance(value, dict):
            if len(value) > self.max_items:
                raise SandboxError("字典长度超过上限")
            checked = {}
            for key, item in value.items():
                if not isinstance(key, (str, int, float, bool)):
                    raise SandboxError("字典键类型不受支持")
                checked[self.check(key)] = self.check(item)
            return checked
        if isinstance(value, range):
            if len(value) > self.max_items:
                raise SandboxError("range 规模超过上限")
            return list(value)
        raise SandboxError("结果类型不受支持")

    def expr(self, node):
        self.tick()
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or node.value is None or isinstance(node.value, (int, float, str)):
                return self.check(node.value)
            raise SandboxError("常量类型不受支持")
        if isinstance(node, ast.Name):
            if node.id not in self.env:
                raise SandboxError("变量未定义：" + node.id[:80])
            return self.env[node.id]
        if isinstance(node, (ast.List, ast.Tuple)):
            if len(node.elts) > self.max_items:
                raise SandboxError("集合字面量太大")
            values = [self.expr(item) for item in node.elts]
            return values if isinstance(node, ast.List) else tuple(values)
        if isinstance(node, ast.Dict):
            if len(node.keys) > self.max_items:
                raise SandboxError("字典字面量太大")
            result = {}
            for key_node, value_node in zip(node.keys, node.values):
                key = self.expr(key_node)
                if not isinstance(key, (str, int, float, bool)):
                    raise SandboxError("字典键类型不受支持")
                result[key] = self.expr(value_node)
            return result
        if isinstance(node, ast.BinOp):
            op = _BIN_OPS.get(type(node.op))
            if op is None:
                raise SandboxError("运算符不在白名单中")
            left, right = self.expr(node.left), self.expr(node.right)
            if isinstance(node.op, ast.Pow) and (not isinstance(right, (int, float)) or abs(right) > 1000):
                raise SandboxError("幂运算指数超过上限")
            if isinstance(node.op, ast.Mult) and isinstance(left, (str, list, tuple)) and isinstance(right, int) and len(left) * max(0, right) > self.max_items:
                raise SandboxError("重复结果规模超过上限")
            if isinstance(node.op, ast.Mult) and isinstance(right, (str, list, tuple)) and isinstance(left, int) and len(right) * max(0, left) > self.max_items:
                raise SandboxError("重复结果规模超过上限")
            return self.check(op(left, right))
        if isinstance(node, ast.UnaryOp):
            value = self.expr(node.operand)
            if isinstance(node.op, ast.UAdd): return self.check(+value)
            if isinstance(node.op, ast.USub): return self.check(-value)
            if isinstance(node.op, ast.Not): return not value
            raise SandboxError("一元运算符不受支持")
        if isinstance(node, ast.BoolOp):
            if isinstance(node.op, ast.And):
                result = True
                for item in node.values:
                    result = self.expr(item)
                    if not result: return result
                return result
            if isinstance(node.op, ast.Or):
                result = False
                for item in node.values:
                    result = self.expr(item)
                    if result: return result
                return result
            raise SandboxError("布尔运算不受支持")
        if isinstance(node, ast.Compare):
            left = self.expr(node.left)
            for op_node, right_node in zip(node.ops, node.comparators):
                op = _CMP_OPS.get(type(op_node))
                if op is None: raise SandboxError("比较操作不受支持")
                right = self.expr(right_node)
                if not op(left, right): return False
                left = right
            return True
        if isinstance(node, ast.IfExp):
            return self.expr(node.body if self.expr(node.test) else node.orelse)
        if isinstance(node, ast.Slice):
            lower = self.expr(node.lower) if node.lower is not None else None
            upper = self.expr(node.upper) if node.upper is not None else None
            step = self.expr(node.step) if node.step is not None else None
            for part in (lower, upper, step):
                if part is not None and (not isinstance(part, int) or isinstance(part, bool)):
                    raise SandboxError("切片边界仅允许整数")
            if step == 0:
                raise SandboxError("切片步长不能为 0")
            return slice(lower, upper, step)
        if isinstance(node, ast.Subscript):
            base = self.expr(node.value)
            index = self.expr(node.slice)
            if not isinstance(base, (list, tuple, str, dict)) or not isinstance(index, (int, str, slice)):
                raise SandboxError("索引操作不受支持")
            if isinstance(base, (list, tuple, str)) and isinstance(index, slice):
                result = base[index]
                if len(result) > self.max_items: raise SandboxError("切片结果过大")
                return result
            return self.check(base[index])
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.keywords:
                raise SandboxError("只允许白名单函数，且不允许关键字参数")
            name = node.func.id
            if name == "print":
                values = [self.expr(arg) for arg in node.args]
                self.output.append(" ".join(str(v) for v in values)[:2000])
                if sum(len(s) for s in self.output) > MAX_OUTPUT_CHARS:
                    raise SandboxError("输出内容超过上限")
                return None
            fn = _ALLOWED_CALLS.get(name) or _ALLOWED_MATH.get(name)
            if fn is None: raise SandboxError("函数不在白名单中：" + name[:80])
            args = [self.expr(arg) for arg in node.args]
            if name == "range":
                value = range(*args)
                if len(value) > self.max_items: raise SandboxError("range 规模超过上限")
                return list(value)
            if name == "factorial":
                if len(args) != 1 or not isinstance(args[0], int) or isinstance(args[0], bool) or not 0 <= args[0] <= 10000:
                    raise SandboxError("factorial 仅允许 0 到 10000 的整数参数")
            if name in ("min", "max", "sum", "sorted", "mean", "median", "pstdev", "stdev") and args and isinstance(args[0], (list, tuple)) and len(args[0]) > self.max_items:
                raise SandboxError("函数输入规模超过上限")
            return self.check(fn(*args))
        raise SandboxError("表达式包含不允许的语法：" + type(node).__name__)

    def stmt(self, node):
        self.tick()
        if isinstance(node, ast.Expr):
            value = self.expr(node.value)
            self.return_value = value
            return
        if isinstance(node, ast.Assign):
            if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                raise SandboxError("赋值只能写入单个普通变量")
            self.env[node.targets[0].id] = self.check(self.expr(node.value))
            self.return_value = self.env[node.targets[0].id]
            return
        if isinstance(node, ast.AugAssign):
            if not isinstance(node.target, ast.Name): raise SandboxError("复合赋值仅支持普通变量")
            op = _BIN_OPS.get(type(node.op))
            if op is None: raise SandboxError("复合运算符不受支持")
            if node.target.id not in self.env: raise SandboxError("变量未定义：" + node.target.id[:80])
            self.env[node.target.id] = self.check(op(self.env[node.target.id], self.expr(node.value)))
            self.return_value = self.env[node.target.id]
            return
        if isinstance(node, ast.For):
            if not isinstance(node.target, ast.Name) or node.orelse:
                raise SandboxError("循环只支持简单变量，且不支持 else 分支")
            iterable = self.expr(node.iter)
            if not isinstance(iterable, (list, tuple, str)) or len(iterable) > self.max_items:
                raise SandboxError("循环对象必须是有界的列表、元组、字符串或 range")
            for item in iterable:
                self.tick()
                self.env[node.target.id] = item
                for child in node.body: self.stmt(child)
            return
        if isinstance(node, ast.If):
            branch = node.body if self.expr(node.test) else node.orelse
            for child in branch: self.stmt(child)
            return
        if isinstance(node, ast.Pass): return
        raise SandboxError("语句不在白名单中：" + type(node).__name__)

    def run(self, tree):
        for statement in tree.body:
            self.stmt(statement)
        if self.output:
            rendered = "\n".join(self.output)
            if self.return_value is not None:
                rendered += ("\n" if rendered else "") + str(self.return_value)
            return rendered[:MAX_OUTPUT_CHARS]
        return str(self.return_value)[:MAX_OUTPUT_CHARS] if self.return_value is not None else "执行完成；未产生显式结果。"


def run(code, timeout_ms=30000, max_steps=MAX_STEPS, max_items=MAX_LOOP_ITEMS):
    """Run restricted calculation code. Errors are returned as ERROR messages, never success."""
    try:
        if not isinstance(code, str) or not code.strip():
            raise SandboxError("代码为空")
        if len(code) > MAX_CODE_CHARS:
            raise SandboxError("代码超过 12000 字符上限")
        tree = ast.parse(code, mode="exec")
        if sum(1 for _ in ast.walk(tree)) > MAX_AST_NODES:
            raise SandboxError("语法节点数量超过上限")
        interpreter = _Sandbox(timeout_ms, max_steps, max_items)
        return interpreter.run(tree)
    except ZeroDivisionError:
        return "ERROR: 除数不能为 0"
    except OverflowError:
        return "ERROR: 计算结果超出范围"
    except Exception as exc:
        return "ERROR: " + (str(exc) or type(exc).__name__)[:500]
