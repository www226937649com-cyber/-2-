package com.aiguanjia.app

import org.junit.Assert.assertTrue
import org.junit.Test

class InferencePromptPolicyTest {
    @Test fun allModeSystemPromptsStayWithinOneHundredCharacters() {
        for (mode in 0..2) {
            val prompt = InferencePromptPolicy.systemPrompt(mode, simpleQuestion = false, webResearch = false, supportsReasoning = true)
            assertTrue("Mode $mode prompt was ${prompt.length} chars", prompt.length <= 100)
            assertTrue(prompt.contains("简体中文"))
            assertTrue(prompt.contains("不确定") || prompt.contains("不编造"))
        }
    }

    @Test fun simpleQuestionUsesNoThinkPathInEveryMode() {
        for (mode in 0..2) {
            val prompt = InferencePromptPolicy.systemPrompt(mode, simpleQuestion = true, webResearch = false, supportsReasoning = true)
            assertTrue("Mode $mode should not request long thinking for simple questions", prompt.endsWith("/no_think"))
        }
    }

    @Test fun reasoningDirectiveIsExplicitOnlyWhenSupportedAndNeeded() {
        val unsupported = InferencePromptPolicy.systemPrompt(1, false, false, false)
        assertTrue(!unsupported.contains("/think"))
        assertTrue(InferencePromptPolicy.systemPrompt(1, false, false, true).endsWith("/think"))
        assertTrue(InferencePromptPolicy.systemPrompt(2, false, true, true).contains("直接回答原问题"))
    }
    @Test fun customAssistantNameIsPreservedWithinPromptBudget() {
        val prompt = InferencePromptPolicy.systemPrompt(1, false, false, false, assistantName = "东巴壳")
        assertTrue(prompt.contains("384 tokens内"))
        assertTrue(prompt.startsWith("你是东巴壳。"))
        assertTrue(prompt.length <= 100)
        val longNamePrompt = InferencePromptPolicy.systemPrompt(1, false, false, false, assistantName = "X".repeat(64))
        assertTrue(longNamePrompt.length <= 100)
    }
}
