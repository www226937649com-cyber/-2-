package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalEmbeddingRouterTest {
    @Test fun meanPoolsContentTokensAndIgnoresSpecialAndPaddingTokens() {
        val pooled = LocalEmbeddingRouter.meanPoolAndNormalize(
            listOf(
                floatArrayOf(100f, 0f), // CLS: excluded
                floatArrayOf(1f, 0f),
                floatArrayOf(0f, 1f),
                floatArrayOf(0f, 0f), // SEP: excluded
                floatArrayOf(50f, 50f) // masked padding: excluded
            ),
            longArrayOf(1, 1, 1, 1, 0),
            excludeSpecialTokens = true
        )
        assertEquals(2, pooled.size)
        assertEquals(0.7071f, pooled[0], 0.001f)
        assertEquals(0.7071f, pooled[1], 0.001f)
    }

    @Test fun rejectsMismatchedEmbeddingAndMaskLengths() {
        val error = runCatching {
            LocalEmbeddingRouter.meanPoolAndNormalize(listOf(floatArrayOf(1f)), longArrayOf(1, 1), true)
        }.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
    }
}
