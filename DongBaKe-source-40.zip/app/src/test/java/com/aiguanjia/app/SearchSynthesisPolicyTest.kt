package com.aiguanjia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchSynthesisPolicyTest {
    @Test fun sourceAndPromptBudgetsScaleByMode() {
        val quick = SearchSynthesisPolicy.forMode(0, 4096)
        val balanced = SearchSynthesisPolicy.forMode(1, 4096)
        val deep = SearchSynthesisPolicy.forMode(2, 4096)
        assertEquals(2, quick.maxSources)
        assertEquals(3, balanced.maxSources)
        assertEquals(4, deep.maxSources)
        assertTrue(quick.totalPromptChars < balanced.totalPromptChars)
        assertTrue(balanced.totalPromptChars < deep.totalPromptChars)
    }

    @Test fun contextWindowCapsSearchSynthesisPromptBudget() {
        val deepSmallContext = SearchSynthesisPolicy.forMode(2, 1024)
        assertEquals(2048, deepSmallContext.totalPromptChars)
    }

    @Test fun trimmingRetainsCurrentQuestionPrefixAndLatestSourceTail() {
        val budget = SearchSynthesisPolicy.forMode(0, 1024)
        val prompt = "用户原问题：请比较甲和乙。\n" + "来源摘要。".repeat(900)
        val trimmed = SearchSynthesisPolicy.trimPrompt(prompt, budget)
        assertTrue(trimmed.length <= budget.totalPromptChars)
        assertTrue(trimmed.startsWith("用户原问题：请比较甲和乙。"))
        assertTrue(trimmed.contains("较早检索资料已按当前模式压缩"))
    }
}
