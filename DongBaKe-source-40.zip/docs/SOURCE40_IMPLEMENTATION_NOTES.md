# Source40 implementation and verification notes

## Version and baseline

- Base: the handoff archive `DongBaKe-source-39-v0.12.5-ai-tool-dispatch.zip` (SHA-256 `98318609d60c7e884de3a2a58b2710e164364cebcc12b7789deb3306701d96f7`).
- Intended next release: `versionCode=40`, `versionName=0.12.6-ai-performance-routing`.
- Application ID remains `com.aiguanjia.app`.
- This patch is designed to be applied after the existing Source37 → Source38 tool-dispatch + Source39 repair workflow. It must not be applied directly to Source37 or Source38.

## Implemented in this source tree

- Local ONNX Embedding candidate routing through ONNX Runtime for Android. The model and matching vocabulary are imported by the user to private app storage. Query/tool embeddings stay on device. Tool-description vectors are cached in memory per installed model and description. If files are missing, inference fails, or confidence is low, the route falls back to all AI-authorized tools. The router only filters tool descriptions; the main model still decides whether to call a tool.
- Explicitly parseable simple arithmetic is evaluated through the existing AST-allowlisted expression evaluator before normal model inference. Failed parsing/evaluation falls back to the model. This does not redirect arbitrary prose or all math prompts away from the model.
- `code_sandbox.py` is a constrained Python-like AST interpreter, not unrestricted `eval`/`exec` and not a full Python runtime. Imports, attribute access, files, networking, system commands, and process creation are unavailable. Code length, AST node count, step count, wall-clock budget, ranges/collections, numeric size, and output are bounded. It is application-layer interpretation, not an OS-level isolated sandbox; this limitation is logged and described to the user.
- Regular native inference retains its context and attempts exact token-prefix KV reuse, with a conservative minimum prefix length. It logs hit/miss, reused tokens, processed prefill tokens, invalidation reasons, and persistent-context state. Failed decode/prefill, unknown native exceptions, speculative mode, CPU fallback reload, explicit unload, or memory pressure clear this cache. The cache only trusts tokens that were successfully decoded into the context.
- The Qwen reasoning control no longer relies only on matching one literal newline suffix. It detects the actual final assistant/open-think template shape and logs when the requested suppression cannot be safely applied.
- Runtime logging preference is sent to the JNI layer. Ordinary native detail is suppressed when disabled while warnings/errors/fatal evidence is preserved.
- Mode-switch status distinguishes preference context, loaded native context, effective soft context, and whether a reload is required.
- Diagnostic schema and regression assertions are updated.

## Required checks and known limitations

- Python source tests and shell audits should run in CI before APK assembly.
- Kotlin/Android and C++ compilation are not considered validated until the Source40 GitHub Actions run succeeds.
- The Embedding model is not bundled into the APK. Before import the system deliberately falls back to the full authorized tool list; the route itself becomes active only after importing a compatible BGE-small-zh-v1.5 ONNX export and its matching `vocab.txt`. Different ONNX export output shapes are supported only for common float output tensors; incompatible outputs fail open.
- The similarity thresholds and `top-4` candidate policy are conservative initial values, not a proven evaluation result. A labeled Chinese tool-routing test set and device measurements are still needed.
- Prefix cache reuse is proven only by native hit/reused-token logs; performance gain and answer equivalence require actual phone A/B tests. Persistent KV allocation is released on memory-pressure callbacks, but Android lifecycle behavior still needs device validation.
- The AST sandbox is not an OS security boundary. It intentionally cannot execute arbitrary system code.
- No change in this patch intentionally redesigns Vulkan/GPU code. Existing build may still compile the existing CPU/Vulkan native libraries because that is the project’s present workflow; no device-side Vulkan optimization is claimed.
- A successful CI run verifies source tests/build/artifact checks only. It does not count as validation on the Redmi Note 11T Pro.
