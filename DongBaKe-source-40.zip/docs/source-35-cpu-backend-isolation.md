# 东巴壳 source-35：CPU 后端隔离与原生崩溃修复

- 版本：`0.12.1-cpu-backend-isolation`，`versionCode=35`
- 应用包名保持：`com.aiguanjia.app`
- 基线：source-34 / llama.cpp v0.6.0
- 状态：源码修复与 CI 编译待验证；真机运行尚未验证。

## 本次系统报告中的确定证据

2026-10-15 16:10:02 的 `tombstone_10` 记录了 `com.aiguanjia.app` 在 `nativeGenerate` 内发生 `SIGSEGV`，故障地址为 `0x0`。栈顶依次经过 `libggml-vulkan.so`、`ggml_backend_sched_reserve`、`llama_context::graph_reserve`、`llama_context::sched_reserve`、`llama_init_from_model`。同一轮应用日志显示请求 GPU 层数为 0，模型已加载成功，随后创建推理上下文时崩溃。

该证据把优先调查点指向 CPU 请求路径仍可进入 Vulkan 图调度。它不能单独证明 Vulkan 驱动的根本错误，但足以要求 CPU 模式与 Vulkan 设备选择完全隔离。

## 修复内容

1. 不再无条件调用 `ggml_backend_load_all_from_path()`。启动时只按路径显式加载 `libggml-cpu.so`。
2. 只有明确请求 GPU 卸载层时才尝试加载 `libggml-vulkan.so`。
3. 当 `n_gpu_layers=0` 时，`llama_model_params.devices` 显式限制为 CPU 设备、`use_extra_bufts=false` 并保留 `LLAMA_LOAD_MODE_MMAP`。避免 CPU 模型加载继续采用 `Vulkan_Host` 额外缓冲区类型。
4. CPU 后端未成功初始化时，诊断信息会明确报错，不让 `llama_supports_gpu_offload()` 走“尚无后端时自动加载所有后端”的隐式路径。
5. 引擎状态页在 Vulkan 插件尚未加载时跳过直接 Vulkan 驱动探测；GPU 请求路径仍会执行设备检查。
6. 增加源码回归断言，覆盖动态后端加载条件、CPU-only 设备列表和额外缓冲区开关。

## 验收步骤

- 自动测试：Python 源码回归、模型配置测试、数学解析测试、源码审计、Android 单元测试。
- 构建检查：Android arm64-v8a / x86_64 原生库与 Debug/Release APK；确认签名和 `versionCode=35`。
- 真机 CPU 验收：使用同一模型、上下文 2048、4 个 CPU 线程、GPU 层数 0。原生日志应含 `backend_loaded name=CPU`、不应含 `backend_loaded name=Vulkan`，加载参数应显示 `device_scope=CPU_ONLY use_extra_bufts=false`，推理应到达 `context_init_complete`、`prompt_prefill_begin`，且系统不应再次出现同型 `SIGSEGV`。
- 性能验收：至少运行一次冷启动和两次后续短问题，记录模型加载耗时、Prefill、首字延迟、Decode、RSS / 可用内存；不要把构建成功当成性能修复证明。
- GPU 验收：单独请求少量 GPU 层后，核对 `backend_loaded name=Vulkan reason=explicit_gpu_offload_request` 与 `offloaded X/Y layers to GPU`。在 CPU 验收通过前，不建议启用 GPU 卸载。

## 本轮不包含

没有加入 Warmup、ADPF、强制大核绑定、持久化前缀 KV 缓存或新的采样器功能。这些不是本次 SIGSEGV 的直接修复项，须在稳定性回归后单独评估。
