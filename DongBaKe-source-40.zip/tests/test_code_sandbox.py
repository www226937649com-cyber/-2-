import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "code_sandbox", ROOT / "app" / "src" / "main" / "python" / "code_sandbox.py"
)
code_sandbox = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(code_sandbox)


class RestrictedCodeSandboxTests(unittest.TestCase):
    def test_bounded_dictionary_data_analysis_is_supported(self):
        self.assertEqual(code_sandbox.run("data = {'north': 4, 'south': 7}\ndata['north'] + data['south']"), "11")
        self.assertTrue(code_sandbox.run("data = {'x': 1}\nlen(data)").endswith("1"))

    def test_multiple_statements_and_loop(self):
        self.assertEqual(code_sandbox.run("total = 0\nfor x in range(1, 6):\n    total += x\ntotal"), "15")

    def test_statistics_and_print(self):
        result = code_sandbox.run("values = [2, 4, 8]\nprint(mean(values))\nmax(values)")
        self.assertEqual(result, "4.666666666666667\n8")

    def test_if_branch(self):
        self.assertEqual(code_sandbox.run("n = 7\nif n > 4:\n    n * 3\nelse:\n    0"), "21")

    def test_import_and_system_access_rejected(self):
        self.assertTrue(code_sandbox.run("import os\nos.system('id')").startswith("ERROR:"))
        self.assertTrue(code_sandbox.run("open('/etc/passwd').read()").startswith("ERROR:"))

    def test_attribute_access_rejected(self):
        self.assertTrue(code_sandbox.run("math.sqrt(9)").startswith("ERROR:"))

    def test_timeout_and_step_budget(self):
        self.assertIn("步数上限", code_sandbox.run("x = 0\nfor i in range(10000):\n    x += i", 30000, 100, 20000))
        self.assertIn("执行时间限制", code_sandbox.run("x = 1\nfor i in range(20000):\n    x += i", 1, 100000, 20000))

    def test_range_and_code_size_limits(self):
        self.assertTrue(code_sandbox.run("list(range(20001))").startswith("ERROR:"))
        self.assertTrue(code_sandbox.run("#" + "x" * 12001).startswith("ERROR:"))

    def test_factorial_argument_is_bounded(self):
        result = code_sandbox.run("factorial(10001)")
        self.assertTrue(result.startswith("ERROR:"))
        self.assertIn("factorial", result)

    def test_bounded_slice(self):
        self.assertEqual(code_sandbox.run("values = [1, 2, 3, 4]\nvalues[1:3]"), "[2, 3]")

    def test_division_by_zero_is_reported(self):
        self.assertTrue(code_sandbox.run("1 / 0").startswith("ERROR:"))


if __name__ == "__main__":
    unittest.main()
