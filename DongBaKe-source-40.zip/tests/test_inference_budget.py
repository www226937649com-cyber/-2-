from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
POLICY = (ROOT / "app/src/main/java/com/aiguanjia/app/InferenceBudgetPolicy.kt").read_text(encoding="utf-8")
MAIN = (ROOT / "app/src/main/java/com/aiguanjia/app/MainActivity.kt").read_text(encoding="utf-8")
BRIDGE = (ROOT / "app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt").read_text(encoding="utf-8")


class InferenceBudgetSourceTests(unittest.TestCase):
    def test_three_mode_soft_thinking_targets_are_distinct(self):
        self.assertIn('0 -> 64', POLICY)
        self.assertIn('1 -> 384', POLICY)
        self.assertIn('else -> 1024', POLICY)

    def test_hard_cap_preserves_input_context_and_stays_bounded(self):
        self.assertIn('MAX_HARD_OUTPUT_TOKENS = 4096', POLICY)
        self.assertIn('(safeContext / 2)', POLICY)

    def test_explicit_user_cancellation_is_never_auto_retried(self):
        self.assertIn('cancelled=true', POLICY)
        self.assertIn('explicitUserCancellationNeverTriggersAutomaticContinuation', (ROOT / "app/src/test/java/com/aiguanjia/app/InferenceBudgetPolicyTest.kt").read_text(encoding="utf-8"))

    def test_token_cap_is_detected_using_native_metrics(self):
        self.assertIn('generatedTokens=', POLICY)
        self.assertIn('InferenceBudgetPolicy.continuationReason(generated, firstPassMetrics, tokenLimit)', MAIN)

    def test_reached_first_pass_starts_answer_focused_continuation(self):
        self.assertIn('inference_soft_budget_continuation', MAIN)
        self.assertIn('【预算收敛规则】', MAIN)
        self.assertIn('continuationStillCapped', MAIN)
        self.assertIn('unfinished_think_block', POLICY)
        self.assertIn('missing_final_answer', POLICY)

    def test_latest_question_is_last_context_before_continuation_instruction(self):
        draft = MAIN.index('上一阶段未完成草稿')
        latest_question = MAIN.index('原问题与最近上下文（本段放在末尾')
        final_instruction = MAIN.index('请现在直接给出完整的正式回答', latest_question)
        self.assertLess(draft, latest_question)
        self.assertLess(latest_question, final_instruction)

    def test_native_bridge_allows_policy_hard_cap(self):
        self.assertEqual(BRIDGE.count('maxTokens.coerceIn(1, 8192)'), 2)


if __name__ == "__main__":
    unittest.main()
