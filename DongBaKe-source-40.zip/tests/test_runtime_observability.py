from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class RuntimeObservabilityContractTests(unittest.TestCase):
    def text(self, relative):
        return (ROOT / relative).read_text(encoding="utf-8")

    def test_diagnostics_schema_is_versioned_and_append_only(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/AppDiagnostics.kt")
        self.assertIn("const val SCHEMA_VERSION = 3", source)
        self.assertIn('"diagnostics_schema"', source)
        self.assertIn("logFileSnapshot", source)
        self.assertIn("OLD_LOG", source)
        self.assertIn("runtime_logging_enabled", source)

    def test_runtime_log_screen_has_shared_logging_switch_and_export_schema(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        log_screen = source[source.index("private fun showDiagnosticLogsScreen"):source.index("private fun showMoreFeaturesScreen")]
        self.assertIn('text = "记录普通运行日志（排查问题时建议开启）"', log_screen)
        self.assertIn('putBoolean("runtime_logging_enabled", checked)', log_screen)
        report = source[source.index("private fun buildFullDiagnosticsReport"):source.index("private fun runLocalInferenceBenchmark")]
        self.assertIn("AppDiagnostics.SCHEMA_VERSION", report)
        self.assertIn("loadedModelContextSize", report)
        self.assertIn("logFileSnapshot", report)

    def test_inference_metrics_include_context_mode_and_stage_timings_without_content(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertIn('"inference_prompt_policy"', source)
        self.assertIn('"inference_metrics"', source)
        for key in ["systemPromptChars=", "effectiveSoftContext=", "firstPassElapsedMs=", "continuationElapsedMs=", "continuationReason=", "firstPassThinkTagsObserved=", "firstPassVisibleThinkChars=", "finalOutputThinkTagsObserved=", "firstPassNativeMetrics=", "continuationNativeMetrics="]:
            self.assertIn(key, source)
        metrics = source[source.index('"inference_metrics"'):source.index('"inference_metrics"') + 1600]
        self.assertNotIn('append(raw)', metrics)
        self.assertNotIn('append(actualPrompt)', metrics)

    def test_mode_context_policy_and_short_prompts_are_used_in_generation(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertIn('putInt("inference_context_size", targetContext)', source)
        self.assertIn("InferencePromptPolicy.systemPrompt(", source)
        self.assertIn("check(systemPrompt.length <= 100)", source)
        policy = self.text("app/src/main/java/com/aiguanjia/app/InferencePromptPolicy.kt")
        self.assertIn("if (!supportsReasoning) """, policy)
        self.assertIn("InferenceBudgetPolicy.effectiveContextSize", source)

    def test_tool_calls_are_model_requested_and_results_return_to_the_model(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        registry = self.text("app/src/main/java/com/aiguanjia/app/AiToolRegistry.kt")
        self.assertIn("runModelWithTools(contextPrompt, generator)", source)
        self.assertIn("AiToolRegistry.parseResponse(reply.answer)", source)
        self.assertIn("AiToolRegistry.appendToolResult(currentPrompt, call.name, result, activeQuestionText)", source)
        self.assertIn('AiToolDefinition("web_search"', registry)
        self.assertNotIn("runSearchAndAnswer(", source)
        self.assertNotIn("shouldUseWebSearch(", source)

    def test_runtime_logging_switch_controls_native_detail_but_keeps_warnings(self):
        main = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        bridge = self.text("app/src/main/java/com/aiguanjia/app/NativeLlamaEngine.kt")
        native = self.text("app/src/main/cpp/dongbake_llama_jni.cpp")
        self.assertIn("NativeLlamaEngine.setVerboseLogging(checked)", main)
        self.assertIn("nativeSetVerboseLogging", bridge)
        self.assertIn("g_verbose_native_logging", native)
        self.assertIn("priority < ANDROID_LOG_WARN", native)
        self.assertIn('lower.find("fatal")', native)

    def test_embedding_router_is_local_fail_open_and_diagnostic(self):
        router = self.text("app/src/main/java/com/aiguanjia/app/LocalEmbeddingRouter.kt")
        main = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertIn("embedding_assets_missing", router)
        self.assertIn("fallback(reason", router)
        self.assertIn("OrtEnvironment.getEnvironment()", router)
        self.assertIn('"embedding_tool_route"', main)
        self.assertIn("LocalEmbeddingRouter.route", main)
        self.assertIn("prefixKvCache=exact_token_prefix_cache_enabled_native_context_persisted_until_memory_pressure", main)
        native = self.text("app/src/main/cpp/dongbake_llama_jni.cpp")
        self.assertIn("llama_memory_seq_rm(llama_get_memory(ctx), 0, static_cast<llama_pos>(common), -1)", native)
        self.assertIn("prefix_cache_reused_tokens=", native)
        self.assertIn("exact_prefix_reused", native)
        self.assertIn("nativeReleaseInferenceContext", native)

    def test_observability_contract_is_part_of_the_source_regression_suite(self):
        # The build workflow lives in the repository, not inside the source ZIP.
        # Keep this contract test portable so it also runs from clean source archives.
        suite = self.text("tests/test_runtime_observability.py")
        self.assertIn("test_inference_metrics_include_context_mode_and_stage_timings_without_content", suite)
        self.assertIn("test_runtime_log_screen_has_shared_logging_switch_and_export_schema", suite)
        self.assertTrue((ROOT / "tests/test_runtime_observability.py").is_file())

    def test_legacy_fixed_source_search_synthesis_is_not_used_for_dispatch(self):
        source = self.text("app/src/main/java/com/aiguanjia/app/MainActivity.kt")
        self.assertNotIn("SearchSynthesisPolicy.forMode", source)
        self.assertNotIn("results.take(synthesisBudget.maxSources)", source)
        self.assertNotIn('"search_synthesis_prompt_budget"', source)
        self.assertIn("runModelWithTools(contextPrompt, generator)", source)

if __name__ == "__main__":
    unittest.main()
